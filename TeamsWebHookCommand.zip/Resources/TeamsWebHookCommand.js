var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TeamsWebHookCommand;
(function (TeamsWebHookCommand_1) {
    var TeamsWebHookCommand = /** @class */ (function (_super) {
        __extends(TeamsWebHookCommand, _super);
        function TeamsWebHookCommand() {
            return _super.call(this) || this;
        }
        TeamsWebHookCommand.prototype.convertToString = function (source) {
            if (source === null || source === undefined) {
                return '';
            }
            return source + '';
        };
        TeamsWebHookCommand.prototype.execute = function () {
            var teamsWebHookParam = this.CommandParam;
            var evaluatedParam = {
                URL: this.convertToString(this.evaluateFormula(teamsWebHookParam.URL)),
                Title: this.convertToString(this.evaluateFormula(teamsWebHookParam.Title)),
                Text: this.convertToString(this.evaluateFormula(teamsWebHookParam.Text)),
                ShowErrorMessage: teamsWebHookParam.ShowErrorMessage,
                SuccessMessage: this.convertToString(this.evaluateFormula(teamsWebHookParam.SuccessMessage))
            };
            Forguncy.Helper.post("customApi/teamswebhookcommandapi/sendMessageToTeams", JSON.stringify(evaluatedParam), function (message) {
                if (message) {
                    if (evaluatedParam.ShowErrorMessage) {
                        alert(message);
                    }
                }
                else {
                    if (evaluatedParam.SuccessMessage) {
                        alert(evaluatedParam.SuccessMessage);
                    }
                }
            });
        };
        return TeamsWebHookCommand;
    }(Forguncy.Plugin.CommandBase));
    TeamsWebHookCommand_1.TeamsWebHookCommand = TeamsWebHookCommand;
})(TeamsWebHookCommand || (TeamsWebHookCommand = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CommandFactory.registerCommand("TeamsWebHookCommand.Command.TeamsWebHookCommand, TeamsWebHookCommand", TeamsWebHookCommand.TeamsWebHookCommand);
//# sourceMappingURL=TeamsWebHookCommand.js.map