var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var CarouselCellType = /** @class */ (function (_super) {
        __extends(CarouselCellType, _super);
        function CarouselCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.foreColor = "#FFF";
            _this.hasLoadImages = false;
            return _this;
        }
        CarouselCellType.prototype.createContent = function () {
            this.initlizeProperties();
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var carouselDiv = $("<div id=" + this.ID + " class='fgc-carousel'></div>");
            carouselDiv.addClass("carousel slide");
            carouselDiv.attr("data-ride", "carousel");
            carouselDiv.css("width", "100%");
            carouselDiv.css("height", "100%");
            if (cellTypeMetaData.ShowIndicators) {
                this.addCssStyle("#" + this.ID + " .carousel-indicators .active { background-color: " + Forguncy.ConvertToCssColor(this.foreColor) + ";}");
            }
            return carouselDiv;
        };
        CarouselCellType.prototype.initlizeProperties = function () {
            var _this = this;
            var element = this.CellElement;
            if (element.StyleInfo.Foreground && element.StyleInfo.Foreground !== "") {
                this.foreColor = element.StyleInfo.Foreground;
            }
            var cellTypeMetaData = element.CellType;
            cellTypeMetaData.ImageInfos.forEach(function (info) {
                info.Caption = _this.getApplicationResource(info.Caption);
                info.Description = _this.getApplicationResource(info.Description);
            });
            this.isBindingAndHasCommand = cellTypeMetaData.IsBinding && !!cellTypeMetaData.ImageClickCommand;
        };
        CarouselCellType.prototype.reload = function () {
            var cellTypeMetaData = this.CellElement.CellType;
            if (cellTypeMetaData.IsBinding) {
                $("#" + this.ID).carousel('dispose');
                $("#" + this.ID).empty();
                this.hasLoadImages = false;
                this.getImageInfosFromServer(cellTypeMetaData);
            }
        };
        CarouselCellType.prototype.initCarouselDiv = function (imageInfos, cellTypeMetaData) {
            if (this.hasLoadImages) {
                return;
            }
            if (!imageInfos || imageInfos.length <= 0) {
                return;
            }
            var carouselDiv = $("#" + this.ID);
            //<!-- Indicators -->
            if (cellTypeMetaData.ShowIndicators) {
                var indicators = this.getIndicators(imageInfos.length);
                carouselDiv.append(indicators);
            }
            //<!-- Wrapper for slides -->
            var wrapper = this.getWrapperForSlides(imageInfos, cellTypeMetaData.ShowCaptions, cellTypeMetaData.IsBinding);
            carouselDiv.append(wrapper);
            //<!-- Left and right controls -->
            if (cellTypeMetaData.ShowLeftRightControls) {
                carouselDiv.append(this.getLeftRightControls("prev"));
                carouselDiv.append(this.getLeftRightControls("next"));
            }
        };
        CarouselCellType.prototype.getImageInfosFromServer = function (cellTypeMetaData) {
            var _this = this;
            this.getBindingDataSourceValue(cellTypeMetaData.bindingOptions, null, function (data) {
                if (!data) {
                    data = [];
                }
                var items = [];
                for (var i = 0; i < data.length; i++) {
                    var imagePath = data[i]["image"];
                    if (_this.isBase64(data[i]["image"])) {
                        imagePath = "data:image/png;base64," + imagePath;
                    }
                    var itemInfo = {
                        Value: data[i]["value"],
                        Caption: data[i]["title"],
                        Description: data[i]["description"],
                        ImagePath: imagePath
                    };
                    items.push(itemInfo);
                }
                _this.initCarouselDiv(items, cellTypeMetaData);
                _this.hasLoadImages = true;
                _this.startCarousel();
            });
        };
        CarouselCellType.prototype.isBase64 = function (str) {
            if (!str || str === '' || str.trim() === '') {
                return false;
            }
            try {
                return btoa(atob(str)) === str;
            }
            catch (err) {
                return false;
            }
        };
        CarouselCellType.prototype.getBindingColumnNames = function (bindingImageInfo) {
            var valueColumn = bindingImageInfo.ValueColumn;
            var captionColumn = bindingImageInfo.CaptionColumn;
            var descriptionColumn = bindingImageInfo.DescriptionColumn;
            var imageColumn = bindingImageInfo.ImageColumn;
            var columnsArray = [valueColumn, captionColumn, descriptionColumn, imageColumn];
            return columnsArray.filter(function (value, index) { return value && columnsArray.indexOf(value) === index; });
        };
        CarouselCellType.prototype.addCssStyle = function (rule) {
            var stylesheet = null;
            for (var i in document.styleSheets) {
                if (document.styleSheets[i].href && document.styleSheets[i].href.indexOf("forguncyPluginBootstrap.min.css") !== -1) {
                    stylesheet = document.styleSheets[i];
                    break;
                }
            }
            if (stylesheet !== null) {
                stylesheet.insertRule(rule, stylesheet.cssRules.length);
            }
        };
        CarouselCellType.prototype.removeCssStyle = function () {
            var stylesheet = null;
            for (var i in document.styleSheets) {
                if (document.styleSheets[i].href && document.styleSheets[i].href.indexOf("forguncyPluginBootstrap.min.css") !== -1) {
                    stylesheet = document.styleSheets[i];
                    break;
                }
            }
            if (stylesheet !== null) {
                stylesheet.deleteRule(stylesheet.cssRules.length - 1);
            }
        };
        CarouselCellType.prototype.getIndicators = function (length) {
            var indicators_ol = $("<ol></ol>");
            indicators_ol.addClass("carousel-indicators");
            for (var i = 0; i < length; i++) {
                var li = $("<li></li>");
                li.attr("data-target", "#" + this.ID);
                li.attr("data-slide-to", i);
                li.css("border", "1px solid " + Forguncy.ConvertToCssColor(this.foreColor));
                if (i === 0) {
                    li.addClass("active");
                }
                indicators_ol.append(li);
            }
            return indicators_ol;
        };
        CarouselCellType.prototype.getWrapperForSlides = function (imageInfos, showCaptions, isBinding) {
            var _this = this;
            var wrapper_div = $("<div></div>");
            wrapper_div.addClass("carousel-inner");
            wrapper_div.attr("role", "listbox");
            wrapper_div.css("width", "100%");
            wrapper_div.css("height", "100%");
            var _loop_1 = function (i) {
                var div = $("<div></div>");
                div.addClass("carousel-item");
                div.css("width", "100%");
                div.css("height", "100%");
                if (i === 0) {
                    div.addClass("active");
                }
                var image = this_1.getImageToDiv(imageInfos[i], isBinding);
                div.append(image);
                if (showCaptions) {
                    var captionsDiv = this_1.getCaptionsDiv(imageInfos[i]);
                    div.append(captionsDiv);
                }
                if (this_1.hasCommand(imageInfos[i], isBinding)) {
                    div.on("click", function () {
                        _this.onClickExecuteCommand(imageInfos[i], isBinding);
                    });
                    div.css("cursor", "pointer");
                }
                wrapper_div.append(div);
            };
            var this_1 = this;
            for (var i = 0; i < imageInfos.length; i++) {
                _loop_1(i);
            }
            return wrapper_div;
        };
        CarouselCellType.prototype.hasCommand = function (imageInfo, isBinding) {
            return !isBinding && imageInfo.CommandList
                || this.isBindingAndHasCommand;
        };
        CarouselCellType.prototype.onClickExecuteCommand = function (imageInfo, isBinding) {
            if (isBinding) {
                var imageClickCommand = this.CellElement.CellType.ImageClickCommand;
                if (this.isCommandExecuting()) {
                    return;
                }
                var initParams = {};
                var context = this.getFormulaCalcContext();
                this.setValueToCell(context, imageClickCommand.ValueTo, imageInfo.Value, initParams);
                this.setValueToCell(context, imageClickCommand.CaptionTo, imageInfo.Caption, initParams);
                this.setValueToCell(context, imageClickCommand.DescriptionTo, imageInfo.Description, initParams);
                this.setValueToCell(context, imageClickCommand.ImageTo, imageInfo.ImagePath, initParams);
                this.executeCommand(imageClickCommand.CommandList, { initParams: initParams });
            }
            else {
                this.executeCommand(imageInfo.CommandList);
            }
        };
        CarouselCellType.prototype.setValueToCell = function (context, cellLocationFormula, value, initParams) {
            if (!cellLocationFormula) {
                return;
            }
            var cellLocation = Forguncy.Helper.getCellLocation(cellLocationFormula, context);
            var cell = Forguncy.Page.getCellByLocation(cellLocation);
            if (cell) {
                cell.setValue(value);
            }
            else {
                initParams[cellLocationFormula] = value;
            }
        };
        CarouselCellType.prototype.getImageToDiv = function (imageInfo, isBinding) {
            var imageDiv = $("<div></div>");
            var imagePath = this.GetImagePath(imageInfo.ImagePath, isBinding);
            if (imagePath) {
                imageDiv.css("background-image", "url(\"" + imagePath + "\")");
            }
            imageDiv.css("background-position", "center");
            imageDiv.css("background-size", "contain");
            imageDiv.css("background-repeat", "no-repeat");
            imageDiv.css("width", "100%");
            imageDiv.css("height", "100%");
            return imageDiv;
        };
        CarouselCellType.prototype.getCaptionsDiv = function (imageInfo) {
            var caption_div = $("<div></div>");
            caption_div.addClass("carousel-caption");
            caption_div.css("color", Forguncy.ConvertToCssColor(this.foreColor));
            if (imageInfo.Caption && imageInfo.Caption !== "") {
                var caption_h3 = $("<h3></h3>");
                $(caption_h3).text(imageInfo.Caption);
                caption_h3.css("text-overflow", "ellipsis");
                caption_h3.css("overflow", "hidden");
                caption_div.append(caption_h3);
            }
            if (imageInfo.Description && imageInfo.Description !== "") {
                var caption_p = $("<p></p>");
                $(caption_p).text(imageInfo.Description);
                caption_p.css("text-overflow", "ellipsis");
                caption_p.css("overflow", "hidden");
                caption_div.append(caption_p);
            }
            return caption_div;
        };
        CarouselCellType.prototype.getLeftRightControls = function (leftOrRight) {
            var control_a = $("<a></a>");
            control_a.addClass("carousel-control-" + leftOrRight);
            control_a.attr("data-slide", leftOrRight);
            control_a.attr("role", "button");
            control_a.attr("href", "#" + this.ID);
            var span = $("<span></span>");
            span.addClass("carousel-control-" + leftOrRight + "-icon");
            span.attr("aria-hidden", "true");
            var span2_text = leftOrRight === "prev" ? "Previous" : "Next";
            var span2 = $("<span>" + span2_text + "</span>");
            span2.addClass("sr-only");
            control_a.append(span);
            control_a.append(span2);
            return control_a;
        };
        CarouselCellType.prototype.GetImagePath = function (image, isBinding) {
            if (image) {
                //Support external image source.
                if (image.indexOf("http://") === 0 || image.indexOf("https://") === 0) {
                    return image;
                }
                //IE 11 does not support startswith function.
                if (image.indexOf("data:image/png;base64") === 0) {
                    return image;
                }
                if (isBinding) {
                    return Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer() + encodeURIComponent(image);
                }
                return Forguncy.Helper.SpecialPath.getUploadFileFolderPathInDesigner() + "CarouselCellType/Images/" + encodeURIComponent(image);
            }
            return null;
        };
        CarouselCellType.prototype.onPageLoaded = function (info) {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            if (!cellTypeMetaData.IsBinding) {
                this.initCarouselDiv(cellTypeMetaData.ImageInfos, cellTypeMetaData);
                this.hasLoadImages = true;
                this.startCarousel();
            }
            else {
                this.getImageInfosFromServer(cellTypeMetaData);
                this.onDependenceCellValueChanged(this.reload.bind(this));
            }
        };
        CarouselCellType.prototype.startCarousel = function () {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var interval = false;
            if (cellTypeMetaData.AutoSlide && cellTypeMetaData.Interval > 0) {
                interval = cellTypeMetaData.Interval * 1000;
            }
            var pauseWhenHover = false;
            if (cellTypeMetaData.AutoSlide && cellTypeMetaData.PauseWhenHover) {
                pauseWhenHover = "hover";
            }
            $('#' + this.ID).carousel({
                interval: interval,
                pause: pauseWhenHover,
                wrap: cellTypeMetaData.Wrap === true ? true : false
            });
        };
        CarouselCellType.prototype.destroy = function () {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            if (cellTypeMetaData.ShowIndicators) {
                this.removeCssStyle();
            }
            //getContainer是cellTypeBase中的内部方法
            $('#' + this.ID, this.getContainer()).carousel('dispose');
        };
        return CarouselCellType;
    }(Forguncy.Plugin.CellTypeBase));
    Forguncy.CarouselCellType = CarouselCellType;
})(Forguncy || (Forguncy = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("CarouselCellType.Carousel, CarouselCellType", Forguncy.CarouselCellType);
