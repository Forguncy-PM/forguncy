var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    var PreviewerControl = (function (_super) {
        __extends(PreviewerControl, _super);
        function PreviewerControl() {
            var _this = _super.call(this) || this;
            _this.visibility = false;
            _this.fileItems = [];
            _this.registProperty("activeItem");
            return _this;
        }
        PreviewerControl.prototype.syncFileItems = function (fileItems) {
            this.fileItems = fileItems;
            if (this.visibility) {
                this.refresh();
            }
        };
        return PreviewerControl;
    }(FilePreviewer.UserControl));
    FilePreviewer.PreviewerControl = PreviewerControl;
    var PreviewerView = (function (_super) {
        __extends(PreviewerView, _super);
        function PreviewerView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(PreviewerView.prototype, "visibility", {
            set: function (value) {
                var _this = this;
                if (value) {
                    clearTimeout(this.timeout);
                    document.body.style.overflow = "hidden";
                    this.container.addClass("show");
                    this.container.show();
                }
                else {
                    document.body.style.overflow = "";
                    this.container.removeClass("show");
                    this.timeout = setTimeout(function () {
                        _this.container.hide();
                    }, 150);
                }
            },
            enumerable: true,
            configurable: true
        });
        PreviewerView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-previewer fade\"></div>");
        };
        PreviewerView.prototype.createChildren = function () {
            this.addChild(new HeaderView(this.target));
            this.addChild(new ContentView(this.target));
            this.addChild(new FooterView(this.target));
        };
        return PreviewerView;
    }(FilePreviewer.ControlUIBase));
    FilePreviewer.PreviewerView = PreviewerView;
    var HeaderView = (function (_super) {
        __extends(HeaderView, _super);
        function HeaderView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(HeaderView.prototype, "activeItem", {
            set: function (value) {
                if (value) {
                    var fileName = value.getDisplayFileName();
                    this.title.text(fileName);
                    this.title.attr("data-original-title", fileName);
                    this.title.tooltip();
                }
            },
            enumerable: true,
            configurable: true
        });
        HeaderView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-previewer-header\"></div>");
        };
        HeaderView.prototype.createChildren = function () {
            var _this = this;
            var closeSVG = "<svg class=\"octicon octicon-x\" viewBox=\"0 0 12 16\" version=\"1.1\" width=\"16\" height=\"16\" aria-hidden=\"true\"><path fill-rule=\"evenodd\" d=\"M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z\"></path></svg>";
            var closeButton = $("<div class=\"FP-button-close\">" + closeSVG + "</div>").click(function (e) {
                e.stopPropagation();
                _this.target.hide();
            });
            this.title = $("<span class=\"FP-header-title\" data-toggle=\"tooltip\" data-placement=\"bottom\"></span>");
            this.container.append(this.title, closeButton);
        };
        return HeaderView;
    }(FilePreviewer.ControlUIBase));
    var ContentView = (function (_super) {
        __extends(ContentView, _super);
        function ContentView() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.views = [];
            return _this;
        }
        ContentView.prototype.dispose = function () {
            this.propertyChangedHandler && this.target.off("PropertyChanged", this.propertyChangedHandler);
            _super.prototype.dispose.call(this);
        };
        ContentView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-previewer-content\"></div>");
        };
        ContentView.prototype.createContainerEvents = function () {
            var _this = this;
            _super.prototype.createContainerEvents.call(this);
            this.propertyChangedHandler = function (propertyName) {
                if (propertyName === "visibility" && _this.target.visibility) {
                    _this.resetCarouselItems(_this.inner, _this.indicator, _this.carouselId);
                }
            };
            this.target.on("PropertyChanged", this.propertyChangedHandler);
        };
        ContentView.prototype.createChildren = function () {
            var carouselId = "FP-carousel-" + Math.floor(Math.random() * 100000).toString();
            var carousel = $("<div id=\"" + carouselId + "\" class=\"carousel slide\" data-ride=\"carousel\" data-interval=\"false\"></div>");
            var indicator = $("<ol class=\"carousel-indicators\"></ol>");
            var inner = $("<div class=\"carousel-inner\"></div>");
            var prev = $("\n<a class=\"carousel-control-prev\" href=\"#" + carouselId + "\" role=\"button\" data-slide=\"prev\">\n  <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>\n  <span class=\"sr-only\">Previous</span>\n</a>");
            var next = $("\n<a class=\"carousel-control-next\" href=\"#" + carouselId + "\" role=\"button\" data-slide=\"next\">\n  <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>\n  <span class=\"sr-only\">Next</span>\n</a>");
            this.inner = inner;
            this.indicator = indicator;
            this.carouselId = carouselId;
            if (this.target.visibility) {
                this.resetCarouselItems(inner, indicator, carouselId);
            }
            this.bindEvents(carousel, inner, indicator, carouselId);
            this.container.append(carousel.append(inner, indicator, prev, next));
        };
        ContentView.prototype.resetCarouselItems = function (inner, indicator, carouselId) {
            var _this = this;
            inner.empty();
            indicator.empty();
            this.views = [];
            this.target.fileItems.forEach(function (v, index) {
                var active = _this.target.activeItem ? v.src === _this.target.activeItem.src : index === 0;
                var previewItem = new PreviewItem(_this.target, v, active);
                var previewItemView = PreviewFileItemViewFactory.get(previewItem);
                _this.addChild(previewItemView, inner);
                var li = $("<li data-target=\"#" + carouselId + "\" data-slide-to=\"" + index + "\" class=\"" + (active ? "active" : "") + "\"></li>");
                indicator.append(li);
                if (active) {
                    previewItemView.lazyLoad();
                }
                _this.views.push(previewItemView);
            });
        };
        ContentView.prototype.bindEvents = function (carousel, inner, indicator, carouselId) {
            var _this = this;
            carousel.on("slide.bs.carousel", function (event) {
                _this.target.activeItem = _this.target.fileItems[event.to];
                _this.views[event.to] && _this.views[event.to].lazyLoad();
            });
        };
        return ContentView;
    }(FilePreviewer.ControlUIBase));
    var FooterView = (function (_super) {
        __extends(FooterView, _super);
        function FooterView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FooterView.prototype.createChildren = function () {
        };
        return FooterView;
    }(FilePreviewer.ControlUIBase));
    var PreviewItem = (function () {
        function PreviewItem(control, fileItem, active) {
            this.control = control;
            this.fileItem = fileItem;
            this.active = active;
        }
        return PreviewItem;
    }());
    FilePreviewer.PreviewItem = PreviewItem;
    var PreviewFileItemViewFactory = (function () {
        function PreviewFileItemViewFactory() {
        }
        PreviewFileItemViewFactory.get = function (previewItem) {
            if (previewItem.fileItem.status === 0) {
                switch (previewItem.fileItem.getFileType()) {
                    case 1:
                        return new ImageFileView(previewItem);
                    case 2:
                        return new OfficeFileView(previewItem);
                    case 3:
                        return new PDFFileView(previewItem);
                    case 4:
                        return new MediaFileView(previewItem);
                    default:
                        return new NotSupportedFileView(previewItem);
                }
            }
            else {
                return new LoadingFileView(previewItem);
            }
        };
        return PreviewFileItemViewFactory;
    }());
    FilePreviewer.PreviewFileItemViewFactory = PreviewFileItemViewFactory;
    var PreviewItemView = (function (_super) {
        __extends(PreviewItemView, _super);
        function PreviewItemView() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.hasLazyLoaded = false;
            return _this;
        }
        PreviewItemView.prototype.createContainer = function () {
            var activeClassName = this.target && this.target.active ? "active" : "";
            this.container = $("<div class=\"carousel-item " + activeClassName + "\"></div>");
        };
        PreviewItemView.prototype.lazyLoad = function () {
            if (!this.hasLazyLoaded) {
                this.hasLazyLoaded = true;
                this.lazyLoading();
            }
        };
        PreviewItemView.prototype.lazyLoading = function () {
        };
        return PreviewItemView;
    }(FilePreviewer.JQueryUIBase));
    FilePreviewer.PreviewItemView = PreviewItemView;
    var ImageFileView = (function (_super) {
        __extends(ImageFileView, _super);
        function ImageFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ImageFileView.prototype.lazyLoading = function () {
            var panel = $("<img class=\"d-block\" style=\"display:none !important\" />").attr("src", this.target.fileItem.getEncodeURIComponentSrc());
            this.container.append(panel);
            new Viewer(panel[0], { inline: true, navbar: false, toolbar: true, title: false, button: false, backdrop: false, transition: false });
        };
        return ImageFileView;
    }(PreviewItemView));
    var OfficeFileView = (function (_super) {
        __extends(OfficeFileView, _super);
        function OfficeFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        OfficeFileView.prototype.lazyLoading = function () {
            var base = "https://view.officeapps.live.com/op/embed.aspx?src=";
            var url = base + this.target.fileItem.getEntireEncodeURIComponentSrc();
            var officeLink = "<a target='_blank' href='http://office.com'>Microsoft Office</a>";
            var webappsLink = "<a target='_blank' href='http://office.com/webapps'>Office Online</a>";
            var innerText = "This is an embedded" + officeLink + "document, powered by " + webappsLink + ".";
            var panel = $("<iframe class=\"FP-carousel-item\" frameborder='0'>" + innerText + "</iframe>").attr("src", url);
            this.container.empty();
            this.container.append(panel);
        };
        return OfficeFileView;
    }(PreviewItemView));
    var PDFFileView = (function (_super) {
        __extends(PDFFileView, _super);
        function PDFFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PDFFileView.prototype.lazyLoading = function () {
            var base = this.getViewerBaseUrl();
            var url = base + this.target.fileItem.getEntireEncodeURIComponentSrc();
            var panel = $("<iframe class=\"FP-carousel-item\" frameborder='0'></iframe>").attr("src", url);
            this.container.empty();
            this.container.append(panel);
        };
        PDFFileView.prototype.getViewerBaseUrl = function () {
            var paths = FilePreviewer.FilePreviewer.currentScriptSrc.split("/");
            var pluginBase = paths.slice(0, -2).join("/");
            var baseUrl = pluginBase + "/Resources/External/PDF.js/web/viewer.html?file=";
            return baseUrl;
        };
        return PDFFileView;
    }(PreviewItemView));
    var MediaFileView = (function (_super) {
        __extends(MediaFileView, _super);
        function MediaFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MediaFileView.prototype.lazyLoading = function () {
            console.count("A");
            var panel = $("<video controls=\"controls\"/>").attr("src", this.target.fileItem.getEncodeURIComponentSrc());
            this.container.append(panel);
        };
        return MediaFileView;
    }(PreviewItemView));
    var NotSupportedFileView = (function (_super) {
        __extends(NotSupportedFileView, _super);
        function NotSupportedFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        NotSupportedFileView.prototype.lazyLoading = function () {
            var _this = this;
            var panel = $("\n<div class=\"FP-message\">\n  <div>" + FilePreviewer.Resources.File_CannotPreview + "</div>\n  <button type=\"button\" class=\"btn btn-primary btn-sm\">" + FilePreviewer.Resources.Button_DownloadDirectly + "</button>\n</div>");
            panel.find("button").click(function () {
                _this.target.control.dispatch("Download", [_this.target.fileItem]);
            });
            this.container.append(panel);
        };
        return NotSupportedFileView;
    }(PreviewItemView));
    var LoadingFileView = (function (_super) {
        __extends(LoadingFileView, _super);
        function LoadingFileView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        LoadingFileView.prototype.lazyLoading = function () {
            var panel = $("<div class=\"FP-message\">" + FilePreviewer.Resources.File_Uploading + "<span>0%</span></div>");
            this.target.fileItem.events.addHandler("ProgressChanged", function (e) {
                panel.find("span").text(Math.floor(e.loaded / e.total * 99).toString() + "%");
            });
            this.container.append(panel);
        };
        return LoadingFileView;
    }(PreviewItemView));
})(FilePreviewer || (FilePreviewer = {}));
