var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
var FilePreviewer;
(function (FilePreviewer) {
    var EventDispatcher = (function () {
        function EventDispatcher() {
            this.events = new FilePreviewer.Events();
        }
        EventDispatcher.prototype.on = function (eventName, handler, force) {
            if (force === void 0) { force = true; }
            this.events.addHandler(eventName, handler, force);
        };
        EventDispatcher.prototype.off = function (eventName, handler) {
            this.events.removeHandler(eventName, handler);
        };
        EventDispatcher.prototype.dispatch = function (eventName) {
            var _a;
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            (_a = this.events).raiseEvent.apply(_a, __spreadArrays([eventName], args));
        };
        EventDispatcher.prototype.dispose = function () {
            this.events.release();
        };
        return EventDispatcher;
    }());
    FilePreviewer.EventDispatcher = EventDispatcher;
})(FilePreviewer || (FilePreviewer = {}));
