var FilePreviewer;
(function (FilePreviewer) {
    var Resources = (function () {
        function Resources() {
        }
        Resources.Button_Upload = "업로드";
        Resources.Button_Preview = "미리보기";
        Resources.Button_Download = "다운로드";
        Resources.Button_Delete = "삭제";
        Resources.Button_DownloadDirectly = "파일 다운로드";
        Resources.File_CannotPreview = "파일이 미리보기를 지원하지 않습니다.  ";
        Resources.File_Uploading = "파일 업로드  중...";
        Resources.Error_UploadFailed = "업로드에 실패했습니다. Error：";
        Resources.Error_IncorrectFileType = "업로드하신 파일 {0}에 문제가 있습니다.";
        Resources.Error_IncorrectFileSize = "업로드하신 파일 {0}의 크기가 한도를 초과합니다. 최대 크기는 {1} MB 입니다.";
        Resources.Error_IncorrectFileCount = "업로드하실 수 있는 파일의 개수를 초과했습니다. 최대 {0}개까지 업로드하실 수 있습니다.";
        return Resources;
    }());
    FilePreviewer.Resources = Resources;
})(FilePreviewer || (FilePreviewer = {}));
