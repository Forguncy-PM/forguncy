GanttMaster.prototype.$lang["zh"] = {
	GridEditor: {
		Tabel: {
			codeNameCol: "编码",
			nameCol: "任务名称",
			planStartCol: "计划开始时间",
			startCol: "开始时间",
			planEndCol: "计划结束时间",
			endCol: "结束时间",
			planDurationCol: "计划工期",
			durationCol: "工期",
			dependsCol: "前置任务",
			assigsCol: "资源",
			startMilestoneTitle: "开始时间是一个里程碑",
			endMilestoneTitle: "结束时间是一个里程碑"
		},
		TaskRow: {
			codeNamePlaceholder: "编码",
			namePlaceholder: "名称"
		},
		Status: {
			STATUS_ACTIVE: "进行中",
			STATUS_DONE: "已完成",
			STATUS_FAILED: "已失败",
			STATUS_SUSPENDED: "准备中",
			STATUS_WAITING: "等待中"
		}
	},
	GridMaster: {
		ButtonBar: {
			addAboveCurrentTask: "在上一行添加任务",
			addBelowCurrentTask: "在下一行添加任务",
			outdentCurrentTask: "提高一层任务层级",
			indentCurrentTask: "降低一层任务层级",
			moveUpCurrentTask: "向上一层移动任务",
			moveDownCurrentTask: "向下一层移动任务",
			deleteFocused: "删除任务",
			expandAll: "展开子任务",
			collapseAll: "折叠子任务",
			zoomMinus: "增大视图",
			zoomPlus: "减少视图",
			toggleShowCriticalPath: "显/隐关键任务路径",
			splitterLeft: "分隔线置于最左边",
			splitterMiddle: "分隔线置于中间",
			splitterRight: "分隔线置于右边",
			toggleColorByStatus: "切换状态颜色",
			switchDiaplaySVG: "显/隐计划图",
			saveGanttData: "保存"
		},
		Custom: {
			msgError: "错误："
		}
	},
	Error: {
		CANNOT_WRITE: "没有权限去修改这些任务：",
		CHANGE_OUT_OF_SCOPE: "无法更新项目：缺乏更新父项目的权限",
		START_IS_MILESTONE: "开始时间是一个里程碑",
		END_IS_MILESTONE: "结束时间是一个里程碑",
		TASK_HAS_CONSTRAINTS: "任务被约束：拥有前置任务",
		GANTT_ERROR_DEPENDS_ON_OPEN_TASK: "错误：打开的任务被依赖。",
		GANTT_ERROR_DESCENDANT_OF_CLOSED_TASK: "错误：关闭的任务有子任务",
		TASK_HAS_EXTERNAL_DEPS: "这个任务有外部依赖。",
		GANNT_ERROR_LOADING_DATA_TASK_REMOVED: "错误：加载已移除的任务",
		CIRCULAR_REFERENCE: "循环依赖",
		CANNOT_DEPENDS_ON_ANCESTORS: "不能依赖祖先",
		INVALID_DATE_FORMAT: "插入的数据对于字段格式无效",
		GANTT_ERROR_LOADING_DATA_TASK_REMOVED: "加载数据时发生错误：一项任务已被删除。",
		CANNOT_CLOSE_TASK_IF_OPEN_ISSUE: "无法关闭有未解决问题的任务",
		TASK_MOVE_INCONSISTENT_LEVEL: "不能交换不同层级的任务",
		CANNOT_MOVE_TASK: "不能移动任务",
		PLEASE_SAVE_PROJECT: "PLEASE_SAVE_PROJECT请保存项目",
		GANTT_SEMESTER: "短学期",
		GANTT_SEMESTER_SHORT: "短学期",
		GANTT_QUARTER: "季度",
		GANTT_QUARTER_SHORT: "季度",
		GANTT_WEEK: "周",
		GANTT_WEEK_SHORT: "周",
		CANNOT_END_TIME_LESS_THAN_START_TIME: "结束时间不能小于开始时间",
		TASK_HAS_PERDECESSORS: "任务被约束：拥有前置任务",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_EARLY: "任务被约束：因为其父任务拥有前置任务，故此任务的开始时间不能早于其父任务的开始时间",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_MORE: "任务被约束：因为其父任务拥有前置任务，故必须有一个子任务的开始时间相同于其父任务的开始时间",
		TASK_HAS_SUBTASKS_START_TIME: "任务拥有子任务，其开始时间以子任务最早开始时间为准",
		TASK_HAS_SUBTASKS_END_TIME: "任务拥有子任务，其结束时间以子任务最晚结束时间为准",
		CANNOT_ADD_ABOVE_ROOT_TASK: "不能在根任务之前添加任务",
		CANNOT_OUTDENT_ROOT_TASK: "不能提高根任务层级",
		ONLY_CAN_HAVE_ONE_ROOT_TASK: "只能有一个根任务",
		CANNOT_INDENT_ROOT_TASK: "不能降低根任务层级",
		INDENT_TASK_MAXIMUM: "任务已缩进到最大程度：作为上一个任务的子任务",
		CANNOT_MOVE_ROOT_TASK: "不能移动根任务",
		TASK_MOVED_TO_TOP_SIBLING: "任务已移动到同级最前",
		TASK_MOVED_TO_LAST_SIBLING: "任务已移动到同级最后",
		CANNOT_DELETE_ROOT_TASK: "不能删除根任务"
	},
	Date: {
    DefaultFormat: "yyyy/MM/dd",
		MonthNames: {
			January: "一月",
			February: "二月",
			March: "三月",
			April: "四月",
			May: "五月",
			June: "六月",
			July: "七月",
			August: "八月",
			September: "九月",
			October: "十月",
			November: "十一月",
			December: "十二月"
		},
		MonthAbbreviations: {
			Jan: "一月",
			Feb: "二月",
			Mar: "三月",
			Apr: "四月",
			May: "五月",
			Jun: "六月",
			Jul: "七月",
			Aug: "八月",
			Sep: "九月",
			Oct: "十月",
			Nov: "十一月",
			Dec: "十二月"
		},
		DayNames: {
			Sunday: "周一",
			Monday: "周二",
			Tuesday: "周三",
			Wednesday: "周四",
			Thursday: "周五",
			Friday: "周六",
			Saturday: "周日"
		},
		DayAbbreviations: {
			Sun: "一",
			Mon: "二",
			Tue: "三",
			Wed: "四",
			Thu: "五",
			Fri: "六",
			Sat: "日"
		}
	}
};
