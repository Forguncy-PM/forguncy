GanttMaster.prototype.$lang['en'] = {
    GridEditor: {
        Tabel: {
            codeNameCol: "Code Name",
            nameCol: "Task Name",
            planStartCol: "Plan Start",
            startCol: "Start",
            planEndCol: "Plan End",
            endCol: "End",
            planDurationCol: "Plan Dur.",
            durationCol: "Dur.",
            dependsCol: "Dep.",
            assigsCol: "Assigs",
            startMilestoneTitle: "Start date is a milestone.",
            endMilestoneTitle: "End date is a milestone." 
        },
        TaskRow: {
            codeNamePlaceholder: "Code Name",
            namePlaceholder: "Name"
        },
        Status: {
            STATUS_ACTIVE: "Active",
            STATUS_DONE: "Completed",
            STATUS_FAILED: "Failed",
            STATUS_SUSPENDED: "Suspended",
            STATUS_WAITING: "Waiting"
        }
    },
    GridMaster: {
        ButtonBar: {
            addAboveCurrentTask: "Insert Above Task",
            addBelowCurrentTask: "Insert Below Task",
            outdentCurrentTask: "Outdent Task",
            indentCurrentTask: "Indent Task",
            moveUpCurrentTask: "Move Up Task",
            moveDownCurrentTask: "Move Down Task",
            deleteFocused: "Delete Task",
            expandAll: "Expand All Subtasks",
            collapseAll: "Collapse All Subtasks",
            zoomMinus: "Zoom Out",
            zoomPlus: "Zoom In",
            toggleShowCriticalPath: "Critical Path",
            splitterLeft: "Splitter To Left",
            splitterMiddle: "Splitter To Middle",
            splitterRight: "Splitter To Right",
            toggleColorByStatus: "Toggle Status Color",
            switchDiaplaySVG: "Switch Show Plan",
            saveGanttData: "Save"
        },
        Custom: {
            msgError: "ERROR:"
        }
    },
    Error: {
        CANNOT_WRITE: "No permission to change the following task:",
        CHANGE_OUT_OF_SCOPE: "Project update not possible as you lack rights for updating a parent project.",
        START_IS_MILESTONE: "Start date is a milestone.",
        END_IS_MILESTONE: "End date is a milestone.",
        TASK_HAS_CONSTRAINTS: "Task has constraints: It has predecessors or it is the first child task of the parent task",
        GANTT_ERROR_DEPENDS_ON_OPEN_TASK: "Error: there is a dependency on an open task.",
        GANTT_ERROR_DESCENDANT_OF_CLOSED_TASK: "Error: due to a descendant of a closed task.",
        TASK_HAS_EXTERNAL_DEPS: "This task has external dependencies.",
        GANNT_ERROR_LOADING_DATA_TASK_REMOVED: "GANNT_ERROR_LOADING_DATA_TASK_REMOVED",
        CIRCULAR_REFERENCE: "Circular reference.",
        CANNOT_DEPENDS_ON_ANCESTORS: "Cannot depend on ancestors.",
        INVALID_DATE_FORMAT: "The data inserted are invalid for the field format.",
        GANTT_ERROR_LOADING_DATA_TASK_REMOVED: "An error has occurred while loading the data. A task has been trashed.",
        CANNOT_CLOSE_TASK_IF_OPEN_ISSUE: "Cannot close a task with open issues",
        TASK_MOVE_INCONSISTENT_LEVEL: "You cannot exchange tasks of different depth.",
        CANNOT_MOVE_TASK: "CANNOT_MOVE_TASK",
        PLEASE_SAVE_PROJECT: "PLEASE_SAVE_PROJECT",
        GANTT_SEMESTER: "Semester",
        GANTT_SEMESTER_SHORT: "s.",
        GANTT_QUARTER: "Quarter",
        GANTT_QUARTER_SHORT: "q.",
        GANTT_WEEK: "Week",
        GANTT_WEEK_SHORT: "w.",
		CANNOT_END_TIME_LESS_THAN_START_TIME: "The start time cannot be less than the end time",
        TASK_HAS_PERDECESSORS: "Task has constraints: It has predecessors.",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_EARLY: "Task has constraints: because its parent has predecessors, so the start time of this task cannot be earlier than then start time of its parent task.",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_MORE: "Task has constraints: bacause its parent has predecessors, so there must be a child task whose start time is the same as that of its parent task.",
        TASK_HAS_SUBTASKS_START_TIME: "Task has subtasks, and its start time is subject to the earliest start time of the subtask.",
        TASK_HAS_SUBTASKS_END_TIME: "Task has subtasks, and its end time is subject to the lastest end time of the subtask.",
		CANNOT_ADD_ABOVE_ROOT_TASK: "Cannot add brothers to root.",
		CANNOT_OUTDENT_ROOT_TASK: "Cannot outdent the root task level.",
		ONLY_CAN_HAVE_ONE_ROOT_TASK: "There can only be one root task.",
		CANNOT_INDENT_ROOT_TASK: "Cannot indent the root task level.",
		INDENT_TASK_MAXIMUM: "Task indented to the maximum extent: as a subtask of the previous task.",
		CANNOT_MOVE_ROOT_TASK: "Cannot move the root task.",
		TASK_MOVED_TO_TOP_SIBLING: "Task moved to top of sibling.",
		TASK_MOVED_TO_LAST_SIBLING: "Task moved to last of sibling.",
		CANNOT_DELETE_ROOT_TASK: "Cannot delete the root task."
    },
	Date: {
        DefaultFormat: "MM/dd/yyyy",
		MonthNames: {
			January: "January",
			February: "February",
			March: "March",
			April: "April",
			May: "May",
			June: "June",
			July: "July",
			August: "August",
			September: "September",
			October: "October",
			November: "November",
			December: "December"
		},
		MonthAbbreviations: {
			Jan: "Jan",
			Feb: "Feb",
			Mar: "Mar",
			Apr: "Apr",
			May: "May",
			Jun: "Jun",
			Jul: "Jul",
			Aug: "Aug",
			Sep: "Sep",
			Oct: "Oct",
			Nov: "Nov",
			Dec: "Dec"
		},
		DayNames: {
			Sunday: "Sunday",
			Monday: "Monday",
			Tuesday: "Tuesday",
			Wednesday: "Wednesday",
			Thursday: "Thursday",
			Friday: "Friday",
			Saturday: "Saturday"
		},
		DayAbbreviations: {
			Sun: "Sun",
			Mon: "Mon",
			Tue: "Tue",
			Wed: "Wed",
			Thu: "Thu",
			Fri: "Fri",
			Sat: "Sat"
		}
	}
}
