var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Gantt;
(function (Gantt) {
    var GanttCellType = (function (_super) {
        __extends(GanttCellType, _super);
        function GanttCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._loopInvoker = new LoopInvoker();
            _this._hasDestroyed = false;
            return _this;
        }
        GanttCellType.prototype.createContent = function () {
            var container = $("<div id=\"" + this.ID + "\" style='height: 100%; width: 100%;'></div>");
            this._container = container;
            return container;
        };
        GanttCellType.prototype.getGanttData = function () {
            var result = {
                "tasks": [],
                "selectedRow": 0,
                "deletedTaskIds": [],
                "resources": [
                    { "id": "tmp_1", "name": "Resource 1" },
                    { "id": "tmp_2", "name": "Resource 2" },
                    { "id": "tmp_3", "name": "Resource 3" },
                    { "id": "tmp_4", "name": "Resource 4" }
                ],
                "roles": [
                    { "id": "tmp_1", "name": "Project Manager" },
                    { "id": "tmp_2", "name": "Worker" },
                    { "id": "tmp_3", "name": "Stakeholder" },
                    { "id": "tmp_4", "name": "Customer" }
                ],
                "canWrite": true,
                "canDelete": true,
                "canWriteOnParent": true,
                "canAdd": true
            };
            var canEdit = !this._metadata.hasOwnProperty("ReadOnly");
            result.canWrite = canEdit;
            result.canDelete = canEdit;
            result.canWriteOnParent = canEdit;
            result.canAdd = canEdit;
            var hasData = this._listView.getRowCount() > 0;
            if (hasData) {
                var tasks = GanttTaskConvert.getTasksFromListViewToGanttChart(this._listView, this._ganttListViewInfo);
                tasks.forEach(function (task) {
                    task.canWrite = canEdit;
                    task.canAdd = canEdit;
                    task.canDelete = canEdit;
                    task.canAddIssue = canEdit;
                });
                result.tasks = tasks;
            }
            return result;
        };
        GanttCellType.prototype.onLoad = function () {
            this.initializeProperties();
        };
        GanttCellType.prototype.initializeProperties = function () {
            var _this = this;
            var GanttCellTypeData = this.CellElement.CellType;
            this._metadata = GanttCellTypeData;
            this._ganttListViewInfo = this._metadata.GanttListViewInfo;
            this._listViewName = this._ganttListViewInfo.ListViewName;
            this._ganttTaskSetColInfo = this._ganttListViewInfo.GanttTaskSetColInfo;
            this._listViewBase = Forguncy.ListviewBase.getListview(this._listViewName, this.runTimePageName);
            this._listView = Forguncy.Page.getListView(this._listViewName, false);
            ListViewSelectionChangedCapture.regist(this._listView, function () {
                _this._loopInvoker.invokeable = true;
            });
            if (this._ganttObj == null) {
                this._ganttObj = new GanttMaster();
                var showButtonBar = this._metadata.hasOwnProperty("ShowButtonBar") ? this._metadata.ShowButtonBar : false;
                this._ganttObj.styleSettings = {
                    showButtonBar: showButtonBar
                };
                this._ganttObj.set100OnClose = true;
                this._ganttObj.shrinkParent = true;
                this._ganttObj.hasSetCommands = this._metadata.TaskCommandList ? this._metadata.TaskCommandList.length > 0 : false;
                this._ganttObj.ganttTaskSetColInfo = this._metadata.GanttListViewInfo.GanttTaskSetColInfo;
                this._ganttObj.setCalendarHolidays(GanttCalendarConvert.getHolidaysFromTableToGanttChart(this._metadata.GanttCalendarInfo, this.getFormulaCalcContext()));
                this._ganttObj.init(this._container);
                delete this._ganttObj.gantt.zoom;
                this._ganttObj.checkpoint();
                this._ganttObj.bindTaskRowClickEvent = function (task) {
                    var rowIndex = ListViewHelper.getRowIndex(_this._listView, _this._ganttTaskSetColInfo.IdCol, task.id);
                    if (!Utilities.isEmpty(rowIndex) && rowIndex >= 0) {
                        _this._listView.selectRow(rowIndex);
                    }
                };
                this._ganttObj.bindTaskRowDblClickEvent = function (task) {
                    var taskCommandList = GanttCellTypeData.TaskCommandList;
                    _this.executeCommand(taskCommandList);
                };
                this._ganttObj.bindSaveGanttDataEvent = function (task) {
                    _this.saveGanttDataToListView();
                    Forguncy.UpdateListviewCommand.updateListview(_this._listViewBase, function () {
                        Forguncy.NormalCellBindingManager.reloadData(_this._listViewBase.getDataTableName(), true);
                        Forguncy.ForguncyData.getRelatedTableWithForeignKey(_this._listViewBase.getDataTableName()).forEach(function (table) {
                            Forguncy.NormalCellBindingManager.reloadData(table, true);
                        });
                    });
                };
            }
            this._loopInvoker.start(function () {
                _this.refresh(true);
            });
        };
        GanttCellType.prototype.refresh = function (shouldCommitValue) {
            var _this = this;
            window.requestAnimationFrame(function () {
                if (_this._hasDestroyed) {
                    return;
                }
                var project = _this.getGanttData();
                if (!project.canWrite) {
                    $(".ganttButtonBar button.requireWrite").attr("disabled", "true");
                }
                _this._ganttObj.loadProject(project);
                if (shouldCommitValue) {
                    _this.commitValue();
                }
            });
        };
        GanttCellType.prototype.disable = function () {
            $(".ganttButtonBar button.requireWrite").attr("disabled", "true");
        };
        GanttCellType.prototype.enable = function () {
            $(".ganttButtonBar button.requireWrite").attr("disabled", "false");
        };
        GanttCellType.prototype.destroy = function () {
            this._loopInvoker.invokeable = false;
            this._hasDestroyed = true;
            _super.prototype.destroy.call(this);
        };
        GanttCellType.prototype.saveGanttDataToListView = function () {
            var ganttData = this._ganttObj.saveProject();
            var oldTasks = GanttTaskConvert.getTasksFromListViewToGanttChart(this._listView, this._ganttListViewInfo);
            var newTasks = GanttTaskConvert.getTasksFromGanttChartToListView(ganttData, this._ganttListViewInfo);
            var editRows = [];
            var addRows = [];
            var deleteRows = [];
            var defaultIdCol = GanttTaskConvert.GanntTaskRequiredColInfo.IdCol;
            var oldTaskIds = oldTasks.map(function (oldTask) { return oldTask[defaultIdCol]; });
            var setIdCol = this._ganttTaskSetColInfo.IdCol;
            var newTaskIds = newTasks.map(function (newTask) { return newTask[setIdCol]; });
            newTasks.forEach(function (newTask) {
                var idValue = newTask[setIdCol];
                var isAdd = oldTaskIds.indexOf(idValue) === -1;
                if (isAdd) {
                    addRows.push(newTask);
                }
                else {
                    editRows.push({
                        primaryKey: {
                            idCol: setIdCol,
                            idValue: idValue
                        },
                        values: newTask
                    });
                }
            });
            oldTasks.forEach(function (oldTask) {
                var idValue = oldTask[defaultIdCol];
                var isDelete = newTaskIds.indexOf(idValue) === -1;
                if (isDelete) {
                    deleteRows.push({
                        idCol: setIdCol,
                        idValue: idValue
                    });
                }
            });
            var callback = function () { };
            var errorCallback = function () { };
            var ModifyData = {
                editRows: editRows,
                addRows: addRows,
                deleteRows: deleteRows
            };
            ListViewHelper.modifyRows(this._listView, ModifyData);
        };
        return GanttCellType;
    }(Forguncy.Plugin.CellTypeBase));
    Gantt.GanttCellType = GanttCellType;
    var GanttTaskConvert = (function () {
        function GanttTaskConvert() {
        }
        GanttTaskConvert.getTasksFromListViewToGanttChart = function (listView, ganttListViewInfo) {
            var _this = this;
            var rowsData = this.getRowsData(listView);
            var mergedColumnInfos = listView.getMergedColumnInfos();
            var columnNameWithIndex = this.getColumnNameWithIndex(mergedColumnInfos);
            var tasks = rowsData.map(function (row) {
                var values = row.Values;
                var task = _this.creatTaskFromListViewToGanttChart(values, columnNameWithIndex, ganttListViewInfo);
                return task;
            });
            tasks.sort(function (a, b) {
                return (a.order - b.order);
            });
            return tasks;
        };
        GanttTaskConvert.getTasksFromGanttChartToListView = function (ganttData, ganttListViewInfo) {
            var _this = this;
            var newTasks = ganttData.tasks;
            newTasks.forEach(function (task, index) {
                task.order = index + 1;
            });
            var tasks = newTasks.map(function (oldTask) {
                var task = _this.creatTaskFromGanttChartToListView(oldTask, ganttListViewInfo);
                return task;
            });
            return tasks;
        };
        GanttTaskConvert.creatTaskFromListViewToGanttChart = function (values, columnNameWithIndex, ganttListViewInfo) {
            var _this = this;
            var ganttTaskSetColInfo = ganttListViewInfo.GanttTaskSetColInfo;
            var task = {};
            Object.keys(this.GanntTaskRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                var defaultColName = _this.GanntTaskRequiredColInfo[col];
                var index = columnNameWithIndex[setColName];
                var value = values[index];
                task[defaultColName] = _this.formatTaskValueFromListViewToGanttChart(value, col, ganttListViewInfo);
            }));
            Object.keys(this.GanntTaskNotRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                if (!Utilities.isEmpty(setColName)) {
                    var defaultColName = _this.GanntTaskNotRequiredColInfo[col];
                    var index = columnNameWithIndex[setColName];
                    var value = values[index];
                    task[defaultColName] = _this.formatTaskValueFromListViewToGanttChart(value, col, ganttListViewInfo);
                }
            }));
            this.setTaskCollapsedFromListViewToGanttChart(task, ganttListViewInfo, ganttTaskSetColInfo);
            return task;
        };
        GanttTaskConvert.creatTaskFromGanttChartToListView = function (tasks, ganttListViewInfo) {
            var _this = this;
            var ganttTaskSetColInfo = ganttListViewInfo.GanttTaskSetColInfo;
            var task = {};
            Object.keys(this.GanntTaskRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                var defaultColName = _this.GanntTaskRequiredColInfo[col];
                var value = tasks[defaultColName];
                task[setColName] = _this.formatTaskValueFromGanttChartToListView(value, col, ganttListViewInfo);
            }));
            Object.keys(this.GanntTaskNotRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                if (!Utilities.isEmpty(setColName)) {
                    var defaultColName = _this.GanntTaskNotRequiredColInfo[col];
                    var value = tasks[defaultColName];
                    task[setColName] = _this.formatTaskValueFromGanttChartToListView(value, col, ganttListViewInfo);
                }
            }));
            return task;
        };
        GanttTaskConvert.getRowsData = function (listView) {
            var rowsData = [];
            var rowCount = listView.getRowCount();
            if (rowCount === 0) {
                return [];
            }
            var columnInfos = listView.getMergedColumnInfos();
            var mergedColumnCount = columnInfos.length;
            for (var rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                var values = [];
                for (var colIndex = 0; colIndex < mergedColumnCount; colIndex++) {
                    var value = listView.getValue(rowIndex, colIndex);
                    values.push(Utilities.isEmpty(value) ? null : value);
                }
                rowsData.push({
                    RowIndex: rowIndex,
                    Values: values
                });
            }
            return rowsData;
        };
        GanttTaskConvert.getColumnNameWithIndex = function (mergedColumnInfos) {
            var columnNamesWithIndex = {};
            for (var i = 0; i < mergedColumnInfos.length; i++) {
                var columnName = mergedColumnInfos[i].ColumnName;
                if (Utilities.isEmpty(columnName)) {
                    continue;
                }
                columnNamesWithIndex[columnName] = i;
            }
            return columnNamesWithIndex;
        };
        GanttTaskConvert.formatTaskValueFromListViewToGanttChart = function (value, defaultColName, ganttListViewInfo) {
            switch (defaultColName) {
                case "IdCol": return value;
                case "OrderCol": return parseInt(value);
                case "LevelCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "NameCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "DependsCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "StartCol": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "DurationCol": return Utilities.isEmpty(value) ? 2 : parseInt(value);
                case "ProgressCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "DescriptionCol": return Utilities.isEmpty(value) ? "" : value;
                case "CodeCol": return Utilities.isEmpty(value) ? "" : value;
                case "StartIsMilestoneCol": return Boolean(value);
                case "EndIsMilestoneCol": return Boolean(value);
                case "PlanStartCol": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "PlanDurationCol": return Utilities.isEmpty(value) ? 2 : parseInt(value);
                case "AssigsCol": return Utilities.isEmpty(value) ? "" : value;
                case "CollapsedCol": return Boolean(value);
                case "StatusCol": return Utilities.isEmpty(value) || Utilities.isEmpty(ganttListViewInfo.GanttStatusSetInfo) ? "" : this.formatTaskStatusValueFromListViewToGanttChart(value, ganttListViewInfo.GanttStatusSetInfo);
                case "CanWriteCol": return Boolean(value);
                case "CanAddCol": return Boolean(value);
                case "CanDeleteCol": return Boolean(value);
                case "CanAddIssueCol": return Boolean(value);
                default: return value;
            }
        };
        GanttTaskConvert.formatTaskValueFromGanttChartToListView = function (value, defaultColName, ganttListViewInfo) {
            switch (defaultColName) {
                case "IdCol": return value;
                case "OrderCol": return parseInt(value);
                case "LevelCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "NameCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "DependsCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "StartCol": return Utilities.isEmpty(value) ? Forguncy.ConvertDateToOADate(new Date()) : Forguncy.ConvertDateToOADate(new Date(value));
                case "DurationCol": return Utilities.isEmpty(value) ? 2 : parseInt(value);
                case "ProgressCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "DescriptionCol": return Utilities.isEmpty(value) ? "" : value;
                case "CodeCol": return Utilities.isEmpty(value) ? "" : value;
                case "StartIsMilestoneCol": return Boolean(value);
                case "EndIsMilestoneCol": return Boolean(value);
                case "PlanStartCol": return Utilities.isEmpty(value) ? Forguncy.ConvertDateToOADate(new Date()) : Forguncy.ConvertDateToOADate(new Date(value));
                case "PlanDurationCol": return Utilities.isEmpty(value) ? 2 : parseInt(value);
                case "AssigsCol": return Utilities.isEmpty(value) ? "" : value;
                case "CollapsedCol": return Boolean(value);
                case "StatusCol": return Utilities.isEmpty(value) || Utilities.isEmpty(ganttListViewInfo.GanttStatusSetInfo) ? "" : this.formatTaskStatusValueFromGanttChartToListView(value, ganttListViewInfo.GanttStatusSetInfo);
                case "CanWriteCol": return Boolean(value);
                case "CanAddCol": return Boolean(value);
                case "CanDeleteCol": return Boolean(value);
                case "CanAddIssueCol": return Boolean(value);
                default: return value;
            }
        };
        GanttTaskConvert.formatTaskStatusValueFromListViewToGanttChart = function (value, ganttStatusSetInfo) {
            var setInfo = Object.keys(ganttStatusSetInfo);
            for (var i = 0; i < setInfo.length; i++) {
                var key = setInfo[i];
                var setValue = ganttStatusSetInfo[key];
                if (setValue === value) {
                    var defaultValue = this.GanntStatusDefaultInfo[key];
                    return defaultValue;
                }
            }
        };
        GanttTaskConvert.formatTaskStatusValueFromGanttChartToListView = function (value, ganttStatusSetInfo) {
            var defaultInfo = Object.keys(this.GanntStatusDefaultInfo);
            for (var i = 0; i < defaultInfo.length; i++) {
                var key = defaultInfo[i];
                var defaultValue = this.GanntStatusDefaultInfo[key];
                if (defaultValue === value) {
                    var setValue = ganttStatusSetInfo[key];
                    return setValue;
                }
            }
        };
        GanttTaskConvert.setTaskCollapsedFromListViewToGanttChart = function (task, ganttListViewInfo, ganttTaskSetColInfo) {
            var ganttCollapsedSetLevel = ganttListViewInfo.GanttCollapsedSetLevel;
            var setCollapsedColName = ganttTaskSetColInfo.CollapsedCol;
            var defaultCollapsedColName = this.GanntTaskNotRequiredColInfo.CollapsedCol;
            if (Utilities.isEmpty(setCollapsedColName) && ganttCollapsedSetLevel > 0) {
                task[defaultCollapsedColName] = task.level >= ganttCollapsedSetLevel;
            }
        };
        GanttTaskConvert.GanntTaskRequiredColInfo = {
            IdCol: "id",
            OrderCol: "order",
            LevelCol: "level",
            NameCol: "name",
            DependsCol: "depends",
            StartCol: "start",
            DurationCol: "duration"
        };
        GanttTaskConvert.GanntTaskNotRequiredColInfo = {
            DescriptionCol: "description",
            CodeCol: "code",
            ProgressCol: "progress",
            StartIsMilestoneCol: "startIsMilestone",
            EndIsMilestoneCol: "endIsMilestone",
            PlanStartCol: "planStart",
            PlanDurationCol: "planDuration",
            AssigsCol: "assigs",
            CollapsedCol: "collapsed",
            StatusCol: "status",
            CanWriteCol: "canWirte",
            CanAddCol: "canAdd",
            CanDeleteCol: "canDelete",
            CanAddIssueCol: "canAdd",
        };
        GanttTaskConvert.GanntStatusDefaultInfo = {
            WaitingCol: "STATUS_WAITING",
            ActiveCol: "STATUS_ACTIVE",
            CompletedCol: "STATUS_DONE",
            SuspendedCol: "STATUS_SUSPENDED",
            FailedCol: "STATUS_FAILED"
        };
        return GanttTaskConvert;
    }());
    var GanttCalendarConvert = (function () {
        function GanttCalendarConvert() {
        }
        GanttCalendarConvert.getColumnsFromColInfo = function (setColInfo) {
            return Object.keys(this.GanntCalendarColInfo).map(function (col) {
                return setColInfo[col];
            });
        };
        GanttCalendarConvert.getHolidaysFromTableToGanttChart = function (ganttCalendarInfo, formulaCalcContext) {
            var _this = this;
            if (Utilities.isEmpty(ganttCalendarInfo)) {
                return [];
            }
            var tableName = ganttCalendarInfo.TableName || "节假日配置";
            var ganttCalendarSetColInfo = ganttCalendarInfo.GanttCalendarSetColInfo;
            var columns = this.getColumnsFromColInfo(ganttCalendarSetColInfo);
            var queryCondition = ganttCalendarInfo.QueryCondition;
            var params = {
                TableName: tableName,
                Columns: columns,
                QueryCondition: queryCondition,
                QueryPolicy: {
                    Distinct: true,
                    QueryNullPolicy: Forguncy.QueryNullPolicy.QueryAllItemsWhenValueIsNull,
                    IgnoreCache: false
                },
                SortCondition: null
            };
            var rowsData = [];
            Forguncy.getTableDataByCondition(params, formulaCalcContext, function (data) {
                if (!Utilities.isEmpty(data)) {
                    rowsData = data;
                }
            }, false);
            var holidays = rowsData.map(function (row) {
                var date = row[ganttCalendarSetColInfo.DateCol];
                var isHoliday = row[ganttCalendarSetColInfo.IsHolidayCol];
                var holiday = {
                    date: _this.formatHolidayValueFromTableToGanttChart(date, 'date'),
                    isHoliday: _this.formatHolidayValueFromTableToGanttChart(isHoliday, 'isHoliday')
                };
                return holiday;
            });
            return holidays;
        };
        GanttCalendarConvert.formatHolidayValueFromTableToGanttChart = function (value, defaultColName) {
            switch (defaultColName) {
                case "date": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "isHoliday": return Boolean(value);
                default: return value;
            }
        };
        GanttCalendarConvert.GanntCalendarColInfo = {
            DateCol: "date",
            IsHolidayCol: "isHoliday"
        };
        return GanttCalendarConvert;
    }());
    var LoopInvoker = (function () {
        function LoopInvoker() {
            this.interval = 50;
        }
        LoopInvoker.prototype.start = function (func, invokeable) {
            var _this = this;
            if (invokeable === void 0) { invokeable = false; }
            this.invokeable = invokeable;
            setInterval(function () {
                if (_this.invokeable) {
                    _this.invokeable = false;
                    func && func();
                }
            }, this.interval);
        };
        return LoopInvoker;
    }());
    var ListViewSelectionChangedCapture = (function () {
        function ListViewSelectionChangedCapture() {
        }
        ListViewSelectionChangedCapture.regist = function (listView, notify) {
            listView.bind(Forguncy.ListViewEvents.Reloaded, function (arg1, arg2) {
                setTimeout(function () {
                    notify && notify();
                }, 0);
            });
            listView.bind(Forguncy.ListViewEvents.ValueChanged, function (arg1, arg2) {
                notify && notify();
            });
        };
        return ListViewSelectionChangedCapture;
    }());
    var ListViewHelper = (function () {
        function ListViewHelper() {
        }
        ListViewHelper.getRowIndex = function (listView, idCol, idValue) {
            var count = listView.getRowCount();
            for (var rowIndex = 0; rowIndex < count; rowIndex++) {
                if (listView.getValue(rowIndex, idCol) == idValue) {
                    return rowIndex;
                }
            }
        };
        ListViewHelper.addRows = function (listView, rows) {
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                listView.addNewRow(row);
            });
        };
        ListViewHelper.editRows = function (listView, rows) {
            var _this = this;
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                var primaryKey = row.primaryKey, values = row.values;
                var idCol = primaryKey.idCol, idValue = primaryKey.idValue;
                var rowIndex = _this.getRowIndex(listView, idCol, idValue);
                Object.keys(values).forEach(function (col) {
                    var value = values[col];
                    listView.setValue(rowIndex, col, value);
                });
            });
        };
        ListViewHelper.deleteRows = function (listView, rows) {
            var _this = this;
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                var idCol = row.idCol, idValue = row.idValue;
                var rowIndex = _this.getRowIndex(listView, idCol, idValue);
                listView.deleteRow(rowIndex);
            });
        };
        ListViewHelper.modifyRows = function (listView, modifyData) {
            var addRows = modifyData.addRows, editRows = modifyData.editRows, deleteRows = modifyData.deleteRows;
            this.addRows(listView, addRows);
            this.editRows(listView, editRows);
            this.deleteRows(listView, deleteRows);
        };
        return ListViewHelper;
    }());
    var Utilities = (function () {
        function Utilities() {
        }
        Utilities.isEmpty = function (value) {
            return value === null || value === undefined || value === "";
        };
        return Utilities;
    }());
})(Gantt || (Gantt = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Gantt.GanttCellType, Gantt", Gantt.GanttCellType);
