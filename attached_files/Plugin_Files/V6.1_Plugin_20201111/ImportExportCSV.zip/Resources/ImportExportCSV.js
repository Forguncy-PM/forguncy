var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ImportExportCSVCommand;
(function (ImportExportCSVCommand) {
    var ImportExportCSV = /** @class */ (function (_super) {
        __extends(ImportExportCSV, _super);
        function ImportExportCSV() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ImportExportCSV.prototype.execute = function () {
            // Get settings
            var commandSettings = this.CommandParam;
            var importExportInfo = commandSettings.ImportExportInfo;
            if (!importExportInfo) {
                return;
            }
            var csvOperation = importExportInfo.CSVOperation;
            var listViewName = importExportInfo.ListViewName;
            var importExportHeaderRow = importExportInfo.ImportExportHeaderRow;
            var importMode = importExportInfo.ImportMode;
            var lineDelimiter = this.calcDelimiterFormula(importExportInfo.LineDelimiter);
            var columnDelimiter = this.calcDelimiterFormula(importExportInfo.ColumnDelimiter);
            var encodingType = this.evaluateFormula(importExportInfo.EncodingType);
            var columns = importExportInfo.Columns;
            var isAlert = importExportInfo.IsAlert;
            var alertMessage = importExportInfo.AlertMessage;
            var pageID = this.getFormulaCalcContext().PageID;
            var pageInfo = Forguncy.Page.getSubPageInfoByPageID(pageID);
            var listview = pageInfo ? pageInfo.getListView(listViewName) : Forguncy.Page.getListView(listViewName, false);
            var cellLocations = this.getCellLocations(columns);
            if (!listview || cellLocations.length <= 0) {
                return;
            }
            var isPrimaryKeys = columns.map(function (c) {
                return c.IsPrimaryKey;
            });
            var columnNames = importExportHeaderRow ?
                columns.map(function (c) {
                    return c.CSVColumnName.trim();
                }) :
                undefined;
            var csvColumnIndexs = importExportHeaderRow || csvOperation !== CSVOperation.Import ?
                undefined :
                columns.map(function (c) {
                    return c.CSVColumnIndex;
                });
            var alertSuccessMessage = function () {
                if (isAlert) {
                    alert(typeof alertMessage === "string" ? alertMessage : "");
                }
            };
            var columnIndexListInListView = this.getColumnIndexs(listview, cellLocations);
            this.CommandExecutingInfo.suspend = true;
            if (csvOperation === CSVOperation.Import) {
                this.importCSVFile(listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, importMode, lineDelimiter, columnDelimiter, encodingType, isPrimaryKeys, alertSuccessMessage);
            }
            else {
                this.exportCSVFile(listViewName, listview, importExportHeaderRow, columnNames, columnIndexListInListView, lineDelimiter, columnDelimiter);
            }
        };
        ImportExportCSV.prototype.calcDelimiterFormula = function (delimiter) {
            var delimiterStr = this.evaluateFormula(delimiter);
            if (delimiterStr === null || delimiterStr === undefined || delimiterStr === "") {
                return undefined;
            }
            switch (delimiterStr) {
                case "\\t": return "\t";
                case "\\r\\n": return "\r\n";
                case "\\r": return "\r";
                case "\\n": return "\n";
                default: return delimiterStr.toString();
            }
        };
        ImportExportCSV.prototype.getCellLocations = function (columns) {
            var list = [];
            if (columns) {
                for (var i = 0; i < columns.length; i++) {
                    var cell = columns[i].ListViewColumnCell;
                    if (typeof (cell) === "string" && cell.length > 0 && cell[0] === "=") {
                        cell = this.getCellLocation(cell);
                        list.push(cell);
                    }
                    else {
                        list.push(null);
                    }
                }
            }
            return list;
        };
        ImportExportCSV.prototype.getColumnIndexs = function (listview, cellLocations) {
            var columnIndexList = [];
            var columns = listview.getMergedColumnInfos();
            for (var i = 0; i < cellLocations.length; i++) {
                if (cellLocations[i] === null) {
                    columnIndexList.push(-1);
                    continue;
                }
                var columnIndex = cellLocations[i].Column;
                var j = 0;
                for (j = 0; j < columns.length; j++) {
                    if (columns[j].DesignerColumnIndex === columnIndex) {
                        columnIndexList.push(j);
                        break;
                    }
                }
                if (j === columns.length) {
                    columnIndexList.push(-1);
                }
            }
            return columnIndexList;
        };
        ImportExportCSV.prototype.importCSVFile = function (listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, importMode, lineDelimiter, columnDelimiter, encodingType, isPrimaryKeys, alertSuccessMessage) {
            var _this = this;
            if (this.CommandExecutingInfo.eventType === "pageloaded" && this.platformIsChrome()) {
                this.CommandExecutingInfo.suspend = false;
                return;
            }
            var self = this;
            if ($("#importCSVFileInputID").length > 0) {
                $("#importCSVFileInputID").remove();
            }
            var fileInput = $("<input id='importCSVFileInputID' type='file' />");
            fileInput.css("display", "none");
            var accept = ".csv";
            //FORGUNCY-287 [Mobile][Andriod]It prompt "no application to execute the operation" when clicking add button to upload file..
            if (this.isAndroid() && this.isWechatOrQQBrowser()) {
                accept = null;
            }
            // -------------------------------------------------------------------------
            fileInput.attr("accept", accept);
            $("body").append(fileInput);
            $("#importCSVFileInputID").change(function (e) {
                var fileName = e.target.files[0];
                if (!fileName) {
                    self.CommandExecutingInfo.suspend = false;
                    return;
                }
                listview.showLoadingIndicator();
                var reader = new FileReader();
                reader.readAsDataURL(fileName);
                reader.onload = function (evt) {
                    window.Papa.parse(fileName, {
                        header: importExportHeaderRow,
                        //dynamicTyping: true,
                        encoding: encodingType,
                        complete: function (results) {
                            var _a, _b, _c, _d, _e, _f, _g, _h;
                            try {
                                var headers = void 0, headersOfUniformLineBreak = void 0, columnNamesOfUniformLineBreak = void 0;
                                if (importExportHeaderRow) {
                                    headers = (_d = (_c = (_b = (_a = results) === null || _a === void 0 ? void 0 : _a.meta) === null || _b === void 0 ? void 0 : _b.fields) === null || _c === void 0 ? void 0 : _c.map(function (f) { var _a; return (_a = f) === null || _a === void 0 ? void 0 : _a.trim(); }), (_d !== null && _d !== void 0 ? _d : []));
                                    headersOfUniformLineBreak = (_f = (_e = headers) === null || _e === void 0 ? void 0 : _e.map(function (f) { return self.replaceLineBreaks(f); }), (_f !== null && _f !== void 0 ? _f : []));
                                    columnNamesOfUniformLineBreak = (_h = (_g = columnNames) === null || _g === void 0 ? void 0 : _g.map(function (f) { return self.replaceLineBreaks(f); }), (_h !== null && _h !== void 0 ? _h : []));
                                }
                                var checkResult = self.checkImportData(results, headersOfUniformLineBreak, importExportHeaderRow, columnNamesOfUniformLineBreak);
                                if (!checkResult) {
                                    listview.hiddenLoadingIndicator();
                                    self.CommandExecutingInfo.suspend = false;
                                    return;
                                }
                                var processedColumnNames = self.getProcessedColumnNames(headers, headersOfUniformLineBreak, importExportHeaderRow, columnNamesOfUniformLineBreak);
                                var data = self.getImportData(results.data, importExportHeaderRow, processedColumnNames, csvColumnIndexs, columnIndexListInListView);
                                var baseColumns = self.getListviewPrimaryKeyIndexes(columnIndexListInListView, isPrimaryKeys);
                                listview.importData(data, true, importMode, baseColumns, columnIndexListInListView, function (importResult) {
                                    if (importResult.Success) {
                                        alertSuccessMessage();
                                    }
                                    else {
                                        switch (importResult.ErrorInfos[0].ErrorType) {
                                            case Forguncy.ImportError.ExistSameKeys:
                                                alert(self.getRS().Error_ExistSameKeys);
                                                break;
                                            case Forguncy.ImportError.ValidateError:
                                                self.alertErrorMessage(importResult.ErrorInfos[0].ErrorData, importExportHeaderRow);
                                                break;
                                            default:
                                                break;
                                        }
                                    }
                                    listview.hiddenLoadingIndicator();
                                    self.CommandExecutingInfo.suspend = false;
                                });
                            }
                            catch (_j) {
                                listview.hiddenLoadingIndicator();
                                self.CommandExecutingInfo.suspend = false;
                            }
                        },
                        delimiter: columnDelimiter,
                        newline: lineDelimiter,
                        error: function () {
                            self.CommandExecutingInfo.suspend = false;
                        }
                    });
                };
            }).one("click", function (e) {
                if (_this.platformIsChrome()) {
                    $(document).one("focusin", function () {
                        setTimeout(function () {
                            if ($("#importCSVFileInputID").val().length === 0) {
                                _this.CommandExecutingInfo.suspend = false;
                                /* that's the point of cancel,   */
                            }
                        }, 325);
                    });
                }
                else {
                    setTimeout(function () {
                        $(document).one("mousemove focusin", function () {
                            if (e.target.files.length === 0) {
                                _this.CommandExecutingInfo.suspend = false;
                                /* that's the point of cancel,   */
                            }
                        });
                    }, 1); /* 1 is enough as we just need to delay until first available tick */
                }
            });
            if (!Forguncy.ForguncyData.IsAutoTest) {
                $("#importCSVFileInputID").click();
            }
        };
        ImportExportCSV.prototype.getProcessedColumnNames = function (headers, headersOfUniformNewline, importExportHeaderRow, columnNames) {
            var _a;
            if (!importExportHeaderRow) {
                return columnNames;
            }
            return _a = columnNames.map(function (val) { return headers[headersOfUniformNewline.indexOf(val)]; }), (_a !== null && _a !== void 0 ? _a : []);
        };
        ImportExportCSV.prototype.checkImportData = function (result, headers, importExportHeaderRow, columnNames) {
            var success = this.checkHeaderRowInImportData(headers, importExportHeaderRow, columnNames);
            return success;
        };
        ImportExportCSV.prototype.checkHeaderRowInImportData = function (headers, importExportHeaderRow, columnNames) {
            if (!importExportHeaderRow) {
                return true;
            }
            var noFindColumns = columnNames.filter(function (c) { return headers.indexOf(c) === -1; });
            if (noFindColumns.length > 0) {
                alert(this.getRS().Error_ColumnNameNotMatch.replace("{0}", noFindColumns.join(",")));
                return false;
            }
            return true;
        };
        ImportExportCSV.prototype.replaceLineBreaks = function (str) {
            if (str === null || str === undefined || str === "") {
                return "";
            }
            return str.replace(/\r\n|\r/g, "\n");
        };
        ImportExportCSV.prototype.getImportData = function (csvData, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView) {
            var _this = this;
            //remove empty rows in the end.
            csvData = this.removeEmptyRowsInTheEnd(csvData);
            var data = csvData.map(function (row) {
                return _this.getNewRowData(row, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView);
            });
            return data;
        };
        ImportExportCSV.prototype.removeEmptyRowsInTheEnd = function (data) {
            var invalidRowCount = 0;
            for (var i = data.length - 1; i >= 0; i--) {
                var newRowData = data[i];
                if (!newRowData || newRowData.length === 0) {
                    invalidRowCount++;
                    continue;
                }
                var isEmptyRow = true;
                for (var key in newRowData) {
                    if (newRowData[key] !== undefined && newRowData[key] !== null && newRowData[key] !== "") {
                        isEmptyRow = false;
                        break;
                    }
                }
                if (isEmptyRow) {
                    invalidRowCount++;
                }
                else {
                    break;
                }
            }
            if (invalidRowCount > 0) {
                var validRowCount = data.length - invalidRowCount;
                data = data.slice(0, validRowCount);
            }
            return data;
        };
        ImportExportCSV.prototype.getListviewPrimaryKeyIndexes = function (columnIndexListInListView, isPrimaryKeys) {
            return isPrimaryKeys
                .map(function (isPrimaryKey, index) { return isPrimaryKey ? columnIndexListInListView[index] : -1; })
                .filter(function (col) { return col !== -1; });
        };
        ImportExportCSV.prototype.getRS = function () {
            var culture = Forguncy.RS.Culture;
            if (culture === 'CN') {
                return window.RS_CN;
            }
            else if (culture === 'JA') {
                return window.RS_JP;
            }
            else if (culture === 'KR') {
                return window.RS_KO;
            }
            return window.RS_EN;
        };
        ImportExportCSV.prototype.getNewRowData = function (rowData, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView) {
            var newRowData = [];
            for (var i = 0; i < columnIndexListInListView.length; i++) {
                var c = columnIndexListInListView[i];
                if (c === -1) {
                    continue;
                }
                var cNameOrIndex = importExportHeaderRow === true ? columnNames[i] : csvColumnIndexs[i] - 1;
                var tempValue = rowData[cNameOrIndex];
                if (tempValue === null || tempValue === undefined || tempValue === "") {
                    tempValue = null;
                }
                newRowData[c] = tempValue;
            }
            return newRowData;
        };
        ImportExportCSV.prototype.alertErrorMessage = function (errorData, importExportHeaderRow) {
            var csvRowIndex = errorData.RowIndex + 1;
            if (importExportHeaderRow) {
                csvRowIndex += 1;
            }
            alert(this.getRS().Error_DetailInfo.replace("{0}", errorData.CellValue).replace("{1}", csvRowIndex).replace("{2}", errorData.Message));
        };
        ImportExportCSV.prototype.isAndroid = function () {
            var userAgent = navigator.userAgent.toLowerCase();
            return userAgent.indexOf("android") > -1 || userAgent.indexOf("adr") > -1;
        };
        ImportExportCSV.prototype.isWechatOrQQBrowser = function () {
            var userAgent = navigator.userAgent.toLowerCase();
            return userAgent.indexOf("micromessenger") > -1 || userAgent.indexOf("qqbrowser") > -1;
        };
        ImportExportCSV.prototype.exportCSVFile = function (csvFileName, listview, importExportHeaderRow, columnNames, columnIndexListInListView, lineDelimiter, columnDelimiter) {
            if (this.isWechatOrQQBrowser()) {
                alert("请在浏览器中打开该网页后再下载。");
                this.CommandExecutingInfo.suspend = false;
                return;
            }
            var data = [];
            var rowCount = listview.getRowCount();
            for (var r = 0; r < rowCount; r++) {
                var rowData = [];
                for (var i = 0; i < columnIndexListInListView.length; i++) {
                    var c = columnIndexListInListView[i];
                    var val = c === -1 ? null : listview.getText(r, c);
                    rowData.push(val);
                }
                data.push(rowData);
            }
            var csv = window.Papa.unparse({
                fields: importExportHeaderRow ? columnNames : undefined,
                data: data
            }, { delimiter: columnDelimiter, newline: lineDelimiter });
            //download csv file
            var fileName = csvFileName + ".csv";
            var BOM = "\uFEFF";
            var blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
            if (window.navigator.msSaveOrOpenBlob) { // IE hack; see http://msdn.microsoft.com/en-us/library/ie/hh779016.aspx
                window.navigator.msSaveBlob(blob, fileName);
            }
            else {
                var a = window.document.createElement("a");
                a.href = window.URL.createObjectURL(blob);
                a.download = fileName;
                document.body.appendChild(a);
                a.click(); // IE: "Access is denied"; see: https://connect.microsoft.com/IE/feedback/details/797361/ie-10-treats-blob-url-as-cross-origin-and-denies-access
                document.body.removeChild(a);
            }
            this.CommandExecutingInfo.suspend = false;
        };
        ImportExportCSV.prototype.platformIsChrome = function () {
            return !this.platformIsOldEdge() && navigator.userAgent.indexOf("Chrome/") !== -1;
        };
        ImportExportCSV.prototype.platformIsOldEdge = function () {
            return navigator.userAgent.indexOf("Edge/") !== -1;
        };
        return ImportExportCSV;
    }(Forguncy.Plugin.CommandBase));
    ImportExportCSVCommand.ImportExportCSV = ImportExportCSV;
    var CSVOperation;
    (function (CSVOperation) {
        CSVOperation[CSVOperation["Import"] = 0] = "Import";
        CSVOperation[CSVOperation["Export"] = 1] = "Export";
    })(CSVOperation || (CSVOperation = {}));
})(ImportExportCSVCommand || (ImportExportCSVCommand = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CommandFactory.registerCommand("ImportExportCSV.ImportExportCSV, ImportExportCSV", ImportExportCSVCommand.ImportExportCSV);
