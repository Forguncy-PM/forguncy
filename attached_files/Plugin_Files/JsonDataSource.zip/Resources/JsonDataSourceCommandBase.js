var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var JsonDataSource;
(function (JsonDataSource) {
    var JsonDataSourceCommandBase = /** @class */ (function (_super) {
        __extends(JsonDataSourceCommandBase, _super);
        function JsonDataSourceCommandBase() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        JsonDataSourceCommandBase.prototype.getJsonData = function (commandParam) {
            var sourceCell = commandParam.SourceCell;
            if (sourceCell.length > 0 && sourceCell[0] !== "=") {
                sourceCell = "=" + sourceCell;
            }
            var cell = this.evaluateFormula(sourceCell);
            var data = this.parseJson(cell, commandParam);
            return data;
        };
        JsonDataSourceCommandBase.prototype.getCell = function (cellStr) {
            var cellInfo = this.getCellLocationOrColumnName(cellStr);
            var cell = typeof (cellInfo) === "string" /* StaticStrings.string */ ?
                Forguncy.Page.getCell(cellInfo) :
                Forguncy.Page.getCellByLocation(cellInfo);
            return cell;
        };
        JsonDataSourceCommandBase.prototype.getCellLocationOrColumnName = function (cell) {
            var isFormula = typeof (cell) === "string" /* StaticStrings.string */ && cell.length > 0 && cell[0] === "=";
            if (isFormula) {
                return this.getCellLocation(cell);
            }
            else {
                return cell;
            }
        };
        JsonDataSourceCommandBase.prototype.parseJson = function (jsonData, commandParam) {
            var data;
            if (typeof jsonData === "string" /* StaticStrings.string */) {
                try {
                    data = JSON.parse(jsonData);
                }
                catch (_a) {
                    throw new Error(JsonDataSource.Common.format(this.getPluginResource("Error_InvalidJson"), jsonData));
                }
            }
            else {
                data = jsonData;
            }
            if (!JsonDataSource.Common.IsEmpty(commandParam.JsonPath)) {
                data = this.getPropertyValue(data, commandParam.JsonPath);
            }
            return data;
        };
        JsonDataSourceCommandBase.prototype.getPropertyValue = function (data, propertyName) {
            if (JsonDataSource.Common.IsEmpty(propertyName)) {
                return data;
            }
            var parts = propertyName.split("." /* StaticStrings.jsonPathSeparator */);
            for (var i = 0; i < parts.length; i++) {
                if (JsonDataSource.Common.IsEmpty(data)) {
                    return null;
                }
                if (Array.isArray(data) && data.length > 0) {
                    data = data[0];
                }
                data = data[parts[i].trim()];
            }
            return data;
        };
        return JsonDataSourceCommandBase;
    }(Forguncy.Plugin.CommandBase));
    JsonDataSource.JsonDataSourceCommandBase = JsonDataSourceCommandBase;
})(JsonDataSource || (JsonDataSource = {}));
