var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var JsonDataSource;
(function (JsonDataSource) {
    var ImportJsonDataToListviewCommand = /** @class */ (function (_super) {
        __extends(ImportJsonDataToListviewCommand, _super);
        function ImportJsonDataToListviewCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ImportJsonDataToListviewCommand.prototype.execute = function () {
            var commandParam = this.CommandParam;
            try {
                var jsonData = this.getJsonData(commandParam);
                this.importData(jsonData, commandParam);
            }
            catch (e) {
                alert(e.message);
            }
        };
        ImportJsonDataToListviewCommand.prototype.getJsonData = function (commandParam) {
            var data = _super.prototype.getJsonData.call(this, commandParam);
            if (JsonDataSource.Common.IsEmpty(data)) {
                data = [];
            }
            if (!Array.isArray(data)) {
                data = [data];
            }
            return data;
        };
        ImportJsonDataToListviewCommand.prototype.importData = function (data, commandSettings) {
            var _this = this;
            var listview = this.getListview(commandSettings.Listview);
            if (!listview) {
                return;
            }
            var columnsInfo = this.getColumnsInfo(listview, commandSettings.ListviewColumnInfos);
            var columnIndexs = columnsInfo.map(function (c) { return c.ColumnIndex; });
            var listviewData = this.getListveiwData(data, columnsInfo);
            this.CommandExecutingInfo.suspend = true;
            listview.importData(listviewData, true, Forguncy.ImportMode.Replace, [], columnIndexs, function (importResult) {
                _this.CommandExecutingInfo.suspend = false;
                if (importResult.Success) {
                    return;
                }
                var errors = importResult.ErrorInfos
                    .filter(function (e) { return e.ErrorType === Forguncy.ImportError.ValidateError; })
                    .map(function (e) { return _this.getErrorMessage(e.ErrorData); });
                if (errors.length === 0) {
                    return;
                }
                alert(errors.join("\r\n"));
            });
        };
        ImportJsonDataToListviewCommand.prototype.getErrorMessage = function (errorData) {
            return JsonDataSource.Common.format(this.getPluginResource("Error_DetailInfo"), errorData.CellValue, errorData.RowIndex + 1, errorData.Message);
        };
        ImportJsonDataToListviewCommand.prototype.getListview = function (listviewName) {
            var pageID = this.getFormulaCalcContext().PageID;
            var pageInfo = Forguncy.Page.getSubPageInfoByPageID(pageID);
            var listview = pageInfo ? pageInfo.getListView(listviewName) : Forguncy.Page.getListView(listviewName, false);
            return listview.getRunTimePageName() === pageID ? listview : null;
        };
        ImportJsonDataToListviewCommand.prototype.getColumnsInfo = function (listview, cells) {
            var _this = this;
            return cells.map(function (c) {
                var cell = _this.getCellLocationOrColumnName(c.ListViewColumnCell);
                return {
                    ColumnIndex: _this.getColumnIndex(listview, cell),
                    PropertyName: c.PropertyName
                };
            });
        };
        ImportJsonDataToListviewCommand.prototype.getColumnIndex = function (listview, cell) {
            var columns = listview.getMergedColumnInfos();
            if (!cell) {
                return -1;
            }
            else if (typeof (cell) === "string" /* StaticStrings.string */) {
                for (var i = 0; i < columns.length; i++) {
                    if (columns[i].ColumnName === cell) {
                        return i;
                    }
                }
                return -1;
            }
            else {
                for (var i = 0; i < columns.length; i++) {
                    if (columns[i].DesignerColumnIndex === cell.Column) {
                        return i;
                    }
                }
                return -1;
            }
        };
        ImportJsonDataToListviewCommand.prototype.getListveiwData = function (data, columnsInfo) {
            var _this = this;
            if (!data) {
                return [];
            }
            var emptyPropertyGUID = "E0A87A67-EFF5-4D44-9981-E8BD1DE6384E";
            var dic = {};
            columnsInfo.forEach(function (c) {
                var propertyName = JsonDataSource.Common.IsEmpty(c.PropertyName) ? emptyPropertyGUID : c.PropertyName;
                if (!dic[propertyName]) {
                    dic[propertyName] = [];
                }
                dic[propertyName].push(c.ColumnIndex);
            });
            return data.map(function (row) {
                var rowData = [];
                var _loop_1 = function (colName) {
                    var cols = dic[colName];
                    if (cols) {
                        var realName_1 = colName === emptyPropertyGUID ? null : colName;
                        cols.forEach(function (colIndex) { return rowData[colIndex] = _this.getPropertyValue(row, realName_1); });
                    }
                };
                for (var colName in dic) {
                    _loop_1(colName);
                }
                return rowData;
            });
        };
        return ImportJsonDataToListviewCommand;
    }(JsonDataSource.JsonDataSourceCommandBase));
    JsonDataSource.ImportJsonDataToListviewCommand = ImportJsonDataToListviewCommand;
})(JsonDataSource || (JsonDataSource = {}));
Forguncy.Plugin.CommandFactory.registerCommand("JsonDataSource.ImportJsonDataToListviewCommand, JsonDataSource", JsonDataSource.ImportJsonDataToListviewCommand);
