var JsonDataSource;
(function (JsonDataSource) {
    var RS_JP = {
        Error_InvalidJson: "不正なJSON文字列：{0}"
    };
    var RS_CN = {
        Error_InvalidJson: "非法JSON字符串：{0}"
    };
    var RS_KO = {
        Error_InvalidJson: "Invalid json string: {0}"
    };
    var RS_EN = {
        Error_InvalidJson: "Invalid json string: {0}"
    };
    var RSHelper = /** @class */ (function () {
        function RSHelper() {
        }
        RSHelper.getRS = function () {
            switch (Forguncy.RS.Culture) {
                case "CN" /* Forguncy.ForguncySupportCultures.Chinese */:
                    return RS_CN;
                case "JA" /* Forguncy.ForguncySupportCultures.Japanese */:
                    return RS_JP;
                case "KR" /* Forguncy.ForguncySupportCultures.Korean */:
                    return RS_KO;
                default:
                    return RS_EN;
            }
        };
        return RSHelper;
    }());
    JsonDataSource.RSHelper = RSHelper;
})(JsonDataSource || (JsonDataSource = {}));
