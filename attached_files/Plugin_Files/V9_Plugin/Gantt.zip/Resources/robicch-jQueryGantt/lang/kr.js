// /Plugin/CustomCellTypes/Gantt/Resources/robicch-jQueryGantt/lang/kr.js
GanttMaster.prototype.$lang["kr"] = {
	GridEditor: {
		Tabel: {
			codeNameCol: "코드명",
			nameCol: "이름",
			statusCol: "상태",
			startCol: "시작일",
			endCol: "종료일",
			durationCol: "기간.",
			actualStartCol: "실제 시작일",
			actualEndCol: "실제 종료일",
			actualDurationCol: "실제 기간.",
			dependsCol: "의존.",
			progressCol: "%",
			descriptionCol: "설명",
			assigsCol: "담당자",

			codeNameColTitle: "코드명",
			nameColTitle: "이름",
			statusColTitle: "작업 상태",
			startColTitle: "계획 시작 날짜",
			endColTitle: "계획 종료 날짜",
			durationColTitle: "계획 기간",
			actualStartColTitle: "실제 시작일",
			actualEndColTitle: "실제 종료일",
			actualDurationColTitle: "실제 기간",
			dependsColTitle: "의존",
			progressColTitle: "진행율",
			descriptionColTitle: "설명",
			assigsColTitle: "자원 할당",

			milestoneColTitle: "마일스톤",
			startMilestoneColTitle: "시작일는 마일스톤입니다.",
			endMilestoneColTitle: "종료일은 마일스톤입니다."
		},
		TaskRow: {
			codeNamePlaceholder: "코드명",
			namePlaceholder: "이름",
			defaultRootName: "기본 루트 이름"
		},
		Status: {
			STATUS_ACTIVE: "활성",
			STATUS_DONE: "완료",
			STATUS_FAILED: "실패",
			STATUS_SUSPENDED: "중단됨",
			STATUS_WAITING: "대기 중"
		},
		Error: {
			PLAN_DURATION_VALID: "값은 최소값이 1인 숫자여야 합니다.",
			ACTUAL_DURATION_VALID: "값은 비어 있거나 최소값이 1인 숫자여야 합니다.."
		}
	},
	GridMaster: {
		ButtonBar: {
			addAboveCurrentTask: "작업 위에 삽입",
			addBelowCurrentTask: "작업 아래에 삽입",
			outdentCurrentTask: "작업 내어쓰기",
			indentCurrentTask: "작업 들여쓰기",
			moveUpCurrentTask: "작업 위로 이동",
			moveDownCurrentTask: "작업 아래로 이동",
			deleteFocused: "작업 삭제",
			expandAll: "모든 하위 작업 확장",
			collapseAll: "모든 하위 작업 접기",
			zoomMinus: "축소",
			zoomPlus: "확대",
			timeUnitMinus: "시간 단위 감소",
			timeUnitPlus: "시간 단위 증가",
			toggleShowCriticalPath: "중요한 경로",
			splitterLeft: "스플리터를 왼쪽으로",
			splitterMiddle: "스플리터를 중간으로",
			splitterRight: "스플리터를 오른쪽으로",
			toggleColorByStatus: "상태 색상 전환",
			switchDiaplaySVG: "실제 표시 전환",
			saveGanttData: "저장"
		},
		Custom: {
			msgError: "에러:"
		}
	},
	Error: {
		CANNOT_WRITE: "다음 작업을 변경할 수 있는 권한이 없습니다.",
		CHANGE_OUT_OF_SCOPE: "상위 프로젝트를 업데이트할 수 있는 권한이 없으므로 프로젝트를 업데이트할 수 없습니다.",
		START_IS_MILESTONE: "시작날짜는 마일스톤입니다.",
		END_IS_MILESTONE: "종료날짜는 마일스톤입니다.",
		TASK_HAS_CONSTRAINTS: "작업에 제약이 있음: 선행 작업이 있거나 상위 작업의 첫 번째 하위 작업입니다.",
		GANTT_ERROR_DEPENDS_ON_OPEN_TASK: "오류: 열려 있는 작업에 대한 종속성이 있습니다.",
		GANTT_ERROR_DESCENDANT_OF_CLOSED_TASK: "오류: 닫힌 작업의 하위 항목으로 인해 발생합니다.",
		TASK_HAS_EXTERNAL_DEPS: "이 작업에는 외부 종속성이 있습니다.",
		GANNT_ERROR_LOADING_DATA_TASK_REMOVED: "GANNT_ERROR_LOADING_DATA_TASK_REMOVED",
		CIRCULAR_REFERENCE: "순환 참조.",
		CANNOT_DEPENDS_ON_ANCESTORS: "Cannot depend on ancestors.",
		INVALID_DATE_FORMAT: "삽입된 데이터는 필드 형식에 유효하지 않습니다.",
		GANTT_ERROR_LOADING_DATA_TASK_REMOVED: "데이터를 로드하는 동안 오류가 발생했습니다. 작업이 삭제되었습니다.",
		CANNOT_CLOSE_TASK_IF_OPEN_ISSUE: "열기 문제가 있는 작업을 닫을 수 업습니다.",
		TASK_MOVE_INCONSISTENT_LEVEL: "깊이(depth)가 다른 작업은 교환할 수 없습니다.",
		CANNOT_MOVE_TASK: "CANNOT_MOVE_TASK",
		PLEASE_SAVE_PROJECT: "PLEASE_SAVE_PROJECT",
		GANTT_SEMESTER: "반기",
		GANTT_SEMESTER_SHORT: "s.",
		GANTT_QUARTER: "분기",
		GANTT_QUARTER_SHORT: "q.",
		GANTT_WEEK: "주",
		GANTT_WEEK_SHORT: "w.",
		CANNOT_END_TIME_LESS_THAN_START_TIME: "시작 시간은 종료 시간보다 작을 수 없습니다.",
		TASK_HAS_PERDECESSORS: "작업에 제약이 있음: 선행 작업이 있습니다.",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_EARLY: "작업에는 제약 조건이 있습니다. 상위 작업에는 선행 작업이 있으므로 이 작업의 시작 시간은 상위 작업의 시작 시간보다 빠를 수 없습니다.",
		TASK_PARENT_HAS_PERDECESSORS_START_TIME_MORE: "작업에는 제약 조건이 있습니다. 상위 작업에는 선행 작업이 있으므로 시작 시간이 상위 작업과 동일한 하위 작업이 있어야 합니다.",
		TASK_HAS_SUBTASKS_START_TIME: "작업에는 하위 작업이 있으며 시작 시간은 하위 작업의 가장 빠른 시작 시간에 따라 달라집니다.",
		TASK_HAS_SUBTASKS_END_TIME: "작업에는 하위 작업이 있으며 종료 시간은 하위 작업의 마지막 종료 시간에 따라 달라집니다.",
		CANNOT_ADD_ABOVE_ROOT_TASK: "루트에 동위 항목을 추가할 수 없습니다.",
		CANNOT_OUTDENT_ROOT_TASK: "루트 작업 수준을 내어쓸 수 없습니다.",
		ONLY_CAN_HAVE_ONE_ROOT_TASK: "하나의 루트 작업만 있을 수 있습니다.",
		CANNOT_INDENT_ROOT_TASK: "루트 작업 수준(레벨)을 들여쓸 수 없습니다.",
		INDENT_TASK_MAXIMUM: "최대 범위까지 들여쓴 작업: 이전 작업의 하위 작업으로.",
		CANNOT_MOVE_ROOT_TASK: "루트 작업을 이동할 수 없습니다..",
		TASK_MOVED_TO_TOP_SIBLING: "작업이 동위 항목의 맨 위로 이동했습니다.",
		TASK_MOVED_TO_LAST_SIBLING: "작업이 동위 항목의 마지막으로 이동했습니다.",
		SELECT_THE_TASK_TO_DELETE: "삭제할 작업을 선택하세요.",
		CANNOT_DELETE_ROOT_TASK: "루트 작업을 삭제할 수 없습니다."
	},
	Date: {
		DefaultFormat: "MM/dd/yyyy",
		MonthNames: {
			Jan: "1월",
			Feb: "2월",
			Mar: "3월",
			Apr: "4월",
			May: "5월",
			Jun: "6월",
			Jul: "7월",
			Aug: "8월",
			Sep: "9월",
			Oct: "10월",
			Nov: "11월",
			Dec: "12월"
		},
		MonthAbbreviations: {
			Jan: "1월",
			Feb: "2월",
			Mar: "3월",
			Apr: "4월",
			May: "5월",
			Jun: "6월",
			Jul: "7월",
			Aug: "8월",
			Sep: "9월",
			Oct: "10월",
			Nov: "11월",
			Dec: "12월"
		},
		DayNames: {
			Sun: "일요일",
			Mon: "월요일",
			Tue: "화요일",
			Wed: "수요일",
			Thu: "목요일",
			Fri: "금요일",
			Sat: "토요일"
		},
		DayAbbreviations: {
			Sun: "일요일",
			Mon: "월요일",
			Tue: "화요일",
			Wed: "수요일",
			Thu: "목요일",
			Fri: "금요일",
			Sat: "토요일"
		}
	},
	Zoom: {
		/*
		 * Instead of translating the start-end middle, adjust the position of the word.
		 * The section is a representation of the date, such as using the year-month-day, or month-day-year 
 		 */
		/* start */
		ThreeDays: {
			Row1: "{ startMonth } { startDate } - { dateMonth } { dateDay } { dateYear } ({ whickWeek })",
			Row2: "{ startDay }({ startDate })"
		},
		OneWeek: {
			Row1: "{ startMonth } { startDate } - { dateMonth } { dateDay } { dateYear } ({ whickWeek })",
			Row2: "{ startDay }({ startDate })"
		},
		TwoWeek: {
			Row1: "{ startMonth } { startDate } - { dateMonth } { dateDay } { dateYear } ({ whickWeek })",
			Row2: "{ startDay }"
		},
		OneMonth: {
			Row1: "{ startMonth } { startYear }",
			Row2: "{ startDate }"
		},
		OneQuarter: {
			Row1: "{ startQuarter } { startYear }",
			Row2: "{ startMonth }"
		},
		TwoQuarter: {
			Row1: "{ startQuarter } { startYear }",
			Row2: "{ startMonth }"
		},
		OneYear: {
			Row1: "{ HalfYear } { startYear }",
			Row2: "{ startMonth }"
		},
		TwoYear: {
			Row1: "{ startYear }",
			Row2: "{ HalfYear }"
		},
		/* end */
		WhickWeek: "Week {0}",
		MonthAbbreviationsNumber: {
			0: "1월",
			1: "2월",
			2: "3월",
			3: "4월",
			4: "5월",
			5: "6월",
			6: "7월",
			7: "8월",
			8: "9월",
			9: "10월",
			10: "11월",
			11: "12월"
		},
		DayNamesNumber: {
			0: "일요일",
			1: "월요일",
			2: "화요일",
			3: "수요일",
			4: "목요일",
			5: "금요일",
			6: "토요일"
		},
		DayAbbreviationsNumber: {
			0: "일요일",
			1: "월요일",
			2: "화요일",
			3: "수요일",
			4: "목요일",
			5: "금요일",
			6: "토요일"
		},
		QuarterNumber: {
			0: "1분기",
			1: "2분기",
			2: "3분기",
			3: "4분기"
		},
		HalfYearNumber: {
			0: "상반기",
			1: "하반기"
		}
	}
};
