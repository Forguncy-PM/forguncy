var TabManager;
(function (TabManager) {
    var CellTypeStyleTemplateHelperBase = /** @class */ (function () {
        function CellTypeStyleTemplateHelperBase() {
        }
        CellTypeStyleTemplateHelperBase.prototype.ApplyTemplateStyle = function (styleTemplate, container) {
            if (!styleTemplate) {
                return;
            }
            // 保证container非空
            if (!container) {
                return;
            }
            var key = styleTemplate.Key;
            var templateDomParts = this.MapPartsNameToDom(container);
            for (var i = 0; i < this.TemplateNameParts.length; i++) {
                var partName = this.TemplateNameParts[i];
                var className = CellTypeStyleTemplateUtils
                    .FormatTemplateStyleClassName(this.CellTypeString, key, partName);
                var partDom = templateDomParts[partName];
                if (partDom) {
                    partDom.addClass(className);
                }
            }
            this.OnTemplateStyleApplied(styleTemplate, container);
        };
        CellTypeStyleTemplateHelperBase.prototype.MapPartsNameToDom = function (container) {
            return null;
        };
        CellTypeStyleTemplateHelperBase.prototype.OnTemplateStyleApplied = function (styleTemplate, container) { };
        CellTypeStyleTemplateHelperBase.prototype.Clear = function () { };
        return CellTypeStyleTemplateHelperBase;
    }());
    TabManager.CellTypeStyleTemplateHelperBase = CellTypeStyleTemplateHelperBase;
    var CellTypeStyleTemplateUtils = /** @class */ (function () {
        function CellTypeStyleTemplateUtils() {
        }
        CellTypeStyleTemplateUtils.FormatTemplateStyleClassName = function (cellTypeName, templateKey, partName) {
            return "".concat(cellTypeName.replace(/\./g, ''), "-").concat(templateKey, "-").concat(partName);
        };
        return CellTypeStyleTemplateUtils;
    }());
    TabManager.CellTypeStyleTemplateUtils = CellTypeStyleTemplateUtils;
})(TabManager || (TabManager = {}));
