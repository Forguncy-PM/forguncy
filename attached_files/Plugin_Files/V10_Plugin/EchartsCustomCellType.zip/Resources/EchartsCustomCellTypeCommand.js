﻿/// <reference path="../Declarations/forguncy.d.ts" />
/// <reference path="../Declarations/forguncy.Plugin.d.ts" />

class EchartsCustomCellTypeCommand extends Forguncy.Plugin.CommandBase{

}

Forguncy.Plugin.CommandFactory.registerCommand("EchartsCustomCellType.EchartsCustomCellTypeCommand, EchartsCustomCellType", EchartsCustomCellTypeCommand);
