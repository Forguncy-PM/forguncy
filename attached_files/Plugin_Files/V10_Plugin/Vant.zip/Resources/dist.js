var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var VantTheme;
(function (VantTheme) {
    var colorDictionary = {
        "--van-primary-color": "Accent 1",
        "--van-stepper-button-round-theme-color": "Accent 1",
        "--van-tabs-card-height": "38px"
    };
    var updated = false;
    function updateCssAndAppend() {
        if (updated) {
            return;
        }
        var cssStr = "";
        for (var key in colorDictionary) {
            cssStr += "".concat(key, ":").concat(Forguncy.ConvertToCssColor(colorDictionary[key]), ";");
        }
        cssStr = ":root{ ".concat(cssStr, " }");
        var style = document.createElement("style");
        style.type = "text/css";
        style.id = "FGC_Vant_Variables";
        style.innerHTML = cssStr;
        document.getElementsByTagName("head")[0].appendChild(style);
        updated = true;
    }
    VantTheme.updateCssAndAppend = updateCssAndAppend;
})(VantTheme || (VantTheme = {}));
var VantCellTypes;
(function (VantCellTypes) {
    function internationalize() {
        var resource = Forguncy.Plugin
            .LocalizationResourceHelper.getPluginResource("EB88A8AF-2A9D-494A-95B3-CCF8DA6F5BAC");
        var culture = {
            save: resource["save"],
            confirm: resource["confirm"],
            cancel: resource["cancel"],
            "delete": resource["delete"],
            loading: resource["loading"],
            vanCalendar: {
                end: resource["vanCalendar.end"],
                start: resource["vanCalendar.start"],
                title: resource["vanCalendar.title"],
                weekdays: [
                    resource["vanCalendar.Sun"],
                    resource["vanCalendar.Mon"],
                    resource["vanCalendar.Tue"],
                    resource["vanCalendar.Wed"],
                    resource["vanCalendar.Thu"],
                    resource["vanCalendar.Fri"],
                    resource["vanCalendar.Sat"]
                ],
                monthTitle: function (year, month) { return resource["vanCalendar.monthTitle"].replace("{0}", year).replace("{1}", month); },
                rangePrompt: function (maxRange) { return resource["vanCalendar.rangePrompt"].replace("{0}", maxRange); }
            },
            vanCascader: {
                select: resource["vanCascader.select"],
            }
        };
        window.vant.Locale.use(Forguncy.RS.Culture, culture);
    }
    internationalize();
    var pluginPath = Forguncy.Helper.SpecialPath.getPluginRootPath("EB88A8AF-2A9D-494A-95B3-CCF8DA6F5BAC");
    var touchEmulatorScriptUrl = pluginPath + "Resources/touch-emulator.js";
    function loadScript(url) {
        var script = document.createElement("script");
        script.type = "text/javascript";
        script.src = url;
        document.body.appendChild(script);
    }
    function getIsEmulator() {
        var _a;
        try {
            var search = ((_a = window === null || window === void 0 ? void 0 : window.top) === null || _a === void 0 ? void 0 : _a.location).search;
            return search && search.indexOf("isMobile=true") !== -1;
        }
        catch (_b) {
            return false;
        }
    }
    function loadTouchEmulatorScript() {
        if (getIsEmulator()) {
            loadScript(touchEmulatorScriptUrl);
        }
    }
    loadTouchEmulatorScript();
    var VantCellTypeBase = /** @class */ (function (_super) {
        __extends(VantCellTypeBase, _super);
        function VantCellTypeBase() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._cellStyle = {};
            _this.cellType = _this.CellElement.CellType;
            return _this;
        }
        VantCellTypeBase.prototype.createVueApp = function (option) {
            var self = this;
            if (option.beforeCreate) {
                var beforeCreate_1 = option.beforeCreate;
                option.beforeCreate = function () {
                    self.vue = this;
                    beforeCreate_1();
                };
            }
            else {
                option.beforeCreate = function () {
                    self.vue = this;
                };
            }
            var vueApp = Vue.createApp(option);
            vueApp.use(window.vant);
            vueApp.mount("#".concat(this.uId));
            this._vueApp = vueApp;
        };
        VantCellTypeBase.prototype.updateColorVar = function (key, color) {
            var cssStr = "".concat(key, ":").concat(Forguncy.ConvertToCssColor(color), ";");
            cssStr = ":root{ ".concat(cssStr, " }");
            var style = document.createElement("style");
            style.innerHTML = cssStr;
            document.getElementsByTagName("head")[0].appendChild(style);
        };
        VantCellTypeBase.prototype.setFontStyle = function (styleInfo) {
            var currentStyleInfo = this._cellStyle;
            currentStyleInfo.FontFamily = styleInfo.FontFamily;
            currentStyleInfo.FontStyle = styleInfo.FontStyle;
            currentStyleInfo.FontSize = styleInfo.FontSize;
            currentStyleInfo.FontWeight = styleInfo.FontWeight;
            currentStyleInfo.Foreground = styleInfo.Foreground;
            currentStyleInfo.Strikethrough = styleInfo.Strikethrough;
            currentStyleInfo.Underline = styleInfo.Underline;
            this.setFontToDom();
        };
        VantCellTypeBase.prototype.setFontToDom = function () {
            var fontDom = this.fontDom;
            if (fontDom) {
                fontDom.css(this.getFontStyle());
            }
        };
        VantCellTypeBase.prototype.getFontStyle = function () {
            var _a;
            var styleInfo = (_a = this._cellStyle) !== null && _a !== void 0 ? _a : {};
            var textDecoration = [];
            if (styleInfo.Underline) {
                textDecoration.push("underline");
            }
            if (styleInfo.Strikethrough) {
                textDecoration.push("line-through");
            }
            return {
                "font-family": styleInfo.FontFamily ? styleInfo.FontFamily : "",
                "font-size": styleInfo.FontSize && styleInfo.FontSize > 0 ? styleInfo.FontSize : "",
                "font-style": styleInfo.FontStyle ? styleInfo.FontStyle.toLowerCase() : "",
                "font-weight": styleInfo.FontWeight ? styleInfo.FontWeight.toLowerCase() : "",
                "text-decoration": textDecoration.join(" "),
                "color": styleInfo.Foreground ? Forguncy.ConvertToCssColor(styleInfo.Foreground) : ""
            };
        };
        Object.defineProperty(VantCellTypeBase.prototype, "fontSelector", {
            get: function () {
                return this._fontSelector;
            },
            set: function (value) {
                if (typeof value === "string") {
                    this._fontSelector = value;
                    var style_1 = this.getFontStyle();
                    var styleStr_1 = "";
                    Object.keys(style_1).forEach(function (key) {
                        if (style_1[key] !== "") {
                            var cssValue = style_1[key];
                            if (key === "font-size") {
                                cssValue += "px";
                            }
                            styleStr_1 += "".concat(key, ": ").concat(cssValue, ";");
                        }
                    });
                    var styleElement = document.createElement("style");
                    styleElement.setAttribute("type", "text/css");
                    styleElement.innerHTML = "#".concat(this.uId, " ").concat(value, ", [id_temp=").concat(this.uId, "] ").concat(value, " { ").concat(styleStr_1, " }");
                    var container = this.container[0];
                    container.insertBefore(styleElement, container.childNodes[0]);
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(VantCellTypeBase.prototype, "fontDom", {
            get: function () {
                return this._fontDom;
            },
            set: function (value) {
                this._fontDom = value;
                this.setFontToDom();
            },
            enumerable: false,
            configurable: true
        });
        VantCellTypeBase.generateID = function (prefix) {
            if (prefix === void 0) { prefix = "fgc-vant"; }
            return "".concat(prefix, "-").concat(new Date().getTime().toString(36), "-").concat(Math.random().toString(36).slice(2));
        };
        VantCellTypeBase.prototype.createContent = function () {
            VantTheme.updateCssAndAppend();
            this.uId = VantCellTypeBase.generateID();
            this.container = $("<div id=".concat(this.ID, "><div id ='").concat(this.uId, "' style='width:100%;height:100%'></div>"))
                .css("width", "100%")
                .css("height", "100%");
            this._cellStyle = this.CellElement.StyleInfo;
            return this.container;
        };
        VantCellTypeBase.prototype.addCustomClass = function (className) {
            this.getContainer().addClass(className);
        };
        VantCellTypeBase.prototype.loop = function () {
            return undefined;
        };
        VantCellTypeBase.prototype.setValueToElement = function (jElement, value) {
            var _a;
            return (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setValue) || this.loop)(value);
        };
        VantCellTypeBase.prototype.getValueFromElement = function () {
            var _a;
            return (((_a = this.vue) === null || _a === void 0 ? void 0 : _a.getValue) || this.loop)();
        };
        VantCellTypeBase.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this.onIsDisabledChanged();
        };
        VantCellTypeBase.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this.onIsDisabledChanged();
        };
        VantCellTypeBase.prototype.onIsDisabledChanged = function () {
            var _a, _b, _c, _d;
            if (!this.vue) {
                return;
            }
            if (this.isDisabled()) {
                (_b = (_a = this.vue).disable) === null || _b === void 0 ? void 0 : _b.call(_a);
            }
            else {
                (_d = (_c = this.vue).enable) === null || _d === void 0 ? void 0 : _d.call(_c);
            }
        };
        VantCellTypeBase.prototype.setReadOnly = function (value) {
            var _a, _b;
            _super.prototype.setReadOnly.call(this, value);
            if ((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setReadOnly) {
                return (_b = this.vue) === null || _b === void 0 ? void 0 : _b.setReadOnly(this.isReadOnly());
            }
        };
        VantCellTypeBase.prototype.onPageLoaded = function (info) {
            var _a, _b;
            this.setFontToDom();
            this.setReadOnly(info.isReadOnly);
            if (info.isDisabled) {
                this.disable();
            }
            else {
                this.enable();
            }
            if ((_a = this.vue) === null || _a === void 0 ? void 0 : _a.setValue) {
                (_b = this.vue) === null || _b === void 0 ? void 0 : _b.setValue(info.value);
            }
        };
        VantCellTypeBase.prototype.calcNumber = function (value) {
            if (value === 0) {
                return value;
            }
            if (value) {
                return Number(value);
            }
        };
        VantCellTypeBase.prototype.isEmpty = function (v) {
            return v === null || v === undefined || v === "";
        };
        VantCellTypeBase.prototype.formatDate = function (date, fmt) {
            var o = {
                "M+": date.getMonth() + 1,
                "d+": date.getDate(),
                "H+": date.getHours(),
                "m+": date.getMinutes(),
                "s+": date.getSeconds(),
                "q+": Math.floor((date.getMonth() + 3) / 3),
                "S": date.getMilliseconds()
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        };
        VantCellTypeBase.prototype.isValidDate = function (date) {
            return date instanceof Date && !isNaN(date.getTime());
        };
        // 给vue列表的每个子项生成不重复的key
        VantCellTypeBase.prototype.uniqueKeyCreator = function (options, baseKeyPath) {
            var _this = this;
            if (baseKeyPath === void 0) { baseKeyPath = ""; }
            var keyCache = new Set();
            function getUniqueKey(baseKey) {
                if (typeof baseKey === "object" && baseKey !== null) {
                    return baseKey;
                }
                var key = "key_".concat(baseKey);
                if (keyCache.has(key)) {
                    return getUniqueKey(baseKey + "1");
                }
                else {
                    keyCache.add(key);
                    return key;
                }
            }
            return options.map(function (option) {
                var baseKey = _this.isPlainObject(option) ? option[baseKeyPath] : option;
                var key = getUniqueKey(baseKey);
                return _this.isPlainObject(option) ? __assign({ key: key }, option) : { key: key, value: option };
            });
        };
        VantCellTypeBase.prototype.isPlainObject = function (v) {
            return Object.prototype.toString.call(v) === "[object Object]";
        };
        VantCellTypeBase.prototype.isFormula = function (value) {
            return !this.isEmpty(value) && value.toString()[0] === "=";
        };
        VantCellTypeBase.prototype.destroy = function () {
            try {
                this._vueApp.unmount();
            }
            catch (e) {
                console.log(e);
            }
            finally {
                this._fontDom = null;
                _super.prototype.destroy.call(this);
            }
        };
        VantCellTypeBase.prototype.getCustomSlotByPath = function (slotPath) {
            var _a, _b;
            var slot = this.getPropertyByPath(window.FgcVant, slotPath.split("."));
            var slotStr = "";
            if (slot) {
                var classNames = (_b = (_a = this.CellElement.CssClassName) === null || _a === void 0 ? void 0 : _a.split(" ")) !== null && _b !== void 0 ? _b : [];
                for (var _i = 0, classNames_1 = classNames; _i < classNames_1.length; _i++) {
                    var name_1 = classNames_1[_i];
                    var selectSlotFunc = slot[name_1];
                    if (selectSlotFunc) {
                        slotStr = selectSlotFunc();
                        slotStr = typeof slotStr === "string" ? slotStr : "";
                        break;
                    }
                }
            }
            return slotStr;
        };
        VantCellTypeBase.prototype.getCustomFeatureByPath = function (featurePath) {
            var _a, _b;
            var feature = this.getPropertyByPath(window.FgcVant, featurePath.split("."));
            var featureFunc;
            if (feature) {
                var classNames = (_b = (_a = this.CellElement.CssClassName) === null || _a === void 0 ? void 0 : _a.split(" ")) !== null && _b !== void 0 ? _b : [];
                for (var _i = 0, classNames_2 = classNames; _i < classNames_2.length; _i++) {
                    var name_2 = classNames_2[_i];
                    var func = feature[name_2];
                    if (func) {
                        featureFunc = func;
                        break;
                    }
                }
            }
            return featureFunc;
        };
        VantCellTypeBase.prototype.getPropertyByPath = function (target, pathes) {
            var result = target !== null && target !== void 0 ? target : {};
            for (var _i = 0, pathes_1 = pathes; _i < pathes_1.length; _i++) {
                var item = pathes_1[_i];
                var property = result[item];
                if (property !== undefined) {
                    result = property;
                }
                else {
                    return null;
                }
            }
            return result;
        };
        VantCellTypeBase.prototype.format = function (value) {
            var _a, _b, _c;
            if ((_b = (_a = this.CellElement) === null || _a === void 0 ? void 0 : _a.StyleInfo) === null || _b === void 0 ? void 0 : _b["Formatter"]) {
                var formatedResult = Forguncy.FormatHelper.format((_c = this.CellElement.StyleInfo) === null || _c === void 0 ? void 0 : _c["Formatter"], value);
                return formatedResult.text;
            }
            return value === null || value === void 0 ? void 0 : value.toString();
        };
        return VantCellTypeBase;
    }(Forguncy.Plugin.CellTypeBase));
    VantCellTypes.VantCellTypeBase = VantCellTypeBase;
    var IconHelper = /** @class */ (function () {
        function IconHelper() {
        }
        IconHelper.getIcon = function (icon, callback) {
            if (icon) {
                if (typeof (icon) === "string") {
                    var src_1 = icon;
                    if (IconHelper.isAttachment(src_1)) {
                        src_1 = Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer() + encodeURIComponent(src_1);
                    }
                    callback(src_1);
                }
            }
            if (!(icon === null || icon === void 0 ? void 0 : icon.Name)) {
                return;
            }
            var src;
            if (icon.BuiltIn) {
                src = Forguncy.Helper.SpecialPath.getBuiltInImageFolderPath() + icon.Name;
            }
            else {
                src = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + encodeURIComponent(icon.Name);
            }
            if (Forguncy.ImageDataHelper.IsSvg(src)) {
                Forguncy.ImageHelper.requestSvg(src, function (svgElement) {
                    var svg = $(svgElement);
                    Forguncy.ImageHelper.preHandleSvg(svg, icon.Color);
                    callback(IconHelper.GetBase64FromSvgElement(svg[0].outerHTML));
                });
            }
            else {
                callback(src);
            }
        };
        IconHelper.GetBase64FromSvgElement = function (svgStr) {
            return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgStr)));
        };
        IconHelper.isAttachment = function (src) {
            if (typeof src !== "string") {
                return false;
            }
            src = src.toLowerCase();
            if (src.indexOf("http") === 0) {
                return false;
            }
            if (src.length < 37 || src[36] !== "_") {
                return false;
            }
            // FORGUNCY-5372 [VideoPlayer]External video set as the FilePreviewer cell, the video cannot play in runtime
            //if (src[src.length - 1] !== "|") {
            //    return false;
            //}
            // ---------------------
            return true;
        };
        return IconHelper;
    }());
    VantCellTypes.IconHelper = IconHelper;
    var SlotPath;
    (function (SlotPath) {
        SlotPath["pickerOption"] = "PickerSlots.Option";
        SlotPath["cascaderOption"] = "CascaderSlots.Option";
        SlotPath["datetimePickerOption"] = "DatetimePickerSlots.Option";
        SlotPath["gridItemContent"] = "GridItemSlots.Content";
    })(SlotPath = VantCellTypes.SlotPath || (VantCellTypes.SlotPath = {}));
    var FeaturePath;
    (function (FeaturePath) {
        FeaturePath["calendarFormatter"] = "CalendarFeature.Formatter";
        FeaturePath["swipeItem"] = "SwipeFeature.Item";
        FeaturePath["swipePreviewItem"] = "SwipeFeature.PreviewItem";
    })(FeaturePath = VantCellTypes.FeaturePath || (VantCellTypes.FeaturePath = {}));
    var InputBase = /** @class */ (function (_super) {
        __extends(InputBase, _super);
        function InputBase() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        InputBase.prototype.getData = function (cellType) {
            return {
                value: undefined,
                placeholder: undefined,
                border: cellType.border,
                disabled: undefined,
                readonly: undefined,
                clearable: cellType.clearable,
                isLink: cellType.isLink,
                leftIcon: null,
                rightIcon: null,
                inputAlign: "left",
                type: "text"
            };
        };
        InputBase.prototype.setFontToDom = function () {
            _super.prototype.setFontToDom.call(this);
            if (this.vue) {
                if (this._cellStyle.HorizontalAlignment === Forguncy.Plugin.CellHorizontalAlignment.Center) {
                    this.vue.inputAlign = "center";
                }
                else if (this._cellStyle.HorizontalAlignment === Forguncy.Plugin.CellHorizontalAlignment.Right) {
                    this.vue.inputAlign = "right";
                }
                else {
                    this.vue.inputAlign = "left";
                }
            }
        };
        InputBase.prototype.getInputTemplate = function (moreBindingString) {
            return "\n<div :class=\"border ? 'fgc-vant-field-border':''\">\n    <van-field\n        ref=\"van-field\"\n        v-model=\"value\"\n        :placeholder=\"placeholder\"\n        :disabled=\"disabled\"\n        :clearable=\"type === 'textarea' ? false : (clearable && !disabled && !readonly)\"\n        :is-link=\"isLink\"\n        :left-icon=\"type === 'textarea' ? '' : leftIcon\"\n        :right-icon=\"type === 'textarea' ? '' : rightIcon\"\n        :input-align=\"inputAlign\"\n        center\n        ".concat(moreBindingString, "\n    />\n</div>\n");
        };
        InputBase.prototype.getDefaultMethods = function (obj) {
            obj = obj !== null && obj !== void 0 ? obj : {};
            var cellType = this.CellElement.CellType;
            var base = {
                getValue: function () {
                    return this.value;
                },
                setValue: function (value) {
                    this.value = value;
                },
                disable: function () {
                    this.disabled = true;
                    this.updateIsLink();
                },
                enable: function () {
                    this.disabled = false;
                    this.updateIsLink();
                },
                setReadOnly: function (value) {
                    this.readonly = value;
                    this.updateIsLink();
                },
                updateIsLink: function () {
                    if (this.readonly || this.disabled) {
                        this.isLink = false;
                    }
                    else {
                        this.isLink = cellType.isLink;
                    }
                }
            };
            return __assign(__assign({}, base), obj);
        };
        InputBase.prototype.setFontToInputDom = function (vue, dom) {
            if (dom === void 0) { dom = null; }
            if (!dom) {
                dom = $(".van-field__control", $(vue.$el));
            }
            this.fontDom = dom;
            this.setFontToDom();
        };
        InputBase.prototype.onPageLoaded = function (info) {
            var _this = this;
            var _a;
            var cellType = this.CellElement.CellType;
            IconHelper.getIcon(cellType.leftIcon, function (icon) {
                _this.vue.leftIcon = icon;
            });
            IconHelper.getIcon(cellType.rightIcon, function (icon) {
                _this.vue.rightIcon = icon;
            });
            this._inputTextCache = (_a = this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString();
            this.getContainer().keyup(function () {
                var _a, _b;
                if (_this._inputTextCache !== ((_a = _this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString())) {
                    _this.hideValidateTooltip();
                }
                _this._inputTextCache = (_b = _this.getValueFromElement()) === null || _b === void 0 ? void 0 : _b.toString();
            });
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                _this.vue.placeholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        InputBase.prototype.Focus = function () {
            this.vue.$refs["van-field"].focus();
        };
        InputBase.prototype.setFocus = function () {
            this.Focus();
        };
        InputBase.prototype.hasFocus = function () {
            var dom = $("input", this.getContainer());
            return dom.length && document.activeElement === dom[0];
        };
        InputBase.prototype.Select = function () {
            var input = $(this.vue.$el).find("input");
            input === null || input === void 0 ? void 0 : input.focus();
            input === null || input === void 0 ? void 0 : input.select();
        };
        InputBase.prototype.setValueToElement = function (jElement, value) {
            var _a;
            _super.prototype.setValueToElement.call(this, jElement, value);
            this._inputTextCache = (_a = this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString();
        };
        return InputBase;
    }(VantCellTypeBase));
    VantCellTypes.InputBase = InputBase;
    var SupportDataSourceCellType = /** @class */ (function () {
        function SupportDataSourceCellType() {
        }
        SupportDataSourceCellType.refreshData = function (cellType, bindingDataSourceModel, callBack, watchOnDependenceChange, options, userAction) {
            if (watchOnDependenceChange === void 0) { watchOnDependenceChange = true; }
            if (options === void 0) { options = null; }
            if (userAction === void 0) { userAction = false; }
            cellType.getBindingDataSourceValue(bindingDataSourceModel, options, function (dataSource, userAction) {
                callBack(dataSource, userAction);
            }, true);
        };
        return SupportDataSourceCellType;
    }());
    VantCellTypes.SupportDataSourceCellType = SupportDataSourceCellType;
})(VantCellTypes || (VantCellTypes = {}));
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var CalendarCellType = /** @class */ (function (_super) {
        __extends(CalendarCellType, _super);
        function CalendarCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CalendarCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var customFormatter = this.getCustomFeatureByPath(VantCellTypes.FeaturePath.calendarFormatter);
            var option = {
                template: "\n<van-calendar\n    ref=\"van-calendar\"\n    :show-title=\"false\"\n    :poppable=\"false\"\n    :type=\"type\"\n    :color=\"color\"\n    :min-date=\"minDate\"\n    :max-date=\"maxDate\"\n    :max-range=\"maxRange\"\n    :readonly=\"readonly\"\n    :show-confirm=\"false\"\n    :show-range-prompt=\"showRangePrompt\"\n    :first-day-of-week=\"firstDayOfWeek\"\n    :show-mark=\"showMark\"\n    :show-subtitle=\"showSubtitle\"\n    :allow-same-day=\"allowSameDay\"\n    @select=\"handleSelect\"\n    :formatter=\"formatter\"\n></van-calendar>\n",
                data: function () {
                    return __assign(__assign({ cellValue: undefined }, cellType), self.getDefaultData(cellType));
                },
                methods: {
                    setValue: function (value) {
                        var _this = this;
                        var _a;
                        this.cellValue = value;
                        var date;
                        if (typeof value === "number") {
                            date = Forguncy.ConvertOADateToDate(value);
                        }
                        else if (typeof value === "string") {
                            date = [];
                            for (var _i = 0, _b = value.split(","); _i < _b.length; _i++) {
                                var item = _b[_i];
                                var oaDate = Number(item);
                                if (!isNaN(oaDate)) {
                                    date.push(Forguncy.ConvertOADateToDate(oaDate));
                                }
                                else {
                                    var dateTime = VantCellTypes.DateUtil.ConvertToDate(item, null);
                                    if (dateTime !== null) {
                                        date.push(dateTime);
                                    }
                                    else {
                                        date = [];
                                        break;
                                    }
                                }
                            }
                        }
                        else if (value instanceof Date) {
                            date = value;
                        }
                        else {
                            date = new Date();
                        }
                        if (!Array.isArray(date) && this.type !== "single") {
                            date = [date];
                        }
                        if (this.lastDate) {
                            try {
                                if (this.lastDate instanceof Array && date instanceof Array) {
                                    if (this.lastDate.length === date.length) {
                                        if (date.every(function (item, index) {
                                            var _a;
                                            return (item === null || item === void 0 ? void 0 : item.valueOf()) === ((_a = _this.lastDate[index]) === null || _a === void 0 ? void 0 : _a.valueOf());
                                        })) {
                                            return;
                                        }
                                    }
                                }
                                else {
                                    if (((_a = this.lastDate) === null || _a === void 0 ? void 0 : _a.valueOf()) === (date === null || date === void 0 ? void 0 : date.valueOf())) {
                                        return;
                                    }
                                }
                            }
                            finally {
                                this.lastDate = undefined;
                            }
                        }
                        this.$refs["van-calendar"].reset(date);
                    },
                    getValue: function () {
                        if (Array.isArray(this.cellValue)) {
                            return this.cellValue.join(",");
                        }
                        return this.cellValue;
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    },
                    handleSelect: function (date) {
                        var _a, _b;
                        if ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                            var initValue = {};
                            if (Array.isArray(date)) {
                                var result = null;
                                if (date.length > 0) {
                                    result = date[date.length - 1];
                                }
                                initValue[cellType.ClickCommand.ParamProperties["date"]] = result;
                            }
                            else {
                                initValue[cellType.ClickCommand.ParamProperties["date"]] = date;
                            }
                            self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                        }
                        if (Array.isArray(date)) {
                            this.cellValue = date.map(function (value) { return Forguncy.ConvertDateToOADate(value); });
                        }
                        else {
                            this.cellValue = Forguncy.ConvertDateToOADate(date);
                        }
                        this.lastDate = date;
                        self.commitValue();
                    },
                    formatter: function (day) {
                        if (typeof customFormatter === "function") {
                            return customFormatter(day);
                        }
                        return day;
                    }
                }
            };
            this.createVueApp(option);
            var updateValue = function () {
                _this.vue.$nextTick(function () {
                    _this.vue.setValue(_this.vue.getValue());
                });
            };
            this.onFormulaResultChanged(cellType.minDate, function (value) {
                _this.vue.minDate = _this.convertToDate(value);
                updateValue();
            });
            this.onFormulaResultChanged(cellType.maxDate, function (value) {
                _this.vue.maxDate = _this.convertToDate(value);
                updateValue();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        CalendarCellType.prototype.getDefaultData = function (cellType) {
            return {
                maxRange: this.isEmpty(cellType.maxRange) ? undefined : cellType.maxRange,
                readonly: false,
                showMark: !!cellType.showMark,
                showSubtitle: !!cellType.showSubtitle,
                allowSameDay: !!cellType.allowSameDay,
                showRangePrompt: !!cellType.showRangePrompt,
                minDate: undefined,
                maxDate: undefined,
                color: Forguncy.ConvertToCssColor(cellType.color),
            };
        };
        CalendarCellType.prototype.convertToDate = function (value) {
            var _a;
            return (_a = VantCellTypes.DateUtil.ConvertToDate(this.evaluateFormula(value), null)) !== null && _a !== void 0 ? _a : undefined;
        };
        return CalendarCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.CalendarCellType = CalendarCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Calendar, Vant", VantCellTypes.CalendarCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var CascaderCellType = /** @class */ (function (_super) {
        __extends(CascaderCellType, _super);
        function CascaderCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CascaderCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        CascaderCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var config = cellType.CascaderConfig;
            var options = [];
            if (!cellType.useBinding && cellType.options) {
                options = cellType.options;
                VantCellTypes.TreeHelper.flat(options).forEach(function (i) {
                    if (i === null || i === void 0 ? void 0 : i.text) {
                        i.text = self.format(self.getApplicationResource(i.text));
                    }
                });
            }
            var input = this.getInputTemplate("@click=\"onClick\" clear-trigger=\"always\" @clear=\"onClear\"");
            var optionStr = this.getCustomSlotByPath(VantCellTypes.SlotPath.cascaderOption);
            var option = {
                template: "\n<div class=\"fgc-vant-inputContainer\">\n    ".concat(input, "\n    <van-popup v-model:show=\"show\" position=\"bottom\" teleport=\"body\">\n      <van-cascader\n        v-model=\"cascaderValue\"\n        :title=\"title\"\n        :options=\"options\"\n        :closeable=\"closeable\"\n        :show-header=\"showToolbar\"\n        :swipeable=\"swipeable\"\n        :activeColor=\"activeColor\"\n        @close=\"show = false\"\n        @finish=\"onFinish\"\n      >\n        ").concat(optionStr ? "<template #option='data'>" + optionStr + "</template>" : "", "\n      </van-cascader>\n    </van-popup>\n</div>"),
                data: function () {
                    var baseData = self.getData(cellType);
                    var data = {
                        show: false,
                        cellValue: undefined,
                        cascaderValue: undefined,
                        options: options,
                        title: undefined,
                        activeColor: Forguncy.ConvertToCssColor(config.activeColor),
                        closeable: !!config.closeable,
                        showToolbar: !!config.showToolbar,
                        swipeable: !!config.swipeable
                    };
                    return __assign(__assign({}, baseData), data);
                },
                methods: this.getDefaultMethods({
                    onFinish: function (_a) {
                        var selectedOptions = _a.selectedOptions;
                        this.show = false;
                        this.updataValueBySelectedOption(selectedOptions);
                        this.cellValue = this.cascaderValue;
                        self.commitValue();
                        self.validate();
                    },
                    onClick: function () {
                        if (!self.isReadOnly() && !self.isDisabled()) {
                            this.show = true;
                            this.cascaderValue = this.cellValue;
                        }
                    },
                    onClear: function () {
                        this.cellValue = null;
                        self.commitValue();
                        self.validate();
                    },
                    getValue: function () {
                        return this.cellValue;
                    },
                    setValue: function (value) {
                        if (this.cellValue !== value) {
                            this.cellValue = value;
                            this.updateValue();
                        }
                    },
                    updateValue: function () {
                        var selectedOptions = CascaderCellType.getPathByValue(this.options, this.cellValue);
                        this.updataValueBySelectedOption(selectedOptions);
                    },
                    updataValueBySelectedOption: function (selectedOptions) {
                        if (selectedOptions) {
                            this.value = selectedOptions.map(function (option) { return option.text; }).join('/');
                        }
                        else {
                            this.value = null;
                        }
                    },
                    setOptions: function (options) {
                        if (options) {
                            VantCellTypes.TreeHelper.flat(options).forEach(function (i) {
                                if (i === null || i === void 0 ? void 0 : i.text) {
                                    i.text = self.format(self.getApplicationResource(i.text));
                                }
                            });
                            this.options = options;
                        }
                        else {
                            this.options = [];
                        }
                    }
                }),
                mounted: function () {
                    self.setFontToInputDom(this);
                    $(".van-field__control", self.container).attr("readonly", "readonly");
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.CascaderConfig.title, function (value) {
                _this.vue.title = value === null || value === void 0 ? void 0 : value.toString();
            });
            if (cellType.useBinding) {
                VantCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (data) { return _this.setDataSource(VantCellTypes.TreeHelper.build(data)); });
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        CascaderCellType.getPathByValue = function (options, value, curretPath) {
            if (curretPath === void 0) { curretPath = []; }
            if (!options) {
                return null;
            }
            for (var _i = 0, options_1 = options; _i < options_1.length; _i++) {
                var option = options_1[_i];
                // eslint-disable-next-line
                if (option.value == value) {
                    return curretPath.concat([option]);
                }
                if (option.children) {
                    var result = this.getPathByValue(option.children, value, curretPath.concat([option]));
                    if (result) {
                        return result;
                    }
                }
            }
            return null;
        };
        CascaderCellType.prototype.SetDataSourceByObjTree = function (dataSource, valueProperty, labelProperty, childrenProperty) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (childrenProperty) {
                childrenProperty = childrenProperty.split('|');
            }
            if (valueProperty) {
                valueProperty = valueProperty.split('|');
            }
            if (labelProperty) {
                labelProperty = labelProperty.split('|');
            }
            if (!labelProperty) {
                labelProperty = valueProperty;
            }
            var source = this.buildTree(dataSource, valueProperty, labelProperty, childrenProperty);
            this.setDataSource(source);
        };
        CascaderCellType.prototype.buildTree = function (dataSource, valueProperty, labelProperty, childrenProperty) {
            var _this = this;
            if (!dataSource) {
                return undefined;
            }
            return dataSource.map(function (i) { return ({
                value: _this.getSubPropertyValue(i, valueProperty),
                text: _this.getSubPropertyValue(i, labelProperty),
                children: _this.buildTree(_this.getSubPropertyValue(i, childrenProperty), valueProperty, labelProperty, childrenProperty),
            }); });
        };
        CascaderCellType.prototype.getSubPropertyValue = function (obj, subProperties) {
            for (var _i = 0, subProperties_1 = subProperties; _i < subProperties_1.length; _i++) {
                var prop = subProperties_1[_i];
                if (obj[prop] !== undefined) {
                    return obj[prop];
                }
            }
            return undefined;
        };
        CascaderCellType.prototype.SetDataSourceByIdPidTable = function (dataSource, valueProperty, labelProperty, parentValue) {
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var treeObj = VantCellTypes.TreeHelper.build(dataSource.map(function (i) { return ({
                value: i[valueProperty],
                text: i[labelProperty],
                parentValue: i[parentValue],
            }); }));
            this.setDataSource(treeObj);
        };
        CascaderCellType.prototype.GetCheckedNodes = function (leafOnly) {
            if (typeof (leafOnly) === "string") {
                leafOnly = !(leafOnly.toLowerCase() === "false" || leafOnly.toLowerCase() === "0");
            }
            else {
                leafOnly = !!leafOnly;
            }
            return {
                CheckedItems: this.vue.$refs.elInput.getCheckedNodes(leafOnly).map(function (i) { return ({
                    "value": i.value,
                    "text": i.text,
                }); })
            };
        };
        CascaderCellType.prototype.ShowPopup = function () {
            this.vue.onClick();
        };
        return CascaderCellType;
    }(VantCellTypes.InputBase));
    VantCellTypes.CascaderCellType = CascaderCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Cascader, Vant", VantCellTypes.CascaderCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var CircleCellType = /** @class */ (function (_super) {
        __extends(CircleCellType, _super);
        function CircleCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CircleCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var option = {
                template: "\n<van-circle\n:text=\"text\"\nv-model:current-rate=\"currentRate\"\n:rate=\"rate\"\n:color=\"color\"\n:layer-color=\"layerColor\"\n:fill=\"fill\"\n:size=\"size\" \n:speed=\"speed\" \n:strokeLinecap=\"strokeLinecap\" \n:startPosition=\"startPosition\" \n:clockwise=\"clockwise\" \n:strokeWidth=\"strokeWidth\" />",
                data: function () {
                    return {
                        text: " ",
                        currentRate: 0,
                        rate: 0,
                        color: Forguncy.ConvertToCssColor(cellType.color),
                        layerColor: Forguncy.ConvertToCssColor(cellType.layerColor),
                        fill: Forguncy.ConvertToCssColor(cellType.fill),
                        size: cellType.size,
                        speed: cellType.speed,
                        strokeLinecap: cellType.strokeLinecap,
                        startPosition: cellType.startPosition,
                        clockwise: !!cellType.clockwise,
                        strokeWidth: cellType.strokeWidth * 1000 / cellType.size
                    };
                },
                methods: {
                    getValue: function () {
                        return this.rate;
                    },
                    setValue: function (value) {
                        if (!value) {
                            value = 0;
                        }
                        var rate = Number(value);
                        if (!isNaN(rate)) {
                            this.rate = rate;
                            this.text = self.getText();
                        }
                    }
                },
                mounted: function () {
                    self.fontDom = $(this.$el).find(".van-circle__text");
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.text, function (value) {
                _this.vue.text = _this.getText();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        CircleCellType.prototype.getText = function () {
            var _a;
            var text = this.cellType.text;
            if (!text) {
                return this.vue.rate.toFixed(0) + "%";
            }
            var result = (_a = this.evaluateFormula(text)) === null || _a === void 0 ? void 0 : _a.toString();
            if (!result) {
                return " ";
            }
            return result;
        };
        CircleCellType.prototype.clickable = function () {
            return false;
        };
        CircleCellType.prototype.ChangeCircleProgressStatus = function (text, color, fill) {
            if (!this.isEmpty(text)) {
                this.vue.text = text;
            }
            if (!this.isEmpty(color)) {
                this.vue.color = Forguncy.ConvertToCssColor(color);
            }
            if (!this.isEmpty(fill)) {
                this.vue.fill = Forguncy.ConvertToCssColor(fill);
            }
        };
        return CircleCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.CircleCellType = CircleCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Circle, Vant", VantCellTypes.CircleCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var DateTimePickerCellType = /** @class */ (function (_super) {
        __extends(DateTimePickerCellType, _super);
        function DateTimePickerCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DateTimePickerCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        DateTimePickerCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var config = cellType.DateTimePickerConfig;
            var input = this.getInputTemplate("@click=\"onClick\" clear-trigger=\"always\" @change=\"onChange\" @clear=\"onClear\"");
            var optionStr = this.getCustomSlotByPath(VantCellTypes.SlotPath.datetimePickerOption);
            var option = {
                template: "\n<div class=\"fgc-vant-inputContainer\">\n    ".concat(input, "\n    <van-popup v-model:show=\"show\" position=\"bottom\" teleport=\"body\">\n      <van-datetime-picker\n        v-model=\"DateTimePickerValue\"\n        :type=\"type\"\n        :min-date=\"minDate\"\n        :max-date=\"maxDate\"\n        :min-hour=\"minHour\"\n        :max-hour=\"maxHour\"\n        :min-minute=\"minMinute\"\n        :max-minute=\"maxMinute\"\n        :title=\"title\"\n        :confirm-button-text=\"confirmButtonText\"\n        :cancel-button-text=\"cancelButtonText\"\n        :item-height=\"itemHeight\"\n        :visible-item-count=\"visibleItemCount\"\n        :swipe-duration=\"swipeDuration\"\n        :show-toolbar=\"showToolbar\"\n        :formatter=\"onFormatter\"\n        :filter=\"onFilter\"\n        @cancel=\"show = false\"\n        @confirm=\"onFinish\"\n      >\n        ").concat(optionStr ? "<template #option='data'>" + optionStr + "</template>" : "", "\n      </van-datetime-picker>\n    </van-popup>\n</div>"),
                data: function () {
                    var baseData = self.getData(cellType);
                    var data = __assign(__assign({ value: "", show: false, cellValue: undefined }, VantCellTypes.getPickerValidToolbarOption(config)), { DateTimePickerValue: cellType.type === "time" ? "".concat(cellType.minHour, ":").concat(cellType.minMinute) : new Date(), type: cellType.type, minDate: undefined, maxDate: undefined, minHour: cellType.minHour, maxHour: cellType.maxHour, minMinute: cellType.minMinute, maxMinute: cellType.maxMinute });
                    config.showToolbar = !!config.showToolbar;
                    return __assign(__assign(__assign({}, baseData), config), data);
                },
                methods: this.getDefaultMethods({
                    onFinish: function () {
                        this.show = false;
                        if (typeof this.DateTimePickerValue === "string" &&
                            this.DateTimePickerValue.indexOf(":") > 0 &&
                            this.type === "time") {
                            var start = Forguncy.ConvertDateToOADate(new Date("2001/1/1 " + this.DateTimePickerValue));
                            var end = Forguncy.ConvertDateToOADate(new Date("2001/1/1"));
                            this.cellValue = start - end;
                        }
                        else {
                            this.cellValue = Forguncy.ConvertDateToOADate(this.DateTimePickerValue);
                        }
                        this.updateValue();
                        self.commitValue();
                        self.validate();
                    },
                    onClear: function () {
                        this.cellValue = null;
                        self.commitValue();
                        self.validate();
                    },
                    getValidMinDateAndMaxDate: function (minDateValue, maxDateValue, autoFill) {
                        if (autoFill === void 0) { autoFill = true; }
                        var minDate = this.convertToDate(minDateValue) || this.minDate;
                        var maxDate = this.convertToDate(maxDateValue) || this.maxDate;
                        var returnResult = function () { return ({ minDate: minDate, maxDate: maxDate, }); };
                        if (!autoFill) {
                            return returnResult();
                        }
                        if (!minDate && maxDate) {
                            minDate = new Date(maxDate.valueOf());
                            minDate.setFullYear(minDate.getFullYear() - 20);
                            return returnResult();
                        }
                        if (!maxDate && minDate) {
                            maxDate = new Date(minDate.valueOf());
                            maxDate.setFullYear(maxDate.getFullYear() + 20);
                            return returnResult();
                        }
                        return returnResult();
                    },
                    onFormatter: function (type, value) {
                        return self.formatter(type, value);
                    },
                    onFilter: function (type, options) {
                        return self.filter(type, options);
                    },
                    onClick: function () {
                        if (!self.isReadOnly() && !self.isDisabled()) {
                            this.show = true;
                        }
                    },
                    onChange: function (value) {
                        this.value = value !== null && value !== void 0 ? value : "";
                        this.onFinish();
                    },
                    getValue: function () {
                        return this.cellValue;
                    },
                    setValue: function (value) {
                        if (this.cellValue !== value) {
                            this.cellValue = value;
                            this.updateValue();
                        }
                    },
                    updateValue: function () {
                        var result = Forguncy.FormatHelper.format(this.getFormatStr(), this.cellValue);
                        this.value = result === null || result === void 0 ? void 0 : result.text;
                        var dateTime = new Date();
                        if (this.cellValue) {
                            dateTime = Forguncy.ConvertOADateToDate(this.cellValue);
                        }
                        if (this.type === "time") {
                            this.DateTimePickerValue = "".concat(dateTime.getHours(), ":").concat(dateTime.getMinutes());
                        }
                        else {
                            this.DateTimePickerValue = dateTime;
                        }
                    },
                    getFormatStr: function () {
                        switch (this.type) {
                            case "date":
                                return "yyyy-MM-dd";
                            case "time":
                                return "HH:mm";
                            case "year-month":
                                return "yyyy-MM";
                            case "month-day":
                                return "MM-dd";
                            case "datehour":
                                return "yyyy-MM-dd HH:mm";
                            case "datetime":
                                return "yyyy-MM-dd HH:mm";
                            default:
                                return "yyyy-MM-dd";
                        }
                    },
                    convertToDate: function (value) {
                        var _a;
                        return (_a = VantCellTypes.DateUtil.ConvertToDate(value, null)) !== null && _a !== void 0 ? _a : undefined;
                    },
                }),
                mounted: function () {
                    self.setFontToInputDom(this);
                    $(".van-field__control", self.container).attr("readonly", "readonly");
                },
                watch: {
                    show: function (value) {
                        if (!value && !this.showToolbar) {
                            this.onFinish();
                        }
                    }
                }
            };
            this.createVueApp(option);
            var updateMinMax = function () {
                var _a = _this.vue.getValidMinDateAndMaxDate(_this._minValueResult, _this._maxValueResult, false), minDate = _a.minDate, maxDate = _a.maxDate;
                _this.vue.minDate = minDate;
                _this.vue.maxDate = maxDate;
            };
            this.onFormulaResultChanged(cellType.minDate, function (value) {
                _this._minValueResult = value;
                updateMinMax();
            });
            this.onFormulaResultChanged(cellType.maxDate, function (value) {
                _this._maxValueResult = value;
                updateMinMax();
            });
            VantCellTypes.setPickerValidToolbarOptionToVue(this, cellType.DateTimePickerConfig, this.vue);
            _super.prototype.onPageLoaded.call(this, info);
        };
        // 留给用户重写
        DateTimePickerCellType.prototype.formatter = function (type, value) {
            return value;
        };
        // 留给用户重写
        DateTimePickerCellType.prototype.filter = function (type, options) {
            return options;
        };
        DateTimePickerCellType.prototype.ShowPopup = function () {
            this.vue.onClick();
        };
        return DateTimePickerCellType;
    }(VantCellTypes.InputBase));
    VantCellTypes.DateTimePickerCellType = DateTimePickerCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.DateTimePicker, Vant", VantCellTypes.DateTimePickerCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var GridCellType = /** @class */ (function (_super) {
        __extends(GridCellType, _super);
        function GridCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        GridCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            this.addCustomClass("vant-grid-custom");
            var cellType = this.cellType;
            var gridItems = [];
            if (!cellType.useBinding && cellType.options) {
                var permission = this.getUIPermission(1 /* Forguncy.Plugin.UIPermissionScope.Visible */);
                var filteredOptions = this.filterOptionsByPermission(cellType.options, permission === null || permission === void 0 ? void 0 : permission.Children);
                gridItems = self.uniqueKeyCreator(filteredOptions.map(function (i) { return self.createItem(i, false); }), "text");
            }
            var contentStr = this.getCustomSlotByPath(VantCellTypes.SlotPath.gridItemContent);
            var option = {
                el: "#" + this.uId,
                template: "\n<van-grid\n    :column-num=\"columnNum\"\n    :gutter=\"gutter\"\n    :border=\"border\"\n    :center=\"center\"\n    :square=\"square\"\n    :clickable=\"clickable\"\n    :direction=\"direction\"\n    :icon-size=\"iconSize\"\n    :reverse=\"reverse\">\n    <van-grid-item\n        :key=\"option.key\"\n        v-for=\"(option, index) in gridItems\"\n        :text=\"option.text\"\n        :icon=\"option.icon\"\n        :dot=\"showAsDot(option)\"\n        :badge=\"option.badge\"\n        @click=\"option.click\">\n        ".concat(contentStr, "\n    </van-grid-item>\n</van-grid>\n"),
                data: function () {
                    var _a, _b;
                    return {
                        columnNum: cellType.columnNum,
                        gutter: cellType.gutter,
                        border: !!cellType.border,
                        center: !!cellType.center,
                        square: !!cellType.square,
                        reverse: !!cellType.reverse,
                        clickable: ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) > 0,
                        direction: cellType.direction,
                        iconSize: cellType.iconSize,
                        gridItems: gridItems,
                    };
                },
                methods: {
                    showAsDot: function (gridItem) {
                        return self.isEmpty(gridItem.badge) ? false : !!gridItem.dot;
                    }
                },
                mounted: function () {
                    self.fontDom = self.container.find(".van-grid-item__text");
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                VantCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                    _this.vue.gridItems = _this.uniqueKeyCreator(dataSource.map(function (i) { return _this.createItem(i); }), "text");
                    _this.calcIcon(_this.vue.gridItems);
                    _this.vue.$nextTick(function () {
                        _this.fontDom = _this.container.find(".van-grid-item__text");
                    });
                });
            }
            else {
                this.calcIcon(this.vue.gridItems);
                var _loop_1 = function (gridItem) {
                    this_1.onFormulaResultChanged(gridItem.sourceBadge, function (value) {
                        gridItem.badge = value;
                    });
                };
                var this_1 = this;
                for (var _i = 0, _a = this.vue.gridItems; _i < _a.length; _i++) {
                    var gridItem = _a[_i];
                    _loop_1(gridItem);
                }
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        GridCellType.prototype.filterOptionsByPermission = function (options, permissions) {
            var _this = this;
            if (!permissions) {
                return options;
            }
            return options.filter(function (option, index) {
                if (permissions[index]) {
                    return _this.checkRoleAuthority(permissions[index].AllowRoles);
                }
                return true;
            });
        };
        GridCellType.prototype.calcIcon = function (items) {
            var _loop_2 = function (item) {
                if (item.sourceIcon) {
                    VantCellTypes.IconHelper.getIcon(item.sourceIcon, function (icon) {
                        item.icon = icon;
                    });
                }
            };
            for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
                var item = items_1[_i];
                _loop_2(item);
            }
        };
        GridCellType.prototype.createItem = function (sourceData, calcBadge) {
            var _this = this;
            var _a;
            if (calcBadge === void 0) { calcBadge = true; }
            var cellType = this.cellType;
            var result = {
                value: sourceData.value,
                text: this.getApplicationResource(sourceData.text),
                icon: null,
                sourceIcon: sourceData.icon,
                dot: sourceData.dot,
                sourceBadge: sourceData.badge,
                badge: calcBadge ? this.evaluateFormula(sourceData.badge) : null
            };
            var clickCommands = cellType.ClickCommand;
            if (((_a = clickCommands === null || clickCommands === void 0 ? void 0 : clickCommands.Commands) === null || _a === void 0 ? void 0 : _a.length) > 0) {
                result.click = function () {
                    var param = {};
                    param[clickCommands.ParamProperties["value"]] = sourceData.value;
                    param[clickCommands.ParamProperties["text"]] = sourceData.text;
                    _this.executeCustomCommandObject(clickCommands, param, "Click" + sourceData.value);
                };
            }
            return result;
        };
        // RunTimeMethod
        GridCellType.prototype.SetBadge = function (itemValue, badgeValue) {
            for (var _i = 0, _a = this.vue.gridItems; _i < _a.length; _i++) {
                var item = _a[_i];
                var gridItem = item;
                // eslint-disable-next-line
                if (gridItem.value == itemValue) {
                    item.badge = badgeValue === null || badgeValue === void 0 ? void 0 : badgeValue.toString();
                }
            }
        };
        return GridCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.GridCellType = GridCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Grid, Vant", VantCellTypes.GridCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var InputCellType = /** @class */ (function (_super) {
        __extends(InputCellType, _super);
        function InputCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        InputCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        InputCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var input = this.getInputTemplate("\n:maxlength=\"maxlength\"\n:show-word-limit=\"showWordLimit\"\n:type=\"type\"\n:enterkeyhint=\"enterkeyhint\"\n:autosize=\"autosize\"\n:readonly=\"readonly\"\n@blur=\"onFinish\"\n@keypress=\"onKeypress($event)\"\n:class=\"{ 'show-word-limit': ".concat(!self.isEmpty(cellType.maxlength), " && showWordLimit }\"\n"));
            var option = {
                el: "#" + this.uId,
                template: "\n<div class=\"fgc-vant-inputContainer\">\n    ".concat(input, "\n</div>"),
                data: function () {
                    var baseData = self.getData(cellType);
                    var data = {
                        type: cellType.type === "text" ? cellType.keyboardType : cellType.type,
                        maxlength: undefined,
                        showWordLimit: cellType.showWordLimit,
                        enterkeyhint: cellType.enterkeyhint
                    };
                    return __assign(__assign(__assign({}, baseData), data), { autosize: self.bindAutosize(cellType) });
                },
                methods: this.getDefaultMethods({
                    onFinish: function () {
                        self.commitValue();
                        self.validate();
                    },
                    onKeypress: function (e) {
                        if (this.type != "textarea"
                            && e.keyCode === 13
                            && e.key === "Enter") {
                            this.onFinish();
                        }
                    }
                }),
                mounted: function () {
                    self.setFontToInputDom(this);
                    if (this.type == "textarea") {
                        $(".van-field__value", self.container).css("height", "100%");
                        $(".van-field__value > .van-field__body", self.container).css("height", "100%");
                        $(".van-field__value > .van-field__body > textarea", self.container).css("height", "100%");
                    }
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.maxlength, function (value) {
                _this.vue.maxlength = _this.getMaxLength(value);
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        InputCellType.prototype.getMaxLength = function (value) {
            var max = this.calcNumber(value);
            return max ? max : undefined;
        };
        InputCellType.prototype.bindAutosize = function (cellType) {
            var autosize = cellType.autosize, minHeight = cellType.minHeight, maxHeight = cellType.maxHeight;
            return autosize ? { minHeight: minHeight, maxHeight: maxHeight } : false;
        };
        return InputCellType;
    }(VantCellTypes.InputBase));
    VantCellTypes.InputCellType = InputCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Input, Vant", VantCellTypes.InputCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var NoticeBarCellType = /** @class */ (function (_super) {
        __extends(NoticeBarCellType, _super);
        function NoticeBarCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        NoticeBarCellType.prototype.onPageLoaded = function (info) {
            var self = this;
            var cellType = this.cellType;
            var template = "\n<van-notice-bar\n:mode=\"mode\"\n:text=\"text\"\n:color=\"color\"\nbackground=\"transparent\"\n:left-icon=\"leftIcon\"\n:delay=\"delay\"\n:speed=\"speed\" \n:scrollable=\"scrollable\"\n:wrapable=\"wrapable\"\n@click=\"click\"\n/>";
            if (cellType.scrollMode === "vertical") {
                template = "\n<van-notice-bar\nclass=\"vertical-notice-bar\"\n:left-icon=\"leftIcon\" \n:mode=\"mode\"\n:color=\"color\"\nbackground=\"transparent\" \n@click=\"click\"\n:scrollable=\"false\">\n  <van-swipe\n    vertical\n    ref=\"vant-swipe\"\n    :height=\"swipeItemHeight\"\n    class=\"notice-swipe\"\n    :autoplay=\"autoplay\"\n    :duration=\"duration\"\n    :show-indicators=\"false\"\n  >\n    <van-swipe-item v-for=\"item in items\">{{item}}</van-swipe-item>\n  </van-swipe>\n</van-notice-bar>";
            }
            var option = {
                el: "#" + this.uId,
                template: template,
                data: function () {
                    return {
                        mode: cellType.mode === "none" ? "" : cellType.mode,
                        text: "",
                        color: Forguncy.ConvertToCssColor(self.CellElement.StyleInfo.Foreground),
                        leftIcon: null,
                        delay: cellType.delay,
                        speed: cellType.speed,
                        autoplay: cellType.autoplay,
                        duration: cellType.duration,
                        scrollable: cellType.scrollMode === "horizontal",
                        wrapable: !!self.CellElement.StyleInfo.WordWrap,
                        items: [],
                        swipeItemHeight: null
                    };
                },
                methods: {
                    getValue: function () {
                        return this.text;
                    },
                    setValue: function (value) {
                        var _this = this;
                        var _a;
                        this.text = value === null || value === void 0 ? void 0 : value.toString();
                        this.items = ((_a = value === null || value === void 0 ? void 0 : value.toString()) !== null && _a !== void 0 ? _a : "").split('\r\n');
                        if (cellType.scrollMode === "vertical") {
                            this.$nextTick(function () {
                                _this.$refs["vant-swipe"].resize();
                            });
                        }
                    },
                    click: function () {
                        self.executeCustomCommandObject(cellType.ClickCommand, null, "Click");
                    }
                },
                mounted: function () {
                    self.fontDom = $(this.$el).find(".van-notice-bar__content");
                    this.swipeItemHeight = $(this.$el)[0].offsetHeight;
                },
            };
            this.createVueApp(option);
            self.recalcIcon(this.CellElement.StyleInfo.Foreground);
            _super.prototype.onPageLoaded.call(this, info);
        };
        NoticeBarCellType.prototype.recalcIcon = function (forground) {
            var _this = this;
            if (!this.vue) {
                return;
            }
            var cellType = this.cellType;
            forground = forground !== null && forground !== void 0 ? forground : "#ed6a0c";
            if (cellType.leftIcon) {
                var color = cellType.leftIcon.UseCellTypeForeColor ? forground : cellType.leftIcon.Color;
                if (color !== this.lastIconColor) {
                    this.lastIconColor = color;
                }
                VantCellTypes.IconHelper.getIcon({
                    Name: cellType.leftIcon.Name,
                    BuiltIn: cellType.leftIcon.BuiltIn,
                    Color: color
                }, function (icon) {
                    _this.vue.leftIcon = icon;
                });
            }
        };
        NoticeBarCellType.prototype.setFontStyle = function (styleInfo) {
            if (this.vue) {
                this.vue.color = Forguncy.ConvertToCssColor(styleInfo.Foreground);
                this.vue.wrapable = !!styleInfo.WordWrap;
            }
            this.recalcIcon(styleInfo.Foreground);
            _super.prototype.setFontStyle.call(this, styleInfo);
        };
        NoticeBarCellType.prototype.clickable = function () {
            var _a, _b;
            var cellType = this.cellType;
            return ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) > 0;
        };
        return NoticeBarCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.NoticeBarCellType = NoticeBarCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.NoticeBar, Vant", VantCellTypes.NoticeBarCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var NumberPickerCellType = /** @class */ (function (_super) {
        __extends(NumberPickerCellType, _super);
        function NumberPickerCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        NumberPickerCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        NumberPickerCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var config = cellType.NumberPickerConfig;
            var input = this.getInputTemplate(":maxlength=\"maxlength\" @click=\"onClick\" @change=\"onChange\" clear-trigger=\"always\" @clear=\"onClear\"");
            var option = {
                el: "#" + this.uId,
                template: "\n<div class=\"fgc-vant-inputContainer\">\n    ".concat(input, "\n    <van-number-keyboard\n        v-model=\"value\"\n        class=\"fgc-field-disable-click\"\n        :title=\"title\"\n        :show=\"show\"\n        :extraKey=\"extraKey\"\n        :maxlength=\"maxlength\"\n        :close-button-text=\"closeButtonText\"\n        :delete-button-text=\"deleteButtonText\"\n        :random-key-order=\"randomKeyOrder\"\n        :hide-on-click-outside=\"hideOnClickOutside\"\n        :theme=\"theme\"\n        teleport=\"body\"\n        @blur=\"onFinish\"\n        @input=\"onInput\"\n        @delete=\"onDelete\"\n        @close=\"onFinish\"\n    />\n</div>"),
                data: function () {
                    var baseData = self.getData(cellType);
                    var data = {
                        show: false,
                        extraKey: "",
                        theme: "default",
                        maxlength: undefined,
                        title: undefined,
                        closeButtonText: undefined,
                        deleteButtonText: undefined
                    };
                    if (config.rightPanel) {
                        data.theme = "custom";
                    }
                    config.randomKeyOrder = !!config.randomKeyOrder;
                    config.hideOnClickOutside = !!config.hideOnClickOutside;
                    return __assign(__assign(__assign({ value: "" }, baseData), config), data);
                },
                methods: this.getDefaultMethods({
                    getValue: function () {
                        var number = this.value;
                        if (!self.isEmpty(number) && cellType.convertToNumber) {
                            number = Number(number);
                            number = isNaN(number) ? "" : number;
                        }
                        return number;
                    },
                    setValue: function (value) {
                        var number = value;
                        if (!self.isEmpty(value) && cellType.convertToNumber) {
                            number = Number(value);
                            number = isNaN(number) ? "" : number;
                        }
                        this.value = number;
                    },
                    onFinish: function () {
                        this.show = false;
                        self.commitValue();
                        self.validate();
                    },
                    onClear: function () {
                        this.onChange();
                    },
                    onInput: function () {
                        self.hideValidateTooltip();
                    },
                    onDelete: function () {
                        self.hideValidateTooltip();
                    },
                    onClick: function () {
                        if (!self.isReadOnly() && !self.isDisabled()) {
                            this.show = true;
                        }
                    },
                    onChange: function (value) {
                        this.value = value !== null && value !== void 0 ? value : "";
                        this.onFinish();
                    }
                }),
                mounted: function () {
                    self.setFontToInputDom(this);
                    $(".van-field__control", self.container).attr("readonly", "readonly");
                },
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.maxlength, function (value) {
                _this.vue.maxlength = _this.getMaxLength(value);
            });
            this.onFormulaResultChanged(cellType.NumberPickerConfig.closeButtonText, function (value) {
                _this.vue.closeButtonText = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.NumberPickerConfig.title, function (value) {
                _this.vue.title = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.NumberPickerConfig.deleteButtonText, function (value) {
                _this.vue.deleteButtonText = value === null || value === void 0 ? void 0 : value.toString();
            });
            var updateExtraKey = function () {
                if (_this._extraKey1Result && _this._extraKey2Result) {
                    _this.vue.extraKey = [_this._extraKey1Result, _this._extraKey2Result];
                }
                else if (_this._extraKey1Result) {
                    _this.vue.extraKey = _this._extraKey1Result;
                }
                else {
                    _this.vue.extraKey = "";
                }
            };
            this.onFormulaResultChanged(cellType.NumberPickerConfig.extraKey1, function (value) {
                var _a;
                _this._extraKey1Result = (_a = value === null || value === void 0 ? void 0 : value.toString()) !== null && _a !== void 0 ? _a : "";
                updateExtraKey();
            });
            this.onFormulaResultChanged(cellType.NumberPickerConfig.extraKey2, function (value) {
                var _a;
                _this._extraKey2Result = (_a = value === null || value === void 0 ? void 0 : value.toString()) !== null && _a !== void 0 ? _a : "";
                updateExtraKey();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        NumberPickerCellType.prototype.getMaxLength = function (value) {
            var max = this.calcNumber(value);
            return max ? max : undefined;
        };
        NumberPickerCellType.prototype.ShowPopup = function () {
            this.vue.onClick();
        };
        return NumberPickerCellType;
    }(VantCellTypes.InputBase));
    VantCellTypes.NumberPickerCellType = NumberPickerCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.NumberPicker, Vant", VantCellTypes.NumberPickerCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var PaginationCellType = /** @class */ (function (_super) {
        __extends(PaginationCellType, _super);
        function PaginationCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PaginationCellType.prototype.createContent = function () {
            var cellType = this.cellType;
            if (cellType.ListviewName) {
                Forguncy.ForguncyData.initListviewPaginationInfo(this.runTimePageName, cellType.ListviewName, cellType.itemsPerPage);
            }
            return _super.prototype.createContent.call(this);
        };
        PaginationCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            if (cellType.ListviewName) {
                this._listview = Forguncy.Page.getListViews(true)
                    .filter(function (i) { return i.getName() === cellType.ListviewName && i.getRunTimePageName() === _this.runTimePageName; })[0];
            }
            var listview = this._listview;
            var option = {
                el: "#" + this.uId,
                template: "\n<van-pagination\n    v-show=\"show\"\n    ref=\"van-pagination\"\n    v-model=\"pageNumber\"\n    :mode=\"mode\"\n    :total-items=\"totalItems\"\n    :items-per-page=\"itemsPerPage\"\n    :show-page-size=\"showPageSize\"\n    :prev-text=\"prevText\"\n    :next-text=\"nextText\"\n    :force-ellipses=\"forceEllipsis\"\n    @change=\"pageChange\"\n></van-pagination>\n",
                data: function () {
                    return __assign(__assign(__assign({}, self.getDefaultData(cellType)), cellType), { prevText: undefined, nextText: undefined });
                },
                computed: {
                    show: function (_a) {
                        var totalItems = _a.totalItems, itemsPerPage = _a.itemsPerPage;
                        if (cellType.hideOnOnePage && itemsPerPage > 0) {
                            return totalItems / itemsPerPage > 1;
                        }
                        return true;
                    }
                },
                methods: {
                    setValue: function (value) {
                        var pageIndex = Math.max(1, Number(value));
                        if (Number.isNaN(pageIndex)) {
                            pageIndex = 1;
                        }
                        if (pageIndex !== this.pageNumber) {
                            this.pageNumber = pageIndex;
                        }
                    },
                    getValue: function () {
                        return this.pageNumber;
                    },
                    pageChange: function () {
                        var _a, _b;
                        if ((_b = (_a = cellType.PageChangeCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                            var initValue = {};
                            initValue[cellType.PageChangeCommand.ParamProperties["pageNumber"]] = this.pageNumber;
                            initValue[cellType.PageChangeCommand.ParamProperties["totalItems"]] = this.totalItems;
                            initValue[cellType.PageChangeCommand.ParamProperties["itemsPerPage"]] = this.itemsPerPage;
                            self.executeCustomCommandObject(cellType.PageChangeCommand, initValue);
                        }
                        self.commitValue();
                    },
                    setItemsPerPage: function (itemsPerPage) {
                        this.itemsPerPage = itemsPerPage;
                        if (listview) {
                            listview.usePaginationDisplay(itemsPerPage);
                        }
                    },
                    setCurrentPage: function (pageNumber) {
                        if (listview) {
                            listview.usePaginationDisplay(this.itemsPerPage, pageNumber);
                        }
                    },
                    setTotalItems: function (totalItems) {
                        this.totalItems = totalItems;
                    }
                },
                watch: {
                    pageNumber: function (pageNumber) {
                        this.setCurrentPage(pageNumber);
                    }
                }
            };
            this.createVueApp(option);
            this.commitValue();
            if (listview) {
                this._pagingChangedCallBack = function (data, info) {
                    _this.vue.totalItems = info.TotalRowCount;
                    _this.vue.pageNumber = info.CurrentPageIndex;
                    _this.vue.itemsPerPage = info.MaxRowCountOfOnePage;
                };
                listview.bind(Forguncy.ListViewEvents.PageingInfoChanged, this._pagingChangedCallBack);
            }
            this.onFormulaResultChanged(cellType.prevText, function (value) {
                _this.vue.prevText = value === null || value === void 0 ? void 0 : value.toString();
            });
            this.onFormulaResultChanged(cellType.nextText, function (value) {
                _this.vue.nextText = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        PaginationCellType.prototype.destroy = function () {
            _super.prototype.destroy.call(this);
            if (this._listview) {
                this._listview.unbind(Forguncy.ListViewEvents.PageingInfoChanged, this._pagingChangedCallBack);
            }
        };
        PaginationCellType.prototype.getDefaultData = function (cellType) {
            return {
                pageNumber: 1,
                totalItems: undefined,
                prevText: undefined,
                nextText: undefined,
                forceEllipsis: !!cellType.forceEllipsis
            };
        };
        // runtime methods
        PaginationCellType.prototype.SetItemsPerPage = function (itemsPerPage) {
            var value = Number(itemsPerPage);
            this.vue.setItemsPerPage(value);
        };
        PaginationCellType.prototype.SetCurrentPage = function (pageNumber) {
            var value = Number(pageNumber);
            this.vue.setValue(value);
        };
        PaginationCellType.prototype.SetTotal = function (totalItems) {
            this.vue.setTotalItems(totalItems);
        };
        PaginationCellType.prototype.ExecuteCommand = function () {
            this.vue.pageChange();
        };
        return PaginationCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.PaginationCellType = PaginationCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Pagination, Vant", VantCellTypes.PaginationCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var ProgressCellType = /** @class */ (function (_super) {
        __extends(ProgressCellType, _super);
        function ProgressCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ProgressCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var option = {
                el: "#" + this.uId,
                template: "\n<van-progress\n:percentage=\"percentage\"\n:stroke-width=\"strokeWidth\"\n:color=\"color\"\n:track-color=\"trackColor\"\n:pivot-text=\"pivotText\"\n:pivot-color=\"pivotColor\"\n:text-color=\"textColor\" \n:show-pivot=\"showPivot\" />",
                data: function () {
                    return __assign(__assign(__assign({ percentage: 0 }, cellType), { showPivot: !!cellType.showPivot }), self.convertToCssColor(cellType));
                },
                methods: {
                    getValue: function () {
                        return this.percentage;
                    },
                    setValue: function (value) {
                        var percentage = Number(value);
                        if (!isNaN(percentage)) {
                            this.percentage = percentage;
                        }
                    }
                },
                mounted: function () {
                    self.fontDom = $(this.$el).find(".van-progress__pivot");
                    $("#".concat(self.uId)).addClass("fgc-progress-container");
                },
                updated: function () {
                    self.setFontToDom();
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.pivotText, function (value) {
                _this.vue.pivotText = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        ProgressCellType.prototype.convertToCssColor = function (cellType) {
            var result = {};
            result.trackColor = Forguncy.ConvertToCssColor(cellType.trackColor);
            result.color = Forguncy.ConvertToCssColor(cellType.color);
            result.textColor = Forguncy.ConvertToCssColor(cellType.textColor);
            result.pivotColor = Forguncy.ConvertToCssColor(cellType.pivotColor);
            return result;
        };
        ProgressCellType.prototype.clickable = function () {
            return false;
        };
        ProgressCellType.prototype.ChangeProgressStatus = function (pivotText, pivotColor, textColor, color) {
            if (!this.isEmpty(pivotText)) {
                this.vue.pivotText = pivotText;
            }
            if (!this.isEmpty(pivotColor)) {
                this.vue.pivotColor = Forguncy.ConvertToCssColor(pivotColor);
            }
            if (!this.isEmpty(textColor)) {
                this.vue.textColor = Forguncy.ConvertToCssColor(textColor);
            }
            if (!this.isEmpty(color)) {
                this.vue.color = Forguncy.ConvertToCssColor(color);
            }
        };
        return ProgressCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.ProgressCellType = ProgressCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Progress, Vant", VantCellTypes.ProgressCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var RateCellType = /** @class */ (function (_super) {
        __extends(RateCellType, _super);
        function RateCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        RateCellType.prototype.onPageLoaded = function (info) {
            var self = this;
            var cellType = this.cellType;
            var option = {
                el: "#" + this.uId,
                template: "\n<van-rate\n    v-model=\"value\"\n    :count=\"iconCount\"\n    :size=\"iconSize\"\n    :gutter=\"iconGutter\"\n    :color=\"color\"\n    :void-color=\"voidColor\"\n    :disabled=\"disabled\"\n    :disabled-color=\"disabledColor\"\n    :allow-half=\"allowHalf\"\n    :touchable=\"touchable\"\n    :readonly=\"readonly\"\n    @change=\"onChange\" />\n",
                data: function () {
                    return __assign(__assign(__assign({}, self.getDefaultData(cellType)), cellType), self.convertToCssColor(cellType));
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        var defaultNumber = Number(value);
                        if (!isNaN(defaultNumber)) {
                            this.value = defaultNumber;
                        }
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    },
                    onChange: function () {
                        self.commitValue();
                    }
                }
            };
            this.createVueApp(option);
            _super.prototype.onPageLoaded.call(this, info);
        };
        RateCellType.prototype.getDefaultData = function (cellType) {
            return {
                value: 0,
                disabled: false,
                readonly: false,
                allowHalf: false,
                touchable: false
            };
        };
        RateCellType.prototype.convertToCssColor = function (cellType) {
            var result = {};
            result.color = Forguncy.ConvertToCssColor(cellType.color);
            result.voidColor = Forguncy.ConvertToCssColor(cellType.voidColor);
            result.disabledColor = Forguncy.ConvertToCssColor(cellType.disabledColor);
            return result;
        };
        RateCellType.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.refreshClickable();
        };
        RateCellType.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this.refreshClickable();
        };
        RateCellType.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this.refreshClickable();
        };
        RateCellType.prototype.refreshClickable = function () {
            var _a, _b;
            if ((_a = this.vue) === null || _a === void 0 ? void 0 : _a.$el) {
                (_b = $(this.vue.$el).parent()) === null || _b === void 0 ? void 0 : _b.attr("clickable", this.clickable() ? true : "");
            }
        };
        RateCellType.prototype.clickable = function () {
            return !this.isReadOnly() && !this.isDisabled();
        };
        return RateCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.RateCellType = RateCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Rate, Vant", VantCellTypes.RateCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var SelectorCellType = /** @class */ (function (_super) {
        __extends(SelectorCellType, _super);
        function SelectorCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SelectorCellType.prototype.setDataSource = function (dataSource, userAction) {
            var _a;
            if (userAction === void 0) { userAction = false; }
            if (userAction) {
                this.vue.cellValue = null;
                this.commitValue();
            }
            var cloneDataSource = __spreadArray([], dataSource, true);
            if (this.cellType.AllowAddEmptyItem) {
                var label = this.getApplicationResource((_a = this.cellType.EmptyItemLabel) !== null && _a !== void 0 ? _a : "");
                if (!label) {
                    this.vue.placeholder = null;
                }
                cloneDataSource.unshift({ value: "", label: label });
            }
            return this.vue.setOptions(cloneDataSource);
        };
        SelectorCellType.prototype.getEmptyValue = function (options) {
            var _a;
            return ((_a = options.find(function (o) { return o.value === ""; })) === null || _a === void 0 ? void 0 : _a.label) || null;
        };
        SelectorCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var config = cellType.SelectorConfig;
            var input = this.getInputTemplate("@click=\"onClick\" clear-trigger=\"always\" @clear=\"onClear\" :clear-icon=\"clearIconName\" ");
            var optionStr = this.getCustomSlotByPath(VantCellTypes.SlotPath.pickerOption);
            var options = [];
            var value = null;
            if (!cellType.useBinding) {
                options = cellType.options.map(function (o) { return self.convertOption(o); });
                value = this.getEmptyValue(options);
            }
            var option = {
                template: "\n<div class=\"fgc-vant-inputContainer\">\n    ".concat(input, "\n    <van-popup v-model:show=\"show\" position=\"bottom\" teleport=\"body\">\n      <van-picker\n        ref=\"van-picker\"\n        :columns=\"columns\"\n        :title=\"title\"\n        :confirm-button-text=\"confirmButtonText\"\n        :cancel-button-text=\"cancelButtonText\"\n        :item-height=\"itemHeight\"\n        :visible-item-count=\"visibleItemCount\"\n        :show-toolbar=\"showToolbar\"\n        :swipe-duration=\"swipeDuration\"\n        @cancel=\"show=false\"\n        @confirm=\"onFinish\"\n        @change=\"onChange\"\n      >\n        ").concat(optionStr ? "<template #option='data'>" + optionStr + "</template>" : "", "\n      </van-picker>\n    </van-popup>\n</div>"),
                data: function () {
                    var baseData = self.getData(cellType);
                    var columns = [];
                    if (!cellType.useBinding && options && options.length > 0) {
                        columns = options.map(function (i) { return i.label; });
                    }
                    var data = __assign(__assign({ show: false, columns: columns, cellValue: "", tempValue: null, tempIndex: null }, VantCellTypes.getPickerValidToolbarOption(config)), { options: options });
                    config.showToolbar = !!config.showToolbar;
                    return __assign(__assign(__assign(__assign({}, baseData), config), data), { value: value });
                },
                computed: {
                    // 通过clear icon name 来控制clear icon的显示
                    clearIconName: function (_a) {
                        var cellValue = _a.cellValue;
                        return cellValue === "" ? "" : undefined;
                    }
                },
                watch: {
                    value: function (newValue) {
                        if (self.isEmpty(newValue)) {
                            this.value = self.getEmptyValue(this.options);
                        }
                    },
                    show: function (value) {
                        if (!value && !this.showToolbar && this.tempIndex !== null) {
                            this.onFinish(this.tempValue, this.tempIndex);
                        }
                    }
                },
                methods: this.getDefaultMethods({
                    onFinish: function (value, index) {
                        this.show = false;
                        this.cellValue = self.isEmpty(index) ? "" : this.options[index].value;
                        this.value = value;
                        this.tempValue = null;
                        this.tempIndex = null;
                        self.commitValue();
                        self.validate();
                    },
                    onClear: function () {
                        this.onFinish(null, null);
                    },
                    onChange: function (value, index) {
                        this.tempValue = value;
                        this.tempIndex = index;
                    },
                    setOptions: function (dataSource) {
                        dataSource = dataSource.map(function (o) { return self.convertOption(o); });
                        this.options = dataSource;
                        if (dataSource && dataSource.length) {
                            this.columns = dataSource.map(function (i) { return i.label; });
                            this.updateValue();
                        }
                        else {
                            this.columns = [];
                            this.value = null;
                        }
                    },
                    onClick: function () {
                        var _this = this;
                        if (!self.isReadOnly() && !self.isDisabled()) {
                            this.show = true;
                            if (this.options) {
                                /*eslint-disable-next-line*/
                                var index_1 = this.options.findIndex(function (i) { return i.value == _this.cellValue; });
                                this.$nextTick(function () {
                                    _this.$refs["van-picker"].setColumnIndex(0, index_1 > 0 ? index_1 : 0);
                                });
                            }
                        }
                    },
                    getValue: function () {
                        return this.cellValue;
                    },
                    setValue: function (value) {
                        if (this.cellValue !== value) {
                            this.cellValue = (value === null || value === void 0 ? void 0 : value.toString()) || "";
                            this.updateValue();
                        }
                    },
                    updateValue: function () {
                        var _this = this;
                        /*eslint-disable-next-line*/
                        var item = this.options.filter(function (i) { return i.value == _this.cellValue; })[0];
                        this.value = item ? item.label : this.cellValue;
                    },
                }),
                mounted: function () {
                    self.setFontToInputDom(this);
                    $(".van-field__control", self.container).attr("readonly", "readonly");
                }
            };
            this.createVueApp(option);
            VantCellTypes.setPickerValidToolbarOptionToVue(this, cellType.SelectorConfig, this.vue);
            if (cellType.useBinding) {
                VantCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource, userAction) {
                    _this.setDataSource(dataSource, userAction);
                }, true, {
                    distinct: true
                });
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        SelectorCellType.prototype.reload = function () {
            var _this = this;
            if (this.cellType.useBinding) {
                VantCellTypes.SupportDataSourceCellType.refreshData(this, this.cellType.bindingOptions, function (dataSource, userAction) {
                    _this.setDataSource(dataSource, userAction);
                }, true, {
                    distinct: true
                });
            }
        };
        SelectorCellType.prototype.getSelectedItem = function () {
            var _this = this;
            return this.vue.options.find(function (option) {
                var _a, _b;
                return option.value === _this.vue.cellValue
                    || ((_a = option.value) === null || _a === void 0 ? void 0 : _a.toString()) === ((_b = _this.vue.cellValue) === null || _b === void 0 ? void 0 : _b.toString())
                    || option.value == _this.vue.cellValue;
            }) || null;
        };
        SelectorCellType.prototype.SetDataSourceByStringArray = function (dataSource) {
            if (!dataSource) {
                dataSource = [];
            }
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            var objSource = dataSource.map(function (i) { return ({
                "value": i,
                "label": i,
            }); });
            this.setDataSource(objSource);
        };
        SelectorCellType.prototype.SetDataSourceByObjArray = function (dataSource, valueProperty, labelProperty) {
            if (!dataSource) {
                dataSource = [];
            }
            if (typeof dataSource === "string") {
                dataSource = JSON.parse(dataSource);
            }
            if (!labelProperty) {
                labelProperty = valueProperty;
            }
            var objSource = dataSource.map(function (i) { return ({
                "value": i[valueProperty],
                "label": i[labelProperty],
            }); });
            this.setDataSource(objSource);
        };
        SelectorCellType.prototype.ShowPopup = function () {
            this.vue.onClick();
        };
        SelectorCellType.prototype.GetSelectedText = function () {
            var _a;
            return {
                SelectedText: (_a = this.getSelectedItem()) === null || _a === void 0 ? void 0 : _a.label
            };
        };
        SelectorCellType.prototype.convertOption = function (item) {
            var _a;
            return __assign(__assign({}, item), { value: (_a = item.value) !== null && _a !== void 0 ? _a : "", label: this.format(this.getApplicationResource(item.label)) });
        };
        return SelectorCellType;
    }(VantCellTypes.InputBase));
    VantCellTypes.SelectorCellType = SelectorCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Selector, Vant", VantCellTypes.SelectorCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var SliderCellType = /** @class */ (function (_super) {
        __extends(SliderCellType, _super);
        function SliderCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._minResult = undefined;
            _this._maxResult = undefined;
            return _this;
        }
        SliderCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var Min = Math.min, Max = Math.max;
            var self = this;
            var cellType = this.cellType;
            this.getContainer().css("overflow", "");
            var option = {
                el: "#" + this.uId,
                template: "\n<div class=\"fgc-vant-slider\" :style=\"{ padding: buttonSize / 2 + 'px' }\">\n    <van-slider\n        v-model=\"value\"\n        :min=\"min\"\n        :max=\"max\"\n        :step=\"step\"\n        :bar-height=\"barHeight\"\n        :button-size=\"buttonSize\"\n        :active-color=\"activeColor\"\n        :inactive-color=\"inactiveColor\"\n        :range=\"range\"\n        :reverse=\"reverse\"\n        :disabled=\"disabled\"\n        :readonly=\"readonly\"\n        :vertical=\"vertical\"\n        @change=\"handleChange\"\n    >\n    </van-slider>\n</div>\n",
                data: function () {
                    return {
                        value: undefined,
                        min: undefined,
                        max: undefined,
                        step: undefined,
                        barHeight: cellType.barHeight,
                        buttonSize: cellType.buttonSize,
                        activeColor: Forguncy.ConvertToCssColor(cellType.activeColor),
                        inactiveColor: Forguncy.ConvertToCssColor(cellType.inactiveColor),
                        range: !!cellType.range,
                        reverse: !!cellType.reverse,
                        vertical: !!cellType.vertical,
                        readonly: false,
                        disabled: false
                    };
                },
                methods: {
                    getValue: function () {
                        var _this = this;
                        if (Array.isArray(this.value)) {
                            var values = this.value.map(function (item) {
                                return Min(Max(Number(item), _this.min), _this.max);
                            });
                            return values.join(",");
                        }
                        return Min(Max(Number(this.value), this.min), this.max);
                    },
                    setValue: function (value) {
                        var _this = this;
                        if (self.isEmpty(value)) {
                            this.value = this.range ? [this.min, this.max] : this.min;
                        }
                        else if (typeof value === "number") {
                            this.value = Min(Max(value, this.min), this.max);
                        }
                        else if (typeof value === "string") {
                            if (this.range) {
                                if (value.indexOf(",") !== -1) {
                                    this.value = value.split(",").map(function (i) { return Min(Max(Number(i), _this.min), _this.max); });
                                }
                                else {
                                    this.value = [this.min, this.max];
                                }
                            }
                            else {
                                this.value = Min(Max(Number(value), this.min), this.max);
                            }
                        }
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    handleChange: function () {
                        self.commitValue();
                    }
                }
            };
            this.createVueApp(option);
            var updateMaxMin = function () {
                var min = _this._minResult;
                var max = _this._maxResult;
                min = min !== null && min !== void 0 ? min : 0;
                max = max !== null && max !== void 0 ? max : 100;
                min = isNaN(min) ? 0 : min;
                max = isNaN(max) ? 100 : max;
                if (min > max) {
                    min = 0;
                    max = 100;
                }
                _this.vue.min = min;
                _this.vue.max = max;
            };
            this.onFormulaResultChanged(cellType.min, function (value) {
                _this._minResult = _this.calcNumber(value);
                updateMaxMin();
            });
            this.onFormulaResultChanged(cellType.max, function (value) {
                _this._maxResult = _this.calcNumber(value);
                updateMaxMin();
            });
            this.onFormulaResultChanged(cellType.step, function (value) {
                _this.vue.step = _this.calcNumber(value);
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        return SliderCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.SliderCellType = SliderCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Slider, Vant", VantCellTypes.SliderCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var StepperCellType = /** @class */ (function (_super) {
        __extends(StepperCellType, _super);
        function StepperCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        StepperCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var _a;
            var self = this;
            var cellType = this.cellType;
            var option = {
                template: "\n<van-stepper\n    class=\"fgc-vant-stepper\"\n    v-model=\"value\"\n    :min=\"min\"\n    :max=\"max\"\n    :step=\"step\"\n    :decimal-length=\"decimalLength\"\n    :placeholder=\"placeholder\"\n    :theme=\"theme\"\n    :integer=\"integer\"\n    :allow-empty=\"allowEmpty\"\n    :show-input=\"showInput\"\n    :show-plus=\"showPlus\"\n    :show-minus=\"showMinus\"\n    :disabled=\"disabled\"\n    :disable-input=\"disableInput\"\n    :long-press=\"longPress\"\n    :button-size=\"buttonSize + 'px'\"\n    :default-value=\"''\"\n    @plus=\"commitValue\"\n    @minus=\"commitValue\"\n    @blur=\"commitValue\"\n>\n</van-stepper>\n",
                data: function () {
                    return {
                        value: undefined,
                        min: undefined,
                        max: undefined,
                        step: undefined,
                        buttonSize: self.calcNumber(cellType.buttonSize),
                        decimalLength: self.calcNumber(cellType.decimalLength),
                        placeholder: undefined,
                        theme: cellType.theme,
                        integer: !!cellType.integer,
                        allowEmpty: !!cellType.allowEmpty,
                        showInput: !!cellType.showInput,
                        showPlus: !!cellType.showPlus,
                        showMinus: !!cellType.showMinus,
                        disabled: !!cellType.IsDisabled,
                        disableInput: !!cellType.disableInput,
                        longPress: !!cellType.longPress,
                    };
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        this.value = self.isEmpty(value) ? "" : value;
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    commitValue: function () {
                        Vue.nextTick(function () {
                            self.commitValue();
                            self.validate();
                        });
                    }
                },
                mounted: function () {
                    self.fontDom = $(".van-stepper__input", self.container);
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.min, function (value) {
                _this.vue.min = _this.calcNumber(value);
            });
            this.onFormulaResultChanged(cellType.max, function (value) {
                _this.vue.max = _this.calcNumber(value);
            });
            this.onFormulaResultChanged(cellType.step, function (value) {
                _this.vue.step = _this.calcNumber(value);
            });
            this.onFormulaResultChanged(cellType.placeholder, function (value) {
                _this.vue.placeholder = value === null || value === void 0 ? void 0 : value.toString();
            });
            this._inputTextCache = (_a = this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString();
            this.getContainer().keyup(function () {
                var _a, _b;
                if (_this._inputTextCache !== ((_a = _this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString())) {
                    _this.hideValidateTooltip();
                }
                _this._inputTextCache = (_b = _this.getValueFromElement()) === null || _b === void 0 ? void 0 : _b.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        // runtime methods
        StepperCellType.prototype.SetMinValue = function (value) {
            this.vue.min = Number(value);
        };
        StepperCellType.prototype.SetMaxValue = function (value) {
            this.vue.max = Number(value);
        };
        StepperCellType.prototype.SetStepSize = function (value) {
            this.vue.step = Number(value);
        };
        StepperCellType.prototype.SetFocus = function () {
            $("#".concat(this.uId)).find(".van-stepper__input").focus();
        };
        // 支持本体的设置焦点命令
        StepperCellType.prototype.setFocus = function () {
            this.SetFocus();
        };
        StepperCellType.prototype.hasFocus = function () {
            var dom = $(".van-stepper__input", this.getContainer());
            return dom.length && document.activeElement === dom[0];
        };
        StepperCellType.prototype.setValueToElement = function (jElement, value) {
            var _a;
            _super.prototype.setValueToElement.call(this, jElement, value);
            this._inputTextCache = (_a = this.getValueFromElement()) === null || _a === void 0 ? void 0 : _a.toString();
        };
        return StepperCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.StepperCellType = StepperCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Stepper, Vant", VantCellTypes.StepperCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var StepsCellType = /** @class */ (function (_super) {
        __extends(StepsCellType, _super);
        function StepsCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        StepsCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var option = {
                template: "\n<van-steps\n    :active=\"active\"\n    :direction=\"direction\"\n    :active-icon=\"activeIcon\"\n    :active-color=\"activeColor\"\n    :inactive-icon=\"inactiveIcon\"\n    :inactive-color=\"inactiveColor\"\n    :finish-icon=\"finishIcon\"\n>\n    <van-step :key=\"key\" v-for=\"({ key, title }, index) in stepsOptions\">\n        {{ title }}\n    </van-step>\n</van-steps>\n",
                data: function () {
                    return __assign(__assign(__assign(__assign({}, self.getDefaultData()), cellType), self.convertToCssColor(cellType)), { activeIcon: "checked", inactiveIcon: "", finishIcon: "" });
                },
                computed: {
                    stepsOptions: function (_a) {
                        var useBinding = _a.useBinding, bindingOptions = _a.bindingOptions, options = _a.options;
                        var stepsOptions = useBinding ? bindingOptions : options;
                        if (Array.isArray(stepsOptions)) {
                            stepsOptions.forEach(function (op) { return op.title = self.getApplicationResource(op.title); });
                            return self.uniqueKeyCreator(stepsOptions, "value");
                        }
                        return [];
                    }
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        this.value = value;
                        this.updateActive();
                    },
                    setBindingOptions: function (options) {
                        this.bindingOptions = options;
                        this.updateActive();
                    },
                    updateActive: function () {
                        var _this = this;
                        // 这里认为字符串数字与数字等价，双等号不能去掉
                        // eslint-disable-next-line
                        var index = this.stepsOptions.findIndex(function (step) { return step.value == _this.value; });
                        if (index > -1) {
                            this.active = index;
                            return;
                        }
                        if (this.value || this.value === 0) {
                            this.active = this.stepsOptions.length;
                        }
                        else {
                            this.active = -1;
                        }
                    }
                }
            };
            this.createVueApp(option);
            VantCellTypes.IconHelper.getIcon(cellType.activeIcon, function (icon) {
                _this.vue.activeIcon = icon;
            });
            VantCellTypes.IconHelper.getIcon(cellType.inactiveIcon, function (icon) {
                _this.vue.inactiveIcon = icon;
            });
            VantCellTypes.IconHelper.getIcon(cellType.finishIcon, function (icon) {
                _this.vue.finishIcon = icon;
            });
            this.ReloadBindingItems();
            _super.prototype.onPageLoaded.call(this, info);
        };
        StepsCellType.prototype.getDefaultData = function () {
            return {
                active: -1,
                value: null,
                useBinding: false,
                options: [],
                bindingOptions: [],
                DefaultValue: ""
            };
        };
        StepsCellType.prototype.convertToCssColor = function (cellType) {
            var result = {};
            result.activeColor = Forguncy.ConvertToCssColor(cellType.activeColor);
            result.inactiveColor = Forguncy.ConvertToCssColor(cellType.inactiveColor);
            return result;
        };
        StepsCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        StepsCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                VantCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        StepsCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setBindingOptions(dataSource);
        };
        StepsCellType.prototype.UpdateActiveIcon = function (activeIcon) {
            var _this = this;
            VantCellTypes.IconHelper.getIcon(activeIcon, function (icon) {
                _this.vue.activeIcon = icon;
            });
        };
        StepsCellType.prototype.UpdateActiveColor = function (activeColor) {
            this.vue.activeColor = Forguncy.ConvertToCssColor(activeColor);
        };
        return StepsCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.StepsCellType = StepsCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Steps, Vant", VantCellTypes.StepsCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var SwipeCellType = /** @class */ (function (_super) {
        __extends(SwipeCellType, _super);
        function SwipeCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        SwipeCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var option = {
                template: "\n<van-swipe\n    ref=\"van-swipe\"\n    :vertical=\"vertical\"\n    :autoplay=\"autoplay\"\n    :show-indicators=\"showIndicators\"\n    :indicator-color=\"indicatorColor\"\n    :loop=\"loop\"\n    :touchable=\"touchable\"\n    class=\"fgc-media-swiper\"\n>\n    <van-swipe-item\n        :ref=\"'swipe-item' + index\"\n        :key=\"item.src\"\n        v-for=\"(item, index) in items\"\n        @click=\"onSwipeItemClick($event, index, item.value)\"\n    >\n        <div class=\"van-image van-image-preview__image\" style=\"transition-duration: 0.3s;height:100%;\">\n            <img @load=\"onImageLoad($event, index, item.value)\" :src=\"item.src\" class=\"van-image__img\" style=\"object-fit: contain;\" />\n        </div>\n    </van-swipe-item>\n</van-swipe>\n",
                data: function () {
                    var _a;
                    return {
                        items: [],
                        vertical: !!cellType.vertical,
                        autoplay: (_a = cellType.autoplay) !== null && _a !== void 0 ? _a : undefined,
                        showIndicators: !!cellType.showIndicators,
                        indicatorColor: Forguncy.ConvertToCssColor(cellType.indicatorColor),
                        loop: !!cellType.loop,
                        touchable: !!cellType.touchable
                    };
                },
                methods: {
                    onSwipeItemClick: function (e, index, value) {
                        var _this = this;
                        var _a, _b;
                        if (cellType.preview) {
                            var uniqueClass_1 = "image-preview" + self.uId;
                            window.vant.ImagePreview({
                                images: this.items.map(function (item) { return item.src; }),
                                startPosition: index,
                                closeable: true,
                                className: uniqueClass_1
                            });
                            this.$nextTick(function () {
                                var previewItems = $(".".concat(uniqueClass_1)).find(".van-swipe-item");
                                _this.items.forEach(function (item, idx) {
                                    self.InsertPreviewItemTemplate(previewItems[idx], item.value);
                                });
                            });
                        }
                        else {
                            if ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                                var initValue = {};
                                initValue[cellType.ClickCommand.ParamProperties["value"]] = value;
                                self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                            }
                        }
                    },
                    onImageLoad: function (e, index, value) {
                        var swipeItems = $(".van-swipe-item", self.container);
                        self.InsertSwipeItemTemplate(swipeItems[index], value);
                    },
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                VantCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                    if (dataSource !== null) {
                        _this.vue.items = [];
                        dataSource.forEach(function (_a) {
                            var value = _a.value, image = _a.image;
                            if (typeof image === "string") {
                                image === null || image === void 0 ? void 0 : image.split("|").forEach(function (fileName) {
                                    if (fileName) {
                                        _this.vue.items.push({
                                            value: value,
                                            src: _this.GetBindImagePath(fileName)
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
            else {
                this.vue.items = cellType.imageItems.map(function (_a) {
                    var value = _a.value, image = _a.image;
                    var imageItem = {
                        value: value,
                        src: ""
                    };
                    VantCellTypes.IconHelper.getIcon(image, function (url) {
                        imageItem.src = url;
                    });
                    return imageItem;
                });
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        SwipeCellType.prototype.GetBindImagePath = function (image) {
            if (image) {
                //Support external image source.
                if (image.indexOf("http://") === 0 || image.indexOf("https://") === 0) {
                    return image;
                }
                //IE 11 does not support startswith function.
                if (image.indexOf("data:image/png;base64") === 0) {
                    return image;
                }
                return Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer() + encodeURIComponent(image);
            }
            return null;
        };
        // runtime methods
        SwipeCellType.prototype.SwitchToPrev = function () {
            this.vue.$refs["van-swipe"].prev();
        };
        SwipeCellType.prototype.SwitchToNext = function () {
            this.vue.$refs["van-swipe"].next();
        };
        SwipeCellType.prototype.SwitchTo = function (number) {
            var index = Number(number) - 1;
            this.vue.$refs["van-swipe"].swipeTo(index);
        };
        // video display interface
        SwipeCellType.prototype.InsertSwipeItemTemplate = function (el, ID) {
            var func = this.getCustomFeatureByPath(VantCellTypes.FeaturePath.swipeItem);
            return func && func(el, ID);
        };
        SwipeCellType.prototype.InsertPreviewItemTemplate = function (el, ID) {
            var func = this.getCustomFeatureByPath(VantCellTypes.FeaturePath.swipePreviewItem);
            return func && func(el, ID);
        };
        return SwipeCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.SwipeCellType = SwipeCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Swipe, Vant", VantCellTypes.SwipeCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var TabsCellType = /** @class */ (function (_super) {
        __extends(TabsCellType, _super);
        function TabsCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TabsCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var tabs = [];
            if (!cellType.useBinding && cellType.tabs) {
                tabs = this.getTabs(cellType.tabs);
            }
            var option = {
                template: "\n<van-tabs\n    ref=\"van-tabs\"\n    v-model:active=\"active\"\n    :type=\"type\"\n    :color=\"color\"\n    :duration=\"duration\"\n    :background=\"background\"\n    :titleActiveColor=\"titleActiveColor\"\n    :titleInactiveColor=\"titleInactiveColor\"\n    :lineWidth=\"lineWidth\"\n    :lineHeight=\"lineHeight\"\n    :ellipsis=\"ellipsis\"\n    :shrink=\"shrink\"\n    @click-tab=\"tabClick\">\n    <van-tab\n        v-for=\"(tab, index) in tabs\"\n        :key=\"index\"\n        :name=\"tab.valueStr\"\n        :title=\"tab.title\"\n        :dot=\"showAsDot(tab)\"\n        :badge=\"tab.badge\">\n    </van-tab>\n</van-tabs>\n",
                data: function () {
                    return __assign(__assign(__assign(__assign({}, self.getDefaultData()), cellType), self.convertToCssColor(cellType)), { tabs: tabs, active: null, duration: 0.3, ellipsis: !!cellType.ellipsis });
                },
                methods: {
                    tabClick: function (tab) {
                        var _a, _b;
                        var index = this.tabs.map(function (i) { return i.valueStr; }).indexOf(tab.name);
                        if ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                            var initValue = {};
                            initValue[cellType.ClickCommand.ParamProperties["itemIndex"]] = index + 1;
                            initValue[cellType.ClickCommand.ParamProperties["itemValue"]] = this.tabs[index].value;
                            initValue[cellType.ClickCommand.ParamProperties["itemText"]] = tab.title;
                            self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                        }
                        this.value = this.tabs[index].value;
                        self.commitValue();
                    },
                    setValue: function (value) {
                        var _this = this;
                        this.value = value;
                        try {
                            this.duration = 0;
                            this.active = value === null || value === void 0 ? void 0 : value.toString();
                        }
                        finally {
                            Vue.nextTick(function () {
                                _this.duration = 0.3;
                            });
                        }
                    },
                    getValue: function () {
                        return this.value;
                    },
                    showAsDot: function (tab) {
                        return self.isEmpty(tab.badge) ? false : !!tab.dot;
                    }
                },
                mounted: function () {
                    self.fontSelector = ".van-tab__text";
                    self.updateColorVar("--van-tabs-bottom-bar-color", cellType.color);
                }
            };
            this.createVueApp(option);
            if (cellType.useBinding) {
                VantCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) {
                    if (dataSource) {
                        dataSource.every(function (i) { var _a; return i.valueStr = (_a = i.value) === null || _a === void 0 ? void 0 : _a.toString(); });
                    }
                    _this.vue.tabs = _this.getTabs(dataSource !== null && dataSource !== void 0 ? dataSource : []);
                });
            }
            else {
                var _loop_3 = function (tab) {
                    this_2.onFormulaResultChanged(tab.sourceBadge, function (value) {
                        tab.badge = value;
                    });
                };
                var this_2 = this;
                for (var _i = 0, _a = this.vue.tabs; _i < _a.length; _i++) {
                    var tab = _a[_i];
                    _loop_3(tab);
                }
            }
            _super.prototype.onPageLoaded.call(this, info);
        };
        TabsCellType.prototype.getDefaultData = function () {
            return {
                tabs: [],
                shrink: false,
                ellipsis: true
            };
        };
        TabsCellType.prototype.getTabs = function (tabs) {
            var _this = this;
            return tabs === null || tabs === void 0 ? void 0 : tabs.map(function (tab) {
                var _a;
                return {
                    title: _this.getApplicationResource(tab.title),
                    dot: !!tab.dot,
                    value: tab.value,
                    valueStr: (_a = tab.value) === null || _a === void 0 ? void 0 : _a.toString(),
                    sourceBadge: tab.badge,
                    badge: null
                };
            });
        };
        TabsCellType.prototype.convertToCssColor = function (cellType) {
            var result = {};
            result.color = Forguncy.ConvertToCssColor(cellType.color);
            result.background = Forguncy.ConvertToCssColor(cellType.background);
            result.titleActiveColor = Forguncy.ConvertToCssColor(cellType.titleActiveColor);
            result.titleInactiveColor = Forguncy.ConvertToCssColor(cellType.titleInactiveColor);
            return result;
        };
        TabsCellType.prototype.onWindowResized = function () {
            var _a, _b;
            (_b = (_a = this.vue) === null || _a === void 0 ? void 0 : _a.$refs["van-tabs"]) === null || _b === void 0 ? void 0 : _b.resize();
        };
        // RunTimeMethod
        TabsCellType.prototype.SetBadge = function (itemValue, badgeValue) {
            for (var _i = 0, _a = this.vue.tabs; _i < _a.length; _i++) {
                var item = _a[_i];
                var tabItem = item;
                // eslint-disable-next-line
                if (tabItem.value == itemValue) {
                    item.badge = badgeValue === null || badgeValue === void 0 ? void 0 : badgeValue.toString();
                }
            }
        };
        TabsCellType.prototype.HideItems = function (value) {
            var _a;
            var itemArray = (_a = value === null || value === void 0 ? void 0 : value.split(',')) === null || _a === void 0 ? void 0 : _a.map(function (item) { return item.toString(); });
            if (!(itemArray === null || itemArray === void 0 ? void 0 : itemArray.length)) {
                return;
            }
            this.vue.tabs = this.vue.tabs.filter(function (tab) { var _a; return !itemArray.includes((_a = tab.value) === null || _a === void 0 ? void 0 : _a.toString()); });
        };
        return TabsCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.TabsCellType = TabsCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Tabs, Vant", VantCellTypes.TabsCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var TagTheme;
    (function (TagTheme) {
        TagTheme["default"] = "default";
        TagTheme["plain"] = "plain";
        TagTheme["round"] = "round";
        TagTheme["mark"] = "mark";
    })(TagTheme || (TagTheme = {}));
    var TagCellType = /** @class */ (function (_super) {
        __extends(TagCellType, _super);
        function TagCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TagCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var cellType = this.cellType;
            var _a = this.CellElement.StyleInfo.WordWrap, WordWrap = _a === void 0 ? false : _a;
            var self = this;
            var style = null;
            if (WordWrap) {
                style = {
                    "overflow-y": "auto"
                };
            }
            else {
                style = {
                    "display": "flex",
                    "align-items": "center",
                    "overflow-x": "auto"
                };
            }
            $("#".concat(this.uId)).css(style);
            var template = "\n<van-tag\n    v-for=\"(tag, index) in tags\"\n    :key=\"tag.key\"\n    :size=\"size\"\n    :color=\"tag.color\"\n    :plain=\"plain\"\n    :round=\"round\"\n    :mark=\"mark\"\n    :closeable=\"!readonly\"\n    @click=\"onTagClick\"\n    @close.stop=\"onTagClose\"\n    :style=\"getTagStyle(index, tags.length)\"\n>\n{{ tag.label }}\n</van-tag>\n<template v-if=\"!readonly && allowAdd && !inputVisible\">\n    <van-tag\n        type=\"primary\"\n        :size=\"size\"\n        :plain=\"plain\"\n        :round=\"round\"\n        :mark=\"mark\"\n        @click=\"showInput\"\n        class=\"van-tag-button\"\n        :style=\"{ ...buttonFieldStyle, justifyContent: 'center' }\"\n    >\n        {{ buttonText }}\n    </van-tag>\n</template>\n<template v-if=\"!readonly && allowAdd && inputVisible\">\n    <van-field\n        ref=\"saveTagInput\"\n        v-model=\"inputValue\"\n        @blur=\"handleInputConfirm\"\n        @keyup.enter.native=\"handleInputConfirm\"\n        :style=\"fieldStyle\"\n    ></van-field>\n</template>\n";
            var option = {
                template: template,
                data: function () {
                    return {
                        tags: [],
                        size: cellType.size,
                        gutter: cellType.gutter,
                        plain: cellType.theme === TagTheme.plain,
                        round: cellType.theme === TagTheme.round,
                        mark: cellType.theme === TagTheme.mark,
                        readonly: false,
                        buttonText: undefined,
                        buttonWidth: cellType.addButtonSettings.width,
                        buttonSpace: cellType.addButtonSettings.space,
                        inputValue: "",
                        inputVisible: false,
                        allowAdd: !!cellType.allowAdd,
                        fieldHeight: "0px",
                        wordWrap: !!WordWrap
                    };
                },
                computed: {
                    buttonFieldStyle: function (_a) {
                        var buttonWidth = _a.buttonWidth, gutter = _a.gutter, wordWrap = _a.wordWrap;
                        var style = {
                            width: buttonWidth + "px",
                            minWidth: buttonWidth + "px"
                        };
                        if (wordWrap) {
                            style["marginBottom"] = gutter + "px";
                        }
                        return style;
                    },
                    fieldStyle: function (_a) {
                        var buttonFieldStyle = _a.buttonFieldStyle, fieldHeight = _a.fieldHeight, wordWrap = _a.wordWrap;
                        var style = __assign(__assign({}, buttonFieldStyle), { height: fieldHeight });
                        if (wordWrap) {
                            style.display = "inline-flex";
                            style.verticalAlign = "top";
                        }
                        return style;
                    }
                },
                methods: {
                    getValue: function () {
                        return this.tags.map(function (tag) { return tag.label; }).join(cellType.separator);
                    },
                    setValue: function (value) {
                        if (self.isEmpty(value)) {
                            this.tags = [];
                            return;
                        }
                        if (typeof value !== "string") {
                            value = value + "";
                        }
                        this.tags = value.split(cellType.separator).filter(function (tag) { return tag !== ""; });
                        if (cellType.distinct) {
                            this.tags = this.distinct(this.tags);
                        }
                        var colors = cellType.ColorList.map(function (color) { return Forguncy.ConvertToCssColor(color.color); });
                        this.tags = this.tags.map(function (tag, index, arr) {
                            return {
                                key: cellType.distinct ? tag : index,
                                label: tag,
                                color: colors[index % colors.length]
                            };
                        });
                    },
                    getTagStyle: function (index, length) {
                        var style = {
                            flex: "none",
                            marginRight: index === length - 1 ? this.buttonSpace + 'px' : this.gutter + 'px'
                        };
                        if (this.wordWrap) {
                            style["marginBottom"] = this.gutter + 'px';
                        }
                        return style;
                    },
                    onTagClick: function (event) {
                        var _a, _b;
                        if ((_b = (_a = cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) === null || _b === void 0 ? void 0 : _b.length) {
                            var index = this.getEventIndex(event, "van-tag");
                            if (index >= 0) {
                                var initValue = {};
                                initValue[cellType.ClickCommand.ParamProperties["itemName"]] = this.tags[index].label;
                                self.executeCustomCommandObject(cellType.ClickCommand, initValue);
                            }
                        }
                    },
                    onTagClose: function (event) {
                        var index = this.getEventIndex(event, "van-tag__close");
                        if (index >= 0) {
                            this.tags.splice(index, 1);
                            self.commitValue();
                        }
                    },
                    getEventIndex: function (event, className) {
                        var clickItem = event.target;
                        var items = $(".".concat(className), self.getContainer());
                        for (var i = 0; i < items.length; i++) {
                            var item = items[i];
                            if (item === clickItem) {
                                return i;
                            }
                        }
                    },
                    distinct: function (arr) {
                        var result = [];
                        var obj = {};
                        for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
                            var i = arr_1[_i];
                            if (obj[i]) {
                                continue;
                            }
                            obj[i] = true;
                            result.push(i);
                        }
                        return result;
                    },
                    showInput: function () {
                        var _this = this;
                        this.inputVisible = true;
                        this.$nextTick(function (_) {
                            _this.$refs.saveTagInput.focus();
                        });
                    },
                    handleInputConfirm: function () {
                        var inputValue = this.inputValue;
                        if (inputValue) {
                            var currentValue = this.getValue();
                            this.setValue(currentValue ? currentValue + cellType.separator + inputValue : inputValue);
                            self.commitValue();
                        }
                        this.inputVisible = false;
                        this.inputValue = '';
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    }
                },
                mounted: function () {
                    if (this.allowAdd) {
                        this.fieldHeight = getComputedStyle($(".van-tag-button", self.getContainer())[0]).height;
                    }
                }
            };
            this.createVueApp(option);
            this.onFormulaResultChanged(cellType.addButtonSettings.text, function (value) {
                _this.vue.buttonText = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        TagCellType.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.refreshClickable();
        };
        TagCellType.prototype.refreshClickable = function () {
            var _a;
            (_a = this.getContainer()) === null || _a === void 0 ? void 0 : _a.attr("clickable", this.clickable() ? true : "");
        };
        TagCellType.prototype.clickable = function () {
            var _a;
            var cellType = this.CellElement.CellType;
            return !this.isReadOnly() || (((_a = cellType === null || cellType === void 0 ? void 0 : cellType.ClickCommand) === null || _a === void 0 ? void 0 : _a.Commands) && cellType.ClickCommand.Commands.length > 0);
        };
        return TagCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.TagCellType = TagCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Tag, Vant", VantCellTypes.TagCellType);
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var TimelineCellType = /** @class */ (function (_super) {
        __extends(TimelineCellType, _super);
        function TimelineCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TimelineCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            $("#".concat(this.uId)).css("overflow-y", "auto");
            var option = {
                template: "\n<van-steps\n    :active=\"active\"\n    :direction=\"direction\"\n    :active-icon=\"activeIcon\"\n    :active-color=\"activeColor\"\n    :inactive-icon=\"inactiveIcon\"\n    :inactive-color=\"inactiveColor\"\n    :finish-icon=\"finishIcon\"\n>\n    <van-step\n        :key=\"key\"\n        v-for=\"({ key, title, timestamp }) in stepsOptions\"\n>\n        <p style=\"margin: 0;\">{{ placement === \"bottom\" ? (title || \"\") : timestamp }}</p>\n        <p style=\"margin: 0;\">{{ placement === \"bottom\" ? timestamp : (title || \"\") }}</p>\n    </van-step>\n</van-steps>\n",
                data: function () {
                    return __assign(__assign(__assign(__assign({}, self.getDefaultData()), cellType), self.convertToCssColor(cellType)), { activeIcon: "checked", inactiveIcon: "", finishIcon: "" });
                },
                computed: {
                    stepsOptions: function (_a) {
                        var useBinding = _a.useBinding, bindingOptions = _a.bindingOptions, options = _a.options;
                        var stepsOptions = useBinding ? bindingOptions : options;
                        if (Array.isArray(stepsOptions)) {
                            stepsOptions.forEach(function (op) { return op.title = self.getApplicationResource(op.title); });
                            return self.uniqueKeyCreator(stepsOptions.map(this.formatOption), "value");
                        }
                        return [];
                    }
                },
                methods: {
                    getValue: function () {
                        return this.value;
                    },
                    setValue: function (value) {
                        this.value = value;
                        this.updateActive();
                    },
                    setOptions: function (options) {
                        if (this.useBinding) {
                            this.bindingOptions = options;
                        }
                        else {
                            this.options = options;
                        }
                        this.updateActive();
                    },
                    updateActive: function () {
                        var _this = this;
                        // 这里认为字符串数字与数字等价，双等号不能去掉
                        // eslint-disable-next-line
                        var index = this.stepsOptions.findIndex(function (step) { return step.value == _this.value; });
                        if (index > -1) {
                            this.active = index;
                            return;
                        }
                        if (this.value || this.value === 0) {
                            this.active = this.stepsOptions.length;
                        }
                        else {
                            this.active = -1;
                        }
                    },
                    formatOption: function (stepOption) {
                        var timestamp = stepOption.timestamp;
                        var isNumber = typeof (timestamp) === "number" || !isNaN(Number(timestamp));
                        var getDate = function (isOADate) {
                            if (isOADate === void 0) { isOADate = true; }
                            if (isOADate) {
                                var date_1 = Forguncy.ConvertOADateToDate(timestamp);
                                var isInvalidDate = isNaN(date_1.getTime());
                                return isInvalidDate ? getDate(false) : date_1;
                            }
                            var dateString = isNumber ? Number(timestamp) : timestamp === null || timestamp === void 0 ? void 0 : timestamp.replace(/-/g, "/");
                            return new Date(dateString);
                        };
                        var date = getDate();
                        var newTimestamp = self.isValidDate(date)
                            ? self.formatDate(date, cellType.format || "yyyy/MM/dd")
                            : timestamp;
                        return {
                            value: stepOption.value,
                            title: stepOption.title,
                            timestamp: newTimestamp
                        };
                    }
                }
            };
            this.createVueApp(option);
            VantCellTypes.IconHelper.getIcon(cellType.activeIcon, function (icon) {
                _this.vue.activeIcon = icon;
            });
            VantCellTypes.IconHelper.getIcon(cellType.inactiveIcon, function (icon) {
                _this.vue.inactiveIcon = icon;
            });
            VantCellTypes.IconHelper.getIcon(cellType.finishIcon, function (icon) {
                _this.vue.finishIcon = icon;
            });
            this.ReloadBindingItems();
            _super.prototype.onPageLoaded.call(this, info);
        };
        TimelineCellType.prototype.getDefaultData = function () {
            return {
                active: -1,
                value: null,
                direction: "vertical",
                useBinding: false,
                options: [],
                bindingOptions: [],
                DefaultValue: ""
            };
        };
        TimelineCellType.prototype.convertToCssColor = function (cellType) {
            var result = {};
            result.activeColor = Forguncy.ConvertToCssColor(cellType.activeColor);
            result.inactiveColor = Forguncy.ConvertToCssColor(cellType.inactiveColor);
            return result;
        };
        TimelineCellType.prototype.reload = function () {
            this.ReloadBindingItems();
        };
        TimelineCellType.prototype.ReloadBindingItems = function () {
            var _this = this;
            var cellType = this.cellType;
            if (cellType.useBinding) {
                VantCellTypes.SupportDataSourceCellType.refreshData(this, cellType.bindingOptions, function (dataSource) { return _this.setDataSource(dataSource); });
            }
        };
        TimelineCellType.prototype.setDataSource = function (dataSource) {
            return this.vue.setOptions(dataSource);
        };
        // runtime methods
        TimelineCellType.prototype.SetJSONDataSource = function (jsonSource, valueProperty, titleProperty, timestampProperty) {
            var _this = this;
            var isExistEmptyParamter = [
                jsonSource,
                valueProperty,
                titleProperty,
                timestampProperty
            ].some(function (param) { return _this.isEmpty(param); });
            if (!isExistEmptyParamter) {
                var dataSource = JSON.parse(jsonSource);
                dataSource = dataSource.map(function (data) {
                    return {
                        value: data[valueProperty],
                        title: data[titleProperty],
                        timestamp: data[timestampProperty]
                    };
                });
                this.setDataSource(dataSource);
            }
        };
        TimelineCellType.prototype.UpdateActiveIcon = function (activeIcon) {
            var _this = this;
            VantCellTypes.IconHelper.getIcon(activeIcon, function (icon) {
                _this.vue.activeIcon = icon;
            });
        };
        TimelineCellType.prototype.UpdateActiveColor = function (activeColor) {
            this.vue.activeColor = Forguncy.ConvertToCssColor(activeColor);
        };
        return TimelineCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.TimelineCellType = TimelineCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Timeline, Vant", VantCellTypes.TimelineCellType);
var VantCellTypes;
(function (VantCellTypes) {
    var TreeHelper = /** @class */ (function () {
        function TreeHelper() {
        }
        TreeHelper.build = function (nodes) {
            var _this = this;
            if (!nodes) {
                return undefined;
            }
            var allDataNodes = nodes.map(function (item) { return ({
                value: item.value,
                parentValue: item.parentValue,
                text: item.text
            }); });
            for (var _i = 0, allDataNodes_1 = allDataNodes; _i < allDataNodes_1.length; _i++) {
                var node = allDataNodes_1[_i];
                node.uId = this.getUid(node.value, node.parentValue);
            }
            var uidNodesCache = {};
            var idNodesCache = {};
            var parentIdNodesCache = {};
            for (var _a = 0, allDataNodes_2 = allDataNodes; _a < allDataNodes_2.length; _a++) {
                var node = allDataNodes_2[_a];
                uidNodesCache[node.uId] = node;
            }
            for (var _b = 0, allDataNodes_3 = allDataNodes; _b < allDataNodes_3.length; _b++) {
                var node = allDataNodes_3[_b];
                if (!idNodesCache[node.value]) {
                    idNodesCache[node.value] = [];
                }
                idNodesCache[node.value].push(node);
            }
            for (var _c = 0, allDataNodes_4 = allDataNodes; _c < allDataNodes_4.length; _c++) {
                var node = allDataNodes_4[_c];
                if (!parentIdNodesCache[node.parentValue]) {
                    parentIdNodesCache[node.parentValue] = [];
                }
                parentIdNodesCache[node.parentValue].push(node);
            }
            this.buildChildren(allDataNodes, parentIdNodesCache);
            var roots = allDataNodes.filter(function (i) { return _this.isRootNode(i, idNodesCache); });
            var exsitId = {};
            var uniqueRoots = roots.filter(function (i) {
                if (exsitId[i.value]) {
                    return false;
                }
                exsitId[i.value] = true;
                return true;
            });
            return uniqueRoots;
        };
        TreeHelper.getUid = function (id, pid) {
            return (id !== null && id !== void 0 ? id : "") + "_%_" + (pid !== null && pid !== void 0 ? pid : "");
        };
        TreeHelper.buildChildren = function (nodes, parentIdDataNodesCache) {
            for (var _i = 0, nodes_1 = nodes; _i < nodes_1.length; _i++) {
                var node = nodes_1[_i];
                var children = parentIdDataNodesCache[node.value];
                if (children) {
                    node.children = children;
                }
                else {
                    node.children = null;
                }
            }
        };
        TreeHelper.isRootNode = function (node, idNodesCache) {
            if (!node.parentValue) {
                return true;
            }
            var nodes = idNodesCache[node.parentValue];
            if (!nodes) {
                return true;
            }
            return false;
        };
        TreeHelper.flat = function (nodes) {
            var result = [];
            if (nodes && nodes.length) {
                for (var _i = 0, nodes_2 = nodes; _i < nodes_2.length; _i++) {
                    var n = nodes_2[_i];
                    result.push(n);
                    var subResult = this.flat(n.children);
                    subResult.every(function (i) { return result.push(i); });
                }
            }
            return result;
        };
        return TreeHelper;
    }());
    VantCellTypes.TreeHelper = TreeHelper;
})(VantCellTypes || (VantCellTypes = {}));
/// <reference path = "Base.ts" />
var VantCellTypes;
(function (VantCellTypes) {
    var UploadCellType = /** @class */ (function (_super) {
        __extends(UploadCellType, _super);
        function UploadCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        UploadCellType.prototype.onPageLoaded = function (info) {
            var _this = this;
            var self = this;
            var cellType = this.cellType;
            var option = {
                template: "\n<van-uploader\n    v-model=\"fileList\"\n    :max-count=\"maxCount\"\n    :accept=\"accept\"\n    :max-size=\"maxSize * 1024 * 1024\"\n    :capture=\"capture\"\n    :show-upload=\"showUpload && !readonly\"\n    :upload-icon=\"uploadIcon\"\n    :upload-text=\"uploadText\"\n    :preview-size=\"previewSize\"\n    :image-fit=\"imageFit\"\n    :preview-image=\"true\"\n    :preview-full-image=\"previewFullImage && !disabled\"\n    :deletable=\"deletable && !readonly && !disabled\"\n    :multiple=\"multiple\"\n    :readonly=\"readonly\"\n    :disabled=\"disabled\"\n    :before-read=\"checkExtension\"\n    :after-read=\"uploadFile\"\n    @oversize=\"handleOversize\"\n    @delete=\"handleDelete\"\n>\n</van-uploader>\n",
                data: function () {
                    return {
                        fileList: [],
                        maxCount: cellType.maxCount || Infinity,
                        accept: cellType.capture === "images" ? cellType.accept : undefined,
                        maxSize: cellType.maxSize || Infinity,
                        capture: cellType.capture === "images" ? undefined : cellType.capture,
                        showUpload: !!cellType.showUpload,
                        uploadIcon: undefined,
                        uploadText: undefined,
                        previewSize: cellType.previewSize,
                        imageFit: cellType.imageFit,
                        previewFullImage: !!cellType.previewFullImage,
                        deletable: !!cellType.deletable,
                        multiple: !!cellType.multiple,
                        readonly: false,
                        disabled: false
                    };
                },
                methods: {
                    getValue: function () {
                        var fileNameList = this.fileList.map(function (file) { return file === null || file === void 0 ? void 0 : file.fgc_fileName; });
                        return fileNameList.filter(function (name) { return !self.isEmpty(name); }).join("|");
                    },
                    setValue: function (value) {
                        if (value === this.getValue()) {
                            return;
                        }
                        if (typeof value !== "string" || self.isEmpty(value)) {
                            this.fileList = [];
                        }
                        else {
                            var values = value.split("|").filter(function (item) { return !self.isEmpty(item); });
                            this.fileList = values.map(function (fgcFileName) {
                                if (fgcFileName && fgcFileName.length > 37 && fgcFileName.charAt(36) === "_") {
                                    return {
                                        fgc_fileName: fgcFileName,
                                        url: UploadCellType.isImage(fgcFileName) ? UploadCellType.getFileUrl(fgcFileName) : fgcFileName.slice(37)
                                    };
                                }
                            }).filter(function (item) { return !self.isEmpty(item); });
                        }
                    },
                    setReadOnly: function (value) {
                        this.readonly = value;
                    },
                    disable: function () {
                        this.disabled = true;
                    },
                    enable: function () {
                        this.disabled = false;
                    },
                    uploadFile: function (data) {
                        var _this = this;
                        var datas = Array.isArray(data) ? data : [data];
                        datas.forEach(function (dataItem) {
                            var successCallback = function (fileName) {
                                dataItem.fgc_fileName = fileName;
                                dataItem.url = UploadCellType.getFileUrl(fileName);
                                dataItem.status = "";
                                self.commitValue();
                            };
                            var errorCallback = function () {
                                dataItem.status = 'failed';
                                self.commitValue();
                            };
                            if (UploadCellType.isImage(dataItem.file.name)) {
                                Forguncy.Common.uploadImageToServer(dataItem.file, cellType.UploadImageLimit, _this.accept, successCallback, errorCallback, undefined, self.CellElement.ServerPropertiesId.UploadLimit);
                            }
                            else {
                                Forguncy.Common.uploadFileByHTML5(dataItem.file, successCallback, errorCallback, null, self.CellElement.ServerPropertiesId.UploadLimit);
                            }
                        });
                    },
                    checkExtension: function (file) {
                        if (cellType.accept) {
                            var exts_1 = cellType.accept.split(",").filter(function (i) { return i; }).map(function (i) { return i.trim(); });
                            if (Array.isArray(file)) {
                                if (file.some(function (fileItem) { return !exts_1.some(function (i) { return fileItem.name.endsWith(i); }); })) {
                                    this.$notify(cellType.UnacceptableFileError);
                                    return false;
                                }
                            }
                            else {
                                if (!exts_1.some(function (i) { return file.name.endsWith(i); })) {
                                    this.$notify(cellType.UnacceptableFileError);
                                    return false;
                                }
                            }
                        }
                        return true;
                    },
                    handleOversize: function () {
                        this.$notify(cellType.OverFileSizeLimitError);
                    },
                    handleDelete: function () {
                        self.commitValue();
                    },
                    downloadNonImageFile: function (index) {
                        var data = this.fileList[index];
                        if (this.disabled || data.status === "failed" || UploadCellType.isImage(data.fgc_fileName)) {
                            return;
                        }
                        Forguncy.Common.download(UploadCellType.getFileUrl(data.fgc_fileName));
                    }
                },
                updated: function () {
                    var _this = this;
                    var previewItems = $(".van-uploader__preview", this.$el);
                    for (var i = 0; i < previewItems.length; i++) {
                        var el = previewItems[i];
                        var NonImageItem = $(el).find(".van-uploader__file")[0];
                        if (NonImageItem) {
                            NonImageItem.onclick = null;
                        }
                    }
                    var _loop_4 = function (i) {
                        var el = previewItems[i];
                        var NonImageItem = $(el).find(".van-uploader__file")[0];
                        if (NonImageItem) {
                            NonImageItem.onclick = function (e) { return _this.downloadNonImageFile(i); };
                        }
                    };
                    for (var i = 0; i < previewItems.length; i++) {
                        _loop_4(i);
                    }
                }
            };
            this.createVueApp(option);
            VantCellTypes.IconHelper.getIcon(cellType.uploadIcon, function (icon) {
                _this.vue.uploadIcon = icon;
            });
            this.onFormulaResultChanged(cellType.uploadText, function (value) {
                _this.vue.uploadText = value === null || value === void 0 ? void 0 : value.toString();
            });
            _super.prototype.onPageLoaded.call(this, info);
        };
        UploadCellType.getFileUrl = function (fileName) {
            var root = Forguncy.Helper.SpecialPath.getBaseUrl();
            return root + Forguncy.ModuleLoader.getCdnUrl("FileDownloadUpload/Download?file=" + encodeURIComponent(fileName));
        };
        UploadCellType.isImage = function (fileName) {
            if (fileName) {
                var pointIndex = fileName.lastIndexOf(".");
                if (pointIndex) {
                    var extension_1 = fileName.toLowerCase().substring(pointIndex + 1, fileName.length);
                    return ["jpg", "jpeg", "png", "gif", "eps", "svg", "bmp", "tif", "tiff"].some(function (i) { return i === extension_1; });
                }
            }
            return false;
        };
        return UploadCellType;
    }(VantCellTypes.VantCellTypeBase));
    VantCellTypes.UploadCellType = UploadCellType;
})(VantCellTypes || (VantCellTypes = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Vant.CellTypes.Upload, Vant", VantCellTypes.UploadCellType);
/// <reference path = "../CellTypes/Base.ts" />
var VantCommands;
(function (VantCommands) {
    var CloseToastMessage = /** @class */ (function (_super) {
        __extends(CloseToastMessage, _super);
        function CloseToastMessage() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        CloseToastMessage.prototype.execute = function () {
            window.vant.Toast.clear(true);
        };
        return CloseToastMessage;
    }(Forguncy.Plugin.CommandBase));
    VantCommands.CloseToastMessage = CloseToastMessage;
})(VantCommands || (VantCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("Vant.Commands.CloseToast, Vant", VantCommands.CloseToastMessage);
var VantCommands;
(function (VantCommands) {
    var DialogMessage = /** @class */ (function (_super) {
        __extends(DialogMessage, _super);
        function DialogMessage() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DialogMessage.prototype.execute = function () {
            var _this = this;
            var _a, _b;
            var param = this.CommandParam;
            param = __assign(__assign(__assign({ showConfirmButton: !!param.showConfirmButton, showCancelButton: !!param.showCancelButton }, param), { overlay: !!param.AdvancedSetting.overlay, closeOnPopstate: !!param.AdvancedSetting.closeOnPopstate, closeOnClickOverlay: !!param.AdvancedSetting.closeOnClickOverlay }), param.AdvancedSetting);
            Forguncy.PageBuilder.hidePageLoadingCover();
            var clone = __assign({}, param);
            Reflect.deleteProperty(clone, "$type");
            clone.title = (_a = this.evaluateFormula(clone.title)) === null || _a === void 0 ? void 0 : _a.toString();
            clone.message = (_b = this.evaluateFormula(clone.message)) === null || _b === void 0 ? void 0 : _b.toString();
            clone.confirmButtonColor = Forguncy.ConvertToCssColor(clone.confirmButtonColor);
            clone.cancelButtonColor = Forguncy.ConvertToCssColor(clone.cancelButtonColor);
            clone.confirmButtonText = this.getApplicationResource(clone.confirmButtonText);
            clone.cancelButtonText = this.getApplicationResource(clone.cancelButtonText);
            clone.beforeClose = function (action) {
                window.vant.Dialog.close();
                Vue.nextTick(function () {
                    var result = action;
                    if (action === undefined) {
                        result = param.AdvancedSetting.distinguishCancelAndClose ? "close" : "cancel";
                    }
                    Forguncy.CommandHelper.setVariableValue(param.DialogResult, result);
                    _this.CommandExecutingInfo.suspend = false;
                });
            };
            window.vant.Dialog(clone);
            this.CommandExecutingInfo.suspend = true;
        };
        return DialogMessage;
    }(Forguncy.Plugin.CommandBase));
    VantCommands.DialogMessage = DialogMessage;
})(VantCommands || (VantCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("Vant.Commands.Dialog, Vant", VantCommands.DialogMessage);
/// <reference path = "../CellTypes/Base.ts" />
var VantCommands;
(function (VantCommands) {
    var Notify = /** @class */ (function (_super) {
        __extends(Notify, _super);
        function Notify() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Notify.prototype.execute = function () {
            var _a;
            return __awaiter(this, void 0, void 0, function () {
                var param, clickCommands, message, context, notice, toastData;
                var _this = this;
                return __generator(this, function (_b) {
                    param = this.CommandParam;
                    clickCommands = param.Command;
                    message = this.evaluateFormula(param.message);
                    context = this.evaluateFormula(param.context);
                    notice = null;
                    toastData = {
                        message: message === null || message === void 0 ? void 0 : message.toString(),
                        type: param.type,
                        duration: (_a = param.duration) !== null && _a !== void 0 ? _a : 0,
                        position: param.position,
                        color: Forguncy.ConvertToCssColor(param.color),
                        background: param.type === "custom" ? Forguncy.ConvertToCssColor(param.background) : null,
                        onClick: function () {
                            if (notice && (clickCommands === null || clickCommands === void 0 ? void 0 : clickCommands.Commands) && clickCommands.Commands.length > 0) {
                                var param_1 = {};
                                param_1[clickCommands.ParamProperties["message"]] = message;
                                param_1[clickCommands.ParamProperties["context"]] = context;
                                _this.executeCustomCommandObject(clickCommands, param_1, "Notice");
                                notice.close();
                            }
                        }
                    };
                    notice = window.vant.Notify(toastData);
                    return [2 /*return*/];
                });
            });
        };
        Notify.unclickableClassName = "van-toast--unclickable";
        return Notify;
    }(Forguncy.Plugin.CommandBase));
    VantCommands.Notify = Notify;
})(VantCommands || (VantCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("Vant.Commands.Notify, Vant", VantCommands.Notify);
/// <reference path = "../CellTypes/Base.ts" />
var VantCommands;
(function (VantCommands) {
    var ToastMessage = /** @class */ (function (_super) {
        __extends(ToastMessage, _super);
        function ToastMessage() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ToastMessage.prototype.execute = function () {
            var _a, _b;
            return __awaiter(this, void 0, void 0, function () {
                var param, onClose, toastData;
                return __generator(this, function (_c) {
                    param = this.CommandParam;
                    if (param.forbidClick) {
                        $("body").addClass(ToastMessage.unclickableClassName);
                    }
                    onClose = function () {
                        $("body").removeClass(ToastMessage.unclickableClassName);
                    };
                    toastData = {
                        message: (_a = this.evaluateFormula(param.message)) === null || _a === void 0 ? void 0 : _a.toString(),
                        type: param.type,
                        duration: (_b = param.duration) !== null && _b !== void 0 ? _b : 0,
                        position: param.position,
                        overlay: !!param.overlay,
                        iconSize: param.iconSize,
                        loadingType: param.loadingType,
                        forbidClick: !!param.forbidClick,
                        closeOnClick: !!param.closeOnClick,
                        closeOnClickOverlay: !!param.closeOnClickOverlay,
                        icon: null,
                        onClose: onClose
                    };
                    return [2 /*return*/, new Promise(function (resolve) {
                            var _a;
                            if (((_a = param.icon) === null || _a === void 0 ? void 0 : _a.Name) && param.type !== "loading") {
                                VantCellTypes.IconHelper.getIcon(param.icon, function (icon) {
                                    toastData.icon = icon;
                                    window.vant.Toast(toastData);
                                    resolve();
                                });
                            }
                            else {
                                window.vant.Toast(toastData);
                                resolve();
                            }
                        })];
                });
            });
        };
        ToastMessage.unclickableClassName = "van-toast--unclickable";
        return ToastMessage;
    }(Forguncy.Plugin.CommandBase));
    VantCommands.ToastMessage = ToastMessage;
})(VantCommands || (VantCommands = {}));
Forguncy.Plugin.CommandFactory.registerCommand("Vant.Commands.Toast, Vant", VantCommands.ToastMessage);
var VantCellTypes;
(function (VantCellTypes) {
    var DateUtil = /** @class */ (function () {
        function DateUtil() {
        }
        DateUtil.InteralConvertToDate = function (value) {
            if (!value) {
                return null;
            }
            if (value instanceof Date) {
                return value;
            }
            var numerValue = Number(value);
            var isOADate = !isNaN(numerValue);
            if (isOADate) {
                return Forguncy.ConvertOADateToDate(numerValue);
            }
            return new Date(value);
        };
        DateUtil.ConvertToDate = function (value, effectiveValue) {
            if (effectiveValue === void 0) { effectiveValue = "Invalid Date"; }
            var date = DateUtil.InteralConvertToDate(value);
            var isInvalidDate = !date || !date.getTime();
            return isInvalidDate ? effectiveValue : date;
        };
        return DateUtil;
    }());
    VantCellTypes.DateUtil = DateUtil;
})(VantCellTypes || (VantCellTypes = {}));
var VantCellTypes;
(function (VantCellTypes) {
    function getPickerValidToolbarOption(config) {
        return {
            title: "",
            confirmButtonText: "",
            cancelButtonText: ""
        };
    }
    VantCellTypes.getPickerValidToolbarOption = getPickerValidToolbarOption;
    function setPickerValidToolbarOptionToVue(cell, config, vue) {
        cell.onFormulaResultChanged(config.title, function (value) {
            vue.title = value === null || value === void 0 ? void 0 : value.toString();
        });
        cell.onFormulaResultChanged(config.cancelButtonText, function (value) {
            vue.cancelButtonText = value === null || value === void 0 ? void 0 : value.toString();
        });
        cell.onFormulaResultChanged(config.confirmButtonText, function (value) {
            vue.confirmButtonText = value === null || value === void 0 ? void 0 : value.toString();
        });
    }
    VantCellTypes.setPickerValidToolbarOptionToVue = setPickerValidToolbarOptionToVue;
})(VantCellTypes || (VantCellTypes = {}));
//# sourceMappingURL=dist.js.map