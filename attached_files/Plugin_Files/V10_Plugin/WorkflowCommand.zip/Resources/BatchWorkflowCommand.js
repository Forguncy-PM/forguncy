﻿var BatchWorkflowCommand = (function (_super) {
    __extends(BatchWorkflowCommand, _super);
    function BatchWorkflowCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    BatchWorkflowCommand.prototype.execute = function () {
        var param = this.CommandParam;
        var listviewName = param.ListviewName;
        var onlySelectedRows = param.ListViewRows == 1 ? true : false;
        var p = Forguncy.Page;
        const pageID = this.getFormulaCalcContext().PageID;
        const pageInfo = p.getSubPageInfoByPageID(pageID);
        var list = pageInfo ? pageInfo.getListView(listviewName) : p.getListView(listviewName, false);
        var rows = [];
        if (onlySelectedRows) {
            rows = list.getSelectedRowIndexs()
        }
        else {
            for (var i = 0; i < list.getRowCount(); i++) {
                rows.push(i);
            }
        }
        var querys = [];

        for (var i = 0; i < rows.length; i++) {
            querys.push(list.getQuery(rows[i]));
        }
        var comments = null;
        if (param.ActionComments) {
            comments = this.evaluateFormula(param.ActionComments);
        }

        var actionName = null;
        if (param.ActionName) {
            actionName = this.evaluateFormula(param.ActionName);
        }

        Forguncy.Helper.post("WorkflowApi/ExecuteMultiFlowAction",
            {
                tableName: list.getDataTableName(),
                querys: querys,
                actionName: actionName,
                comments: comments
            }, function () {
                Forguncy.Page.reloadBindingData(list.getDataTableName());
            });
    }

    return BatchWorkflowCommand;
}(Forguncy.CommandBase));

Forguncy.CommandFactory.registerCommand("WorkflowCommand.BatchWorkflowCommand, WorkflowCommand", BatchWorkflowCommand);