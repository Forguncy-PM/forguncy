﻿var SmartPhoneCommand = (function (_super) {
    __extends(SmartPhoneCommand, _super);
    function SmartPhoneCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    SmartPhoneCommand.prototype.execute = function () {

        // Get setings
        var param = this.CommandParam;
        var targetCellFormula = param.TargetCell;
        var cellLocation = this.getCellLocation(targetCellFormula);
        var cellInfo = JSON.stringify(cellLocation);

        if (window.ReactNativeWebView) {
            let scanInfo = {
                "type": "scanBarCode",
                "data": cellLocation
            };
            window.ReactNativeWebView.postMessage(JSON.stringify(scanInfo));
        } else {
            var userAgent = window.navigator.userAgent;
            var iOS = /iPad|iPhone|iPod/;
            var Android = /Android/;
            if (new RegExp(iOS).test(userAgent) || (window.navigator.platform === 'MacIntel' && window.navigator.maxTouchPoints > 1)) {
                location.href = "hybrid:scancode?cellid=" + cellInfo;
            }
            else if (new RegExp(Android).test(userAgent)) {
                window.index.ScanCode(cellInfo);
            }
            else {
                var alertText = SmartPhoneCommand.getResourceString("scanCodeAlert");
                alert(alertText);
            }
        }
    };

    SmartPhoneCommand.prototype.GetQRCode = function (cellInfo, qrcode) {
        var cellLocation = JSON.parse(cellInfo);
        Forguncy.Page.getCellByLocation(cellLocation).setValue(qrcode);
    };

    SmartPhoneCommand.getResourceString = function (key) {
        return this.prototype.getPluginResource(key);
    };

    return SmartPhoneCommand;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("SmartPhoneCommand.SmartPhoneCommand, SmartPhoneCommand", SmartPhoneCommand);