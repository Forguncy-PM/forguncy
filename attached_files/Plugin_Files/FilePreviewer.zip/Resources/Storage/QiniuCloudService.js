var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    var QiniuCloudFileItem = /** @class */ (function (_super) {
        __extends(QiniuCloudFileItem, _super);
        function QiniuCloudFileItem() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        QiniuCloudFileItem.prototype.getEncodeURIComponentSrc = function () {
            var index = this.src.lastIndexOf("/") + 1;
            var base = this.src.substring(0, index);
            var fileName = this.src.substring(index);
            return base + encodeURIComponent(fileName);
        };
        QiniuCloudFileItem.prototype.getStorageSrc = function () {
            return "<Qiniu>" + this.src;
        };
        QiniuCloudFileItem.prototype.getDisplayFileName = function () {
            // Length of Guid: 32
            // Length of Underline: 1
            // Sample: c020d44c432248c49997f344daf52776_sample.png
            return this.getFileName().slice(33);
        };
        return QiniuCloudFileItem;
    }(FilePreviewer.FileItem));
    FilePreviewer.QiniuCloudFileItem = QiniuCloudFileItem;
    /**
     * 七牛云存储服务
     */
    var QiniuCloudService = /** @class */ (function () {
        function QiniuCloudService(metadata) {
            this.metadata = metadata;
            this.qiniuToken = {
                authToken: null,
                createTime: new Date()
            };
            if (!this.metadata.UploadLimit) {
                this.metadata.UploadLimit = {
                    ExtensionFilter: "",
                    MaxUploadFileCount: null,
                    SizeLimit: null
                };
            }
        }
        QiniuCloudService.prototype.download = function (url, onSuccess, onError) {
            var link = $("<a>download</a>").attr("href", url);
            $("body").append(link);
            link[0].click();
            link.remove();
            onSuccess && onSuccess();
        };
        QiniuCloudService.prototype.upload = function (file, transmit) {
            this.sliceUpload(file, transmit);
        };
        QiniuCloudService.prototype.delete = function (url, onSuccess, onError) {
            this.deleteObject(url, onSuccess, onError);
        };
        QiniuCloudService.prototype.sliceUpload = function (file, transmit) {
            var self = this;
            //Get token if not exist
            if (!this.qiniuToken.authToken || (new Date().getMilliseconds() - this.qiniuToken.createTime.getMilliseconds()) > 3600 * 24 * 1000) {
                Forguncy.Helper.post("customapi/qiniucloudapi/getuploadtoken", {}, function (token) {
                    self.qiniuToken.authToken = token;
                    self.qiniuToken.createTime = new Date();
                }, false);
            }
            //upload image
            var fileKey = this.guid() + "_" + file.name;
            var authToken = this.qiniuToken.authToken;
            var observable = (window.qiniu).upload(file, fileKey, authToken, null /*putExtra*/, {
                useCdnDomain: true
            });
            var observer = {
                next: function (result) {
                    transmit.progress && transmit.progress({ raw: file, loaded: result.total.loaded, total: result.total.size });
                },
                error: function (err) {
                    transmit.fail && transmit.fail({ raw: file, errorMessage: FilePreviewer.Resources.Error_UploadFailed + JSON.stringify(err) });
                },
                complete: function (res) {
                    if (res && res.key === fileKey && res.fileUrl) {
                        //qiniu.region.z0: 代表华东区域
                        //qiniu.region.z1: 代表华北区域
                        //qiniu.region.z2: 代表华南区域
                        //qiniu.region.na0: 代表北美区域
                        //qiniu.region.as0: 代表东南亚区域
                        transmit.success && transmit.success({ raw: file, fileItem: new QiniuCloudFileItem(res.fileUrl) });
                        return;
                    }
                    transmit.fail && transmit.fail({ raw: file, errorMessage: "上传失败" });
                },
            };
            observable.subscribe(observer);
        };
        QiniuCloudService.prototype.guid = function () {
            return 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'.replace(/[x]/g, function (c) {
                var r = Math.random() * 16 | 0;
                return r.toString(16);
            });
        };
        QiniuCloudService.prototype.deleteObject = function (url, onSuccess, onError) {
            onSuccess && onSuccess();
            // 不删除
        };
        return QiniuCloudService;
    }());
    FilePreviewer.QiniuCloudService = QiniuCloudService;
})(FilePreviewer || (FilePreviewer = {}));
