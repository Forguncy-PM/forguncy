var JsonDataSource;
(function (JsonDataSource) {
    var Common = /** @class */ (function () {
        function Common() {
        }
        Common.IsEmpty = function (obj) {
            if (obj === null || obj === "" || obj === undefined) {
                return true;
            }
            return false;
        };
        return Common;
    }());
    JsonDataSource.Common = Common;
})(JsonDataSource || (JsonDataSource = {}));
