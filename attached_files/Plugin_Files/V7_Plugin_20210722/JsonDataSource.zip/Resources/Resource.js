var PassListviewDataCommand;
(function (PassListviewDataCommand) {
    var RS_JP = {
        Error_ExistSameKeys: "データの受け渡し元の一覧において、行を特定するために必要な列の値が一意になっていません。対象列の値が一意になっているかどうか確認してください。"
    };
    var RS_CN = {
        Error_ExistSameKeys: "源表格的基准列存在相同的数据，请确保基准列的数据是唯一的。"
    };
    var RS_KO = {
        Error_ExistSameKeys: "Exists same reference column values in source listview and please ensure the reference column values is unique."
    };
    var RS_EN = {
        Error_ExistSameKeys: "Exists same reference column values in source listview and please ensure the reference column values is unique."
    };
    var RSHelper = /** @class */ (function () {
        function RSHelper() {
        }
        RSHelper.getRS = function () {
            switch (Forguncy.RS.Culture) {
                case "CN" /* Chinese */:
                    return RS_CN;
                case "JA" /* Japanese */:
                    return RS_JP;
                case "KR" /* Korean */:
                    return RS_KO;
                default:
                    return RS_EN;
            }
        };
        return RSHelper;
    }());
    PassListviewDataCommand.RSHelper = RSHelper;
})(PassListviewDataCommand || (PassListviewDataCommand = {}));
