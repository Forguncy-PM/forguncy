var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    var FPControl = (function (_super) {
        __extends(FPControl, _super);
        function FPControl() {
            var _this = _super.call(this) || this;
            _this.explorerControl = new FilePreviewer.ExplorerControl();
            _this.previewerControl = new FilePreviewer.PreviewerControl();
            _this.initializeProperties();
            return _this;
        }
        FPControl.prototype.setMetadata = function (metadata) {
            this.metadata = metadata;
            this.explorerControl.layoutMode = this.metadata.LayoutMode;
            this.explorerControl.customWidth = this.metadata.CustomWidth;
            this.explorerControl.customHeight = this.metadata.CustomHeight;
            this.explorerControl.isHiddenFileName = this.metadata.IsHiddenFileName;
            this.explorerControl.isHiddenToolbar = this.metadata.IsHiddenToolbar;
            this.explorerControl.isSmallButtonMode = this.metadata.IsSmallButtonMode;
            this.explorerControl.readonly = this.metadata.Readonly;
            this.explorerControl.maxFileCount = (this.metadata.UploadLimit && this.metadata.UploadLimit.MaxUploadFileCount) || Number.MAX_VALUE;
            if (metadata.StorageType === 0) {
                this.storageService = new FilePreviewer.ServerStorageService(this.metadata);
            }
            else if (metadata.StorageType === 1) {
                this.storageService = new FilePreviewer.TencentCloudStorageService(this.metadata);
            }
        };
        FPControl.prototype.getValue = function () {
            var result = this.explorerControl.fileItems.filter(function (i) { return i.status === 0; }).map(function (i) {
                return i.getStorageSrc();
            }).join("|");
            return result;
        };
        FPControl.prototype.setValue = function (value) {
            var _a;
            this.explorerControl.clearFiles();
            if (typeof (value) === "string") {
                (_a = this.explorerControl).addFile.apply(_a, FilePreviewer.FileItemHelper.parseFromString(value, this.metadata));
            }
        };
        FPControl.prototype.initializeProperties = function () {
            var _this = this;
            this.previewerControl.fileItems = this.explorerControl.fileItems;
            this.previewerControl.on("Download", function (fileItems) {
                _this.downloadFiles(fileItems);
            });
            this.explorerControl.on("Preview", function (selectedItems) {
                _this.previewerControl.activeItem = selectedItems[0];
                _this.previewerControl.show();
            });
            this.explorerControl.on("FileItemsChanged", function () {
                _this.previewerControl.syncFileItems(_this.explorerControl.fileItems);
            });
            this.explorerControl.on("Upload", function () {
                var multiple = _this.metadata.UploadLimit && _this.metadata.UploadLimit.MaxUploadFileCount !== 1;
                FilePreviewer.OpenFileDialog.open(multiple, function (files) {
                    files.forEach(function (file) { return _this.uploadFile(file); });
                });
            });
            this.explorerControl.on("DropFile", function (files) {
                files.forEach(function (file) { return _this.uploadFile(file); });
            });
            this.explorerControl.on("PasterFile", function (files) {
                files.forEach(function (file) { return _this.uploadFile(file); });
            });
            this.explorerControl.on("Download", function (fileItems) {
                _this.downloadFiles(fileItems);
            });
            this.explorerControl.on("Delete", function (selectedFileItems) {
                selectedFileItems.forEach(function (fileItem) {
                    if (fileItem.status === 0) {
                        _this.storageService.delete(fileItem.getEncodeURIComponentSrc(), function () {
                            _this.explorerControl.removeFile(fileItem);
                            _this.dispatch("ValueChanged");
                        }, function (e) {
                            alert(e.errorMessage);
                        });
                    }
                });
            });
        };
        FPControl.prototype.downloadFiles = function (files) {
            var _this = this;
            var _a;
            var count = 0;
            (_a = files) === null || _a === void 0 ? void 0 : _a.forEach(function (fileItem, index) {
                var _a;
                if (((_a = fileItem) === null || _a === void 0 ? void 0 : _a.status) === 0) {
                    setTimeout(function () {
                        _this.storageService.download(fileItem.getEncodeURIComponentSrc());
                    }, 100 * count++);
                }
            });
        };
        FPControl.prototype.uploadFile = function (file) {
            var _this = this;
            FilePreviewer.UploadLimitChecker.checkFileCount(this.explorerControl.fileItems.length + 1, this.metadata.UploadLimit, function () {
                if (FilePreviewer.UploadLimitChecker.check(file, _this.metadata.UploadLimit, function (e) { return alert(e.errorMessage); })) {
                    FilePreviewer.UploadLimitChecker.compressFile(file, _this.metadata.UploadLimit, function (actualFile) {
                        var loadingFileItem = new FilePreviewer.LoadingFileItem(actualFile.name);
                        _this.explorerControl.addFile(loadingFileItem);
                        _this.storageService.upload(actualFile, {
                            success: function (e) {
                                if (_this.previewerControl.activeItem === loadingFileItem) {
                                    _this.previewerControl.activeItem = e.fileItem;
                                }
                                _this.explorerControl.replaceFile(loadingFileItem, e.fileItem);
                                _this.dispatch("ValueChanged");
                            },
                            fail: function (e) {
                                alert(e.errorMessage);
                                if (_this.previewerControl.activeItem === loadingFileItem) {
                                    _this.previewerControl.activeItem = _this.previewerControl.fileItems[0];
                                }
                                _this.explorerControl.removeFile(loadingFileItem);
                            },
                            progress: function (e) {
                                loadingFileItem.change(e);
                            }
                        });
                    });
                }
            }, function (errorMessage) {
                alert(errorMessage);
            });
        };
        return FPControl;
    }(FilePreviewer.UserControl));
    FilePreviewer.FPControl = FPControl;
    var FPView = (function (_super) {
        __extends(FPView, _super);
        function FPView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        FPView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-root\"></div>");
        };
        FPView.prototype.createChildren = function () {
            var _this = this;
            this.addChild(new FilePreviewer.ExplorerView(this.target.explorerControl));
            if (this.previewerRoot) {
                this.previewerRoot.remove();
            }
            this.previewerRoot = $("<div class=\"FP-root\"></div>");
            $(document.body).append(this.previewerRoot.hide());
            this.target.previewerControl.on("PropertyChanged", function (propertyName) {
                if (propertyName === "visibility") {
                    if (_this.target.previewerControl.visibility) {
                        _this.previewerRoot.show();
                    }
                    else {
                        _this.previewerRoot.hide();
                    }
                }
            });
            this.addChild(new FilePreviewer.PreviewerView(this.target.previewerControl), this.previewerRoot);
        };
        return FPView;
    }(FilePreviewer.ControlUIBase));
    FilePreviewer.FPView = FPView;
})(FilePreviewer || (FilePreviewer = {}));
