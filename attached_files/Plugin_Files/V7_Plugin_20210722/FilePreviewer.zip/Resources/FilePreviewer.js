var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer_1) {
    var FilePreviewer = (function (_super) {
        __extends(FilePreviewer, _super);
        function FilePreviewer() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.control = new FilePreviewer_1.FPControl();
            return _this;
        }
        FilePreviewer.prototype.createContent = function () {
            return this.control.identify(this.ID).createUI(FilePreviewer_1.FPView).container;
        };
        FilePreviewer.prototype.onLoad = function () {
            var _this = this;
            _super.prototype.onLoad.call(this);
            this.control.setMetadata(this.preHandleMetadata(this.CellElement));
            this.control.on("ValueChanged", function () {
                _this.commitValue();
            });
            this.control.refresh();
        };
        FilePreviewer.prototype.destroy = function () {
            this.control && this.control.dispose();
        };
        FilePreviewer.prototype.setValueToElement = function (jelement, value) {
            this.control.setValue(value);
        };
        FilePreviewer.prototype.getValueFromElement = function () {
            return this.control.getValue();
        };
        FilePreviewer.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.control.explorerControl.readonly = value;
        };
        FilePreviewer.prototype.preHandleMetadata = function (cellContentElement) {
            var thisArg = this;
            var model = cellContentElement.CellType;
            var result = {
                Readonly: !!model.Readonly,
                UploadLimit: model.UploadLimit,
                StorageType: model.StorageType,
                IsHiddenFileName: !!model.IsHiddenFileName,
                IsHiddenToolbar: !!model.IsHiddenToolbar,
                IsSmallButtonMode: !!model.IsSmallButtonMode,
                LayoutMode: model.LayoutMode,
                CustomWidth: model.CustomWidth || 64,
                CustomHeight: model.CustomHeight || 64,
                ServerPropertiesId: cellContentElement.ServerPropertiesId,
                get Bucket() {
                    return thisArg.evaluateFormula(model.Bucket);
                },
                get Region() {
                    return thisArg.evaluateFormula(model.Region);
                },
                get SecretId() {
                    return thisArg.evaluateFormula(model.SecretId);
                },
                get SecretKey() {
                    return thisArg.evaluateFormula(model.SecretKey);
                },
                get Folder() {
                    return thisArg.evaluateFormula(model.Folder);
                }
            };
            return result;
        };
        FilePreviewer.currentScriptSrc = document.scripts[document.scripts.length - 1].src;
        return FilePreviewer;
    }(Forguncy.Plugin.CellTypeBase));
    FilePreviewer_1.FilePreviewer = FilePreviewer;
})(FilePreviewer || (FilePreviewer = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("FilePreviewer.FilePreviewer, FilePreviewer", FilePreviewer.FilePreviewer);
