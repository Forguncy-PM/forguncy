/*
 Copyright (c) 2012-2018 Open Lab
 Written by Roberto Bicchierai and Silvia Chelazzi http://roberto.open-lab.com
 Permission is hereby granted, free of charge, to any person obtaining
 a copy of this software and associated documentation files (the
 "Software"), to deal in the Software without restriction, including
 without limitation the rights to use, copy, modify, merge, publish,
 distribute, sublicense, and/or sell copies of the Software, and to
 permit persons to whom the Software is furnished to do so, subject to
 the following conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


 todo For compatibility with IE and SVGElements.getElementsByClassName not implemented changed every find starting from SVGElement (the other works fine)
 .find(".classname"))  -> .find("[class*=classname])
 */
function Ganttalendar(startMillis, endMillis, master, minGanttSize) {
  this.master = master; // is the a GantEditor instance
  this.element; // is the jquery element containing gantt

  this.svg; // instance of svg object containing gantt
  this.tasksGroup; //instance of svg group containing tasks
  this.linksGroup; //instance of svg group containing links

  this.minGanttSize = minGanttSize;
  this.includeToday = false; //when true today is always visible. If false boundaries comes from tasks periods
  this.showCriticalPath = false; //when true critical path is highlighted

  /* <Modify the source code> */
  /*
   * In order to import multiple languages
   * 
   * <Origin code>
   * this.initZoomlevels(); // initialite the zoom level definitions
   * </Origin code>
   */
  this.initZoomlevels(master); // initialite the zoom level definitions
  /* </Modify the source code> */

  this.originalStartMillis = startMillis;
  this.originalEndMillis = endMillis;
  this.gridChanged = true; //witness for boundaries changed. Force to redraw gantt grid
  this.element = this.createGanttGrid(); // fake

  this.linkOnProgress = false; //set to true when creating a new link

  this.taskHeight = 20;
  this.resizeZoneWidth = 5;
  this.taskVertOffset = (this.master.rowHeight - this.taskHeight) / 2;

  /* <Modify the source code> */
  /*
   * instance of svg group containing grid
   */
  this.gridGroup;
  /* </Modify the source code> */
}

Ganttalendar.prototype.zoomGantt = function (isPlus) {
  var curLevel = this.zoom;
  var pos = this.zoomLevels.indexOf(curLevel + "");

  var centerMillis = this.getCenterMillis();
  var newPos = pos;
  if (isPlus) {
    newPos = pos <= 0 ? 0 : pos - 1;
  } else {
    newPos = pos >= this.zoomLevels.length - 1 ? this.zoomLevels.length - 1 : pos + 1;
  }
  if (newPos != pos) {
    curLevel = this.zoomLevels[newPos];
    this.gridChanged = true;
    this.zoom = curLevel;

    /* <Modify the source code> */
    /*
     * default month mode
     * 
     * <Origin code>
     * this.storeZoomLevel();
     * </Origin code>
     */
    // this.storeZoomLevel();
    /* </Modify the source code> */
    this.redraw();
    this.goToMillis(centerMillis);
  }
};

Ganttalendar.prototype.getStoredZoomLevel = function () {
  /* <Modify the source code> */
  /*
   * tasks may be is empty
   */
  if (this.master.tasks.length === 0) {
    return false;
  }
  /* </Modify the source code> */
  if (localStorage && localStorage.getObject("PluginGantt_TWPGanttSavedZooms")) {
    var savedZooms = localStorage.getObject("PluginGantt_TWPGanttSavedZooms");
    return savedZooms[this.master.tasks[0].id];
  }
  return false;
};

Ganttalendar.prototype.storeZoomLevel = function () {
  //console.debug("storeZoomLevel: "+this.zoom);
  if (localStorage) {
    var savedZooms;
    if (!localStorage.getObject("PluginGantt_TWPGanttSavedZooms")) savedZooms = {};
    else savedZooms = localStorage.getObject("PluginGantt_TWPGanttSavedZooms");

    savedZooms[this.master.tasks[0].id] = this.zoom;

    localStorage.setObject("PluginGantt_TWPGanttSavedZooms", savedZooms);
  }
};

Ganttalendar.prototype.createHeadCell = function (level, zoomDrawer, rowCtx, lbl, span, additionalClass, start, end) {
  var x = (start.getTime() - self.startMillis) * zoomDrawer.computedScaleX;
  var th = $("<th>").html(lbl).attr("colSpan", span);
  if (level > 1) {
    //set width on second level only
    var w = (end.getTime() - start.getTime()) * zoomDrawer.computedScaleX;
    th.width(w);
  }
  if (additionalClass) th.addClass(additionalClass);
  rowCtx.append(th);
};

Ganttalendar.prototype.createBodyCell = function (zoomDrawer, tr, span, isEnd, additionalClass) {
  var ret = $("<td>").html("").attr("colSpan", span).addClass("pluginGantt_ganttBodyCell");
  if (isEnd) ret.addClass("end");
  if (additionalClass) ret.addClass(additionalClass);
  tr.append(ret);
};

Ganttalendar.prototype.createGanttGrid = function () {
  //console.debug("Gantt.createGanttGrid zoom: "+this.zoom +"  " + new Date(this.originalStartMillis).format() + " - " + new Date(this.originalEndMillis).format());
  //var prof = new Profiler("ganttDrawer.createGanttGrid");
  var self = this;

  // get the zoomDrawer
  // if the desired level is not there uses the largest one (last one)
  var zoomDrawer = self.zoomDrawers[self.zoom] || self.zoomDrawers[self.zoomLevels[self.zoomLevels.length - 1]];

  //get best dimension for gantt
  var adjustedStartDate = new Date(this.originalStartMillis);
  var adjustedEndDate = new Date(this.originalEndMillis);
  zoomDrawer.adjustDates(adjustedStartDate, adjustedEndDate);

  self.startMillis = adjustedStartDate.getTime(); //real dimension of gantt
  self.endMillis = adjustedEndDate.getTime();

  //this is computed by hand in order to optimize cell size
  var computedTableWidth = (self.endMillis - self.startMillis) * zoomDrawer.computedScaleX;

  //set a minimal width
  computedTableWidth = Math.max(computedTableWidth, self.minGanttSize);

  var table = $("<table cellspacing=0 cellpadding=0>");

  //loop for header1
  var start = new Date(self.startMillis);
  var tr1 = $("<tr>").addClass("pluginGantt_ganttHead1");
  while (start.getTime() <= self.endMillis) {
    zoomDrawer.row1(start, tr1);
  }

  //loop for header2  e tbody
  start = new Date(self.startMillis);
  var tr2 = $("<tr>").addClass("pluginGantt_ganttHead2");
  var trBody = $("<tr>").addClass("pluginGantt_ganttBody");
  while (start.getTime() <= self.endMillis) {
    zoomDrawer.row2(start, tr2, trBody);
  }

  table.append(tr1).append(tr2); // removed as on FF there are rounding issues  //.css({width:computedTableWidth});

  var head = table.clone().addClass("pluginGantt_ganttFixHead");

  table.append(trBody).addClass("pluginGantt_ganttTable");

  /* <Modify the source code> */
  /*
   * self.master.editor.element.height() may be 0
   * 
   * <Origin code>
   * var height = self.master.editor.element.height();
   * </Origin code>
   */
  var height = self.master.editor.element.children().filter("tr[ishide=false]").length * self.master.rowHeight;
  /* </Modify the source code> */
  table.height(height);

  var box = $("<div>");
  box
    .addClass("gantt pluginGantt_unselectable")
    .attr("unselectable", "true")
    .css({ position: "relative", width: computedTableWidth });
  box.append(table);
  box.append(head);

  //create the svg
  box.svg({
    settings: { class: "pluginGantt_ganttSVGBox" },
    onLoad: function (svg) {
      //console.debug("svg loaded", svg);

      //creates gradient and definitions
      var defs = svg.defs("myDefs");

      //create backgound
      var extDep = svg.pattern(defs, "extDep", 0, 0, 10, 10, 0, 0, 10, 10, { patternUnits: "userSpaceOnUse" });
      var img = svg.image(extDep, 0, 0, 10, 10, self.master.resourceUrl + "res/hasExternalDeps.png", { opacity: 0.3 });

      self.svg = svg;
      $(svg).addClass("pluginGantt_ganttSVGBox");

      //creates grid group
      /* <Modify the source code> */
      /*
       * remove subsequent id
       * 
       * <Origin code>
       * var gridGroup = svg.group("gridGroup");
       * </Origin code>
       */
      self.gridGroup = svg.group("gridGroup");
      /* </Modify the source code> */

      //creates links group
      self.linksGroup = svg.group("linksGroup");

      //creates tasks group
      self.tasksGroup = svg.group("tasksGroup");

      //compute scalefactor fx
      //self.fx = computedTableWidth / (endPeriod - startPeriod);
      self.fx = zoomDrawer.computedScaleX;
    },
  });

  return box;
};

//<%-------------------------------------- GANT TASK GRAPHIC ELEMENT --------------------------------------%>
Ganttalendar.prototype.drawTask = function (task) {
  //console.debug("drawTask", task.name,this.master.showBaselines,this.taskHeight);
  var self = this;
  //var prof = new Profiler("ganttDrawTask");
  if (self.master.showBaselines) {
    var baseline = self.master.baselines[task.id];
    if (baseline) {
      //console.debug("baseLine",baseline)
      var baseTask = $(_createBaselineSVG(task, baseline));
      baseTask.css("opacity", 0.5);
      task.ganttBaselineElement = baseTask;
    }
  }

  /* <Modify the source code> */
  /*
   * single -> multiple, extract the `_addEvent` method to traverse the settings
   * 
   * <Origin code>
   * var taskBox = $(_createTaskSVG(task));
   * </Origin code>
   */
  var taskBox = [];
  switch(this.master.displaySVGType) {
    case this.master.DISPLAYSVGTYPES.ALL:
      $(_createTaskSVG(task, true));
      taskBox.push($(_createTaskSVG(task, false)));
      break;
    case this.master.DISPLAYSVGTYPES.PLAN:
      taskBox.push($(_createTaskSVG(task, false)));
      break;
    case this.master.DISPLAYSVGTYPES.ACTUAL:
      $(_createTaskSVG(task, true));
      break;
    default:
      break;
  }
  task.ganttElement = taskBox;

  if (self.showCriticalPath && task.isCritical) {
    taskBox.forEach(function (box) {
      box.addClass("pluginGantt_critical");
    })
  }

  if (this.master.permissions.canWrite || task.canWrite) {
    taskBox.forEach(function (box) {
      _addEvent(box, self);
    });
  }
  /* <Modify the source code> */

  //bind all events on taskBox
  function _addEvent (box, self) {
    box
      .click(function (e) {
        /* <Modify the source code> */
        /*
          * add call custom event
          */
        if (self.master.permissions.canSeePopEdit) {
            self.master.bindTaskRowClickEvent(task);
        }
        /* </Modify the source code> */

        // manages selection
        e.stopPropagation(); // to avoid body remove focused
        self.element.find("[class*=pluginGantt_focused]").removeClass("pluginGantt_focused");
        $(".pluginGantt_ganttSVGBox .pluginGantt_focused").removeClass("pluginGantt_focused");
        var el = $(this);
        if (!self.resDrop) el.addClass("pluginGantt_focused");
        self.resDrop = false; //hack to avoid select

        $("body")
          .off("click.pluginGantt_focused")
          .one("click.pluginGantt_focused", function () {
            $(".pluginGantt_ganttSVGBox .pluginGantt_focused").removeClass("pluginGantt_focused");
          });
      })
      .dblclick(function () {
        /* <Modify the source code> */
        /*
          * call custom event
          *
          * <Origin code>
          * taskBox.dblclick(function () {
          *   if (self.master.permissions.canSeePopEdit) self.master.editor.openFullEditor(task, false);
          * })
          */
        if (self.master.permissions.canSeePopEdit) {
          self.master.bindTaskRowDblClickEvent(task);
        }
        /* </Modify the source code> */
      })
      .mouseenter(function () {
        //bring to top
        var el = $(this);
        if (!self.linkOnProgress) {
          $("[class*=pluginGantt_linkHandleSVG]").hide();
          el.find("[class*=pluginGantt_linkHandleSVG]").stopTime("hideLink").show();
        } else {
          el.addClass("pluginGantt_linkOver");
        }
      })
      .mouseleave(function () {
        var el = $(this);
        el.removeClass("pluginGantt_linkOver")
          .find("[class*=pluginGantt_linkHandleSVG]")
          .oneTime(500, "hideLink", function () {
            $(this).hide();
          });
      })
      .mouseup(function (e) {
        $(":focus").blur(); // in order to save grid field when moving task
      })
      .mousedown(function () {
        var task = self.master.getTask($(this).attr("taskid"));
        task.rowElement.click();
      })
      .dragExtedSVG($(self.svg.root()), {
        /* <Modify the source code> */
        /*
         * <Origin code>
         * canResize: self.master.permissions.canWrite || task.canWrite,
         * canDrag: !task.depends && (self.master.permissions.canWrite || task.canWrite),
         * </Origin code>
         */
        canResize: (self.master.permissions.canWrite || task.canWrite) && !task.isParent(),
        canDrag: (self.master.permissions.canWrite || task.canWrite) && task.canChangeDate(true),
        /* </Modify the source code> */
        resizeZoneWidth: self.resizeZoneWidth,
        startDrag: function (e) {
          $(".pluginGantt_ganttSVGBox .pluginGantt_focused").removeClass("pluginGantt_focused");
        },
        drag: function (e) {
          var el = $(this);
          var taskId = el.attr("taskid");
          /* <Modify the source code> */
          /*
           * DOMException: Failed to execute 'querySelectorAll' on 'Document'
           * 
           * <Origin code>
           * $("[from=" + taskId + "],[to=" + taskId + "]").trigger("update");
           * </Origin code>
           */
          $("[from='" + taskId + "'],[to='" + taskId + "']").trigger("update");
          /* </Modify the source code> */
        },
        drop: function (e) {
          self.resDrop = true; //hack to avoid select
          var el = $(this);
          var taskId = el.attr("taskid");
          var task = self.master.getTask(taskId);
          var s = Math.round(parseFloat(el.attr("x")) / self.fx + self.startMillis);
          self.master.beginTransaction();
          /* <Modify the source code> */
          /*
           * <Origin code>
           * self.master.moveTask(task, new Date(s));
           * </Origin code>
           */
          if (task.parentHasDepend() && s < task.getParent().start) {
            task.master.setErrorOnTransaction("\"" + task.name + "\"\n" + task.master.lang.Error["TASK_PARENT_HAS_PERDECESSORS_START_TIME_EARLY"], task);
          } else {
            self.master.moveTask(task, new Date(s));
          }
          /* </Modify the source code> */
          self.master.endTransaction();
        },
        startResize: function (e) {
          $(".pluginGantt_ganttSVGBox .pluginGantt_focused").removeClass("pluginGantt_focused");
          var el = $(this);
          var text = $(
            self.svg.text(
              parseInt(el.attr("x")) + parseInt(el.attr("width") + 8),
              parseInt(el.attr("y")),
              "",
              { "font-size": "10px", fill: "red" }
            )
          );
          el.data("textDur", text);
        },
        resize: function (e) {
          //find and update links from, to
          var el = $(this);
          var st = Math.round(parseFloat(el.attr("x")) / self.fx + self.startMillis);
          var en = Math.round(
            (parseFloat(el.attr("x")) + parseFloat(el.attr("width"))) / self.fx + self.startMillis
          );
          var d = getDurationInUnits(computeStartDate(st), computeEndDate(en));
          var text = el.data("textDur");
          /* <Modify the source code> */
          /*
           * TypeError: Cannot read property 'attr' of undefined
           * 
           * <Origin code>
           * text.attr("x", parseInt(el.attr("x")) + parseInt(el.attr("width")) + 8).html(durationToString(d));
           * </Origin code>
           */
          if (text) {
            text.attr("x", parseInt(el.attr("x")) + parseInt(el.attr("width")) + 8).html(durationToString(d));
          }
          /* </Modify the source code> */
          var taskId = el.attr("taskid");
          /* <Modify the source code> */
          /*
           * DOMException: Failed to execute 'querySelectorAll' on 'Document'
           * 
           * <Origin code>
           * $("[from=" + taskId + "],[to=" + taskId + "]").trigger("update");
           * </Origin code>
           */
          $("[from='" + taskId + "'],[to='" + taskId + "']").trigger("update");
          /* </Modify the source code> */
        },
        stopResize: function (e) {
          self.resDrop = true; //hack to avoid select
          var el = $(this);
          var textBox = el.data("textDur");
          if (textBox) textBox.remove();
          var task = self.master.getTask(el.attr("taskid"));
          var st = Math.round(parseFloat(el.attr("x")) / self.fx + self.startMillis);
          var en = Math.round(
            (parseFloat(el.attr("x")) + parseFloat(el.attr("width"))) / self.fx + self.startMillis
          );

          //in order to avoid rounding issue if the movement is less than 1px we keep the same start and end dates
          if (Math.abs(st - task.start) < 1 / self.fx) {
            st = task.start;
          }
          if (Math.abs(en - task.end) < 1 / self.fx) {
            en = task.end;
          }

          self.master.beginTransaction();
          self.master.changeTaskDates(task, new Date(st), new Date(en));
          self.master.endTransaction();
        },
      });

    //binding for creating link
    box.find("[class*=pluginGantt_linkHandleSVG]").mousedown(function (e) {
      e.preventDefault();
      e.stopPropagation();
      var box = $(this).closest(".pluginGantt_taskBoxSVG");
      var svg = $(self.svg.root());
      var offs = svg.offset();
      self.linkOnProgress = true;
      self.linkFromEnd = $(this).is(".pluginGantt_taskLinkEndSVG");
      svg.addClass("pluginGantt_linkOnProgress");

      // create the line
      var startX = parseFloat(box.attr("x")) + (self.linkFromEnd ? parseFloat(box.attr("width")) : 0);
      var startY = parseFloat(box.attr("y")) + parseFloat(box.attr("height")) / 2;
      var line = self.svg.line(startX, startY, e.pageX - offs.left - 5, e.pageY - offs.top - 5, {
        class: "pluginGantt_linkLineSVG",
      });
      var circle = self.svg.circle(startX, startY, 5, { class: "pluginGantt_linkLineSVG" });

      //bind mousemove to draw a line
      svg.bind("mousemove.linkSVG", function (e) {
        var offs = svg.offset();
        var nx = e.pageX - offs.left;
        var ny = e.pageY - offs.top;
        var c = Math.sqrt(Math.pow(nx - startX, 2) + Math.pow(ny - startY, 2));
        nx = nx - ((nx - startX) * 10) / c;
        ny = ny - ((ny - startY) * 10) / c;
        self.svg.change(line, { x2: nx, y2: ny });
        self.svg.change(circle, { cx: nx, cy: ny });
      });

      //bind mouseup un body to stop
      $("body").one("mouseup.linkSVG", function (e) {
        $(line).remove();
        $(circle).remove();
        self.linkOnProgress = false;
        svg.removeClass("pluginGantt_linkOnProgress");

        $(self.svg.root()).unbind("mousemove.linkSVG");
        var targetBox = $(e.target).closest(".pluginGantt_taskBoxSVG");
        //console.debug("create link from " + taskBox.attr("taskid") + " to " + targetBox.attr("taskid"));

        if (targetBox && targetBox.attr("taskid") != box.attr("taskid")) {
          var taskTo;
          var taskFrom;
          if (self.linkFromEnd) {
            taskTo = self.master.getTask(targetBox.attr("taskid"));
            taskFrom = self.master.getTask(box.attr("taskid"));
          } else {
            taskFrom = self.master.getTask(targetBox.attr("taskid"));
            taskTo = self.master.getTask(box.attr("taskid"));
          }

          if (taskTo && taskFrom) {
            var gap = 0;
            var depInp = taskTo.rowElement.find("[name=depends]");
            depInp.val(
              depInp.val() +
                ((depInp.val() + "").length > 0 ? "," : "") +
                (taskFrom.getRow() + 1) +
                (gap != 0 ? ":" + gap : "")
            );
            depInp.blur();
          }
        }
      });
    });
  }
  //ask for redraw link
  self.redrawLinks();

  //prof.stop();

  /* <Modify the source code> */
  /*
   * add displayType to control svg show
   * all: show plan and actual | height / 2 | y = 0 && y = height / 2
   * plan:      just show plan | height     | y = 0
   * actual:  just show actual | height     | y = 0
   * 
   * <Origin code>
   * function _createTaskSVG(task) {
   * var svg = self.svg;
	 * var dimensions = {
	 *	 x: Math.round((task.start - self.startMillis) * self.fx),
	 *	 y: task.rowElement.position().top + task.rowElement.offsetParent().scrollTop() + self.taskVertOffset,
	 *   width : Math.max(Math.round((task.end - task.start) * self.fx), 1),
	 *   height: (self.master.showBaselines ? self.taskHeight / 1.3 : self.taskHeight)
	 * };
   * var taskSvg = svg.svg(self.tasksGroup, dimensions.x, dimensions.y, dimensions.width, dimensions.height, {class:"taskBox taskBoxSVG taskStatusSVG", status:task.status, taskid:task.id,fill:task.color||"#eee" });
   * </Origin code>
   */
  function _createTaskSVG(task, isActual) {
    var svg = self.svg;
    var classNames = "pluginGantt_taskBox pluginGantt_taskBoxSVG";
    var dimensionsFullHight = (self.master.showBaselines ? self.taskHeight / 1.3 : self.taskHeight);
    const index = Math.max(task.rowElement.parent().children("tr").filter("[ishide=false]").index(task.rowElement), 0);
    var dimensionsBasisY = index * task.master.rowHeight + $("table.pluginGantt_ganttFixHead").height() + self.taskVertOffset;
    var dimensions = {
      x: 0,
      y: 0,
      width: 0,
      height: 0
    };
    // verbose but easy to understand
    switch(self.master.displaySVGType) {
      case self.master.DISPLAYSVGTYPES.ALL:
        if (isActual) {
          // top: plan, bottom: actual
          if (needDrawActualSvg(task)) {
            setBaseActualSVG();
            dimensions.y = dimensionsBasisY + dimensionsFullHight;
            dimensions.height = dimensionsFullHight / 3;
          }
        } else {
          setBasePlanSVG();
          dimensions.height = dimensionsFullHight; 
        }
        break;
      case self.master.DISPLAYSVGTYPES.PLAN:
        if (!isActual) {
          setBasePlanSVG();
        } 
        dimensions.height = dimensionsFullHight; 
        break;
      case self.master.DISPLAYSVGTYPES.ACTUAL:
        if (isActual) {
          if (needDrawActualSvg(task)) {
            setBaseActualSVG();
          }
        } 
        dimensions.height = dimensionsFullHight; 
        break;
      default:
        break;
    }
    function needDrawActualSvg (task) {
      return !!task.actualStart && !!task.actualDuration && !!task.actualEnd;
    }
    function setBaseActualSVG () {
      classNames += "";
      dimensions.x = Math.round((task.actualStart - self.startMillis) * self.fx);
      dimensions.width = Math.max(Math.round((task.actualEnd - task.actualStart) * self.fx), 1);
      dimensions.y = dimensionsBasisY;
    }
    function setBasePlanSVG () {
      classNames += " pluginGantt_taskStatusSVG";
      dimensions.x = Math.round((task.start - self.startMillis) * self.fx);
      dimensions.width = Math.max(Math.round((task.end - task.start) * self.fx), 1);
      dimensions.y = dimensionsBasisY;
    }

    var taskSvg = svg.svg(self.tasksGroup, dimensions.x, dimensions.y, dimensions.width, dimensions.height, {
      class: classNames,
      status: task.status,
      taskid: task.id,
      isactual: isActual ? 'actual' : 'plan',
      fill: isActual ? "#7D63D9" : (task.color || "#eee")
    });
    /* </Modify the source code> */

    //svg.title(taskSvg, task.name);
    //external box
    
    /* <Modify the source code> */
    /*
     * <Origin code>
     * var layout = svg.rect(taskSvg, 0, 0, "100%", "100%", { class: "pluginGantt_taskLayout", rx: "2", ry: "2" });
     * <Origin code>
     */
    var layout = svg.rect(taskSvg, 0, 0, "100%", "100%", { class: "pluginGantt_taskLayout", rx: 0, ry: 0 });
    if (self.master.displaySVGType === self.master.DISPLAYSVGTYPES.ALL && isActual) {
      return;
    }
    /* </Modify the source code> */
        
    //external dep
    if (task.hasExternalDep) svg.rect(taskSvg, 0, 0, "100%", "100%", { fill: "url(#extDep)" });

    //progress
    if (task.progress > 0) {
      /* <Modify the source code> */
      /*
       * <Origin code>
       * var progress = svg.rect(taskSvg, 0, "20%", (task.progress > 100 ? 100 : task.progress) + "%", "100%", {
       *  rx: "2",
       *  ry: "2",
       *  fill: "rgba(0,0,0,.4)",
       * });
       * if (dimensions.width > 50) {
       *  var textStyle = {
       *    fill: "#888",
       *    "font-size": "10px",
       *    class: "pluginGantt_textPerc pluginGantt_teamworkIcons",
       *    transform: "translate(5)",
       *  };
       *  if (task.progress > 100) textStyle["font-weight"] = "bold";
       *  if (task.progress > 90) textStyle.transform = "translate(-40)";
       *  svg.text(
       *    taskSvg,
       *    (task.progress > 90 ? 100 : task.progress) + "%",
       *    (self.master.rowHeight - 5) / 2,
       *    (task.progress > 100 ? "!!! " : "") + task.progress + "%",
       *    textStyle
       *  );
       * }
       * </Origin code>
       */
      var progress = svg.rect(taskSvg, 0, 0, (task.progress > 100 ? 100 : task.progress) + "%", "100%", {
       rx: 0,
       ry: 0,
       fill: "rgba(0,0,0,.3)",
      });
      if (dimensions.width > 50) {
        var textStyle = {
          fill: "#fff",
          "font-size": "10px",
          class: "pluginGantt_textPerc pluginGantt_teamworkIcons",
          transform: "translate(5)",
        };
        if (task.progress > 50) textStyle.transform = "translate(-25)";
        if (task.progress === 100) textStyle.transform = "translate(-35)";
        if (task.progress > 100) {
          textStyle["font-weight"] = "bold";
          textStyle.transform = "translate(-45)";
        }
        svg.text(
          taskSvg,
          (task.progress > 100 ? 100 : task.progress) + "%",
          (self.master.rowHeight - 5) / 2,
          (task.progress > 100 ? "!!! " : "") + task.progress + "%",
          textStyle
        );
      }
      /* </Modify the source code> */
    }

    if (task.isParent()) svg.rect(taskSvg, 0, 0, "100%", 3, { fill: "#000" });

    if (task.startIsMilestone) {
      svg.image(taskSvg, -9, dimensions.height / 2 - 9, 18, 18, self.master.resourceUrl + "res/milestone.png");
    }

    if (task.endIsMilestone) {
      svg.image(taskSvg, "100%", dimensions.height / 2 - 9, 18, 18, self.master.resourceUrl + "res/milestone.png", {
        transform: "translate(-9)",
      });
    }

    //task label
    /* <Modify the source code> */
    /*
     * if display SVG type is 'all', only show text on actual svg. 
     *
     * <Origin code>
     * svg.text(taskSvg, "100%", 18, task.name, { class: "pluginGantt_taskLabelSVG", transform: "translate(20,-5)" });
     * </Origin code>
     */
    svg.text(taskSvg, "100%", (self.master.rowHeight - 5) / 2, task.name, { class: "pluginGantt_taskLabelSVG", transform: "translate(5)", "font-size": "10px" });
    /* </Modify the source code> */

    //link tool
    if (task.level > 0) {
      svg.circle(taskSvg, -self.resizeZoneWidth, dimensions.height / 2, dimensions.height / 3, {
        class: "pluginGantt_taskLinkStartSVG pluginGantt_linkHandleSVG",
        transform: "translate(" + (-dimensions.height / 3 + 1) + ")",
      });
      svg.circle(taskSvg, dimensions.width + self.resizeZoneWidth, dimensions.height / 2, dimensions.height / 3, {
        class: "pluginGantt_taskLinkEndSVG pluginGantt_linkHandleSVG",
        transform: "translate(" + (dimensions.height / 3 - 1) + ")",
      });
    }
    return taskSvg;
  }

  function _createBaselineSVG(task, baseline) {
    var svg = self.svg;
    /* <Modify the source code> */
    const index = Math.max(task.rowElement.parent().children("tr").filter("[ishide=false]").index(task.rowElement), 0);
    /* </Modify the source code> */
    var dimensions = {
      x: Math.round((baseline.startDate - self.startMillis) * self.fx),
      y:
        /* <Modify the source code> */
        /*
         * editorRow.position().top + editorRow.offsetParent().scrollTop() may be 0
         * 
         * <Origin code>
         * task.rowElement.position().top +
         * task.rowElement.offsetParent().scrollTop() +
         * </Origin code>
         */
        index * task.master.rowHeight +
        $("table.pluginGantt_ganttFixHead").height() +
        /* </Modify the source code> */
        self.taskVertOffset +
        self.taskHeight / 2,
      width: Math.max(Math.round((baseline.endDate - baseline.startDate) * self.fx), 1),
      height: self.master.showBaselines ? self.taskHeight / 1.5 : self.taskHeight,
    };
    var taskSvg = svg.svg(self.tasksGroup, dimensions.x, dimensions.y, dimensions.width, dimensions.height, {
      class: "pluginGantt_taskBox pluginGantt_taskBoxSVG pluginGantt_taskStatusSVG baseline",
      status: baseline.status,
      taskid: task.id,
      fill: task.color || "#eee",
    });

    //tooltip
    var label = "<b>" + task.name + "</b>";
    label += "<br>";
    label += "@" + new Date(self.master.baselineMillis).format();
    label += "<br><br>";
    label += "<b>Status:</b> " + baseline.status;
    label += "<br><br>";
    label += "<b>Start:</b> " + new Date(baseline.startDate).format();
    label += "<br>";
    label += "<b>End:</b> " + new Date(baseline.endDate).format();
    label += "<br>";
    label += "<b>Duration:</b> " + baseline.duration;
    label += "<br>";
    label += "<b>Progress:</b> " + baseline.progress + "%";

    $(taskSvg)
      .attr("data-label", label)
      .on("click", function (event) {
        showBaselineInfo(event, this);
        //bind hide
      });

    //external box
    var layout = svg.rect(taskSvg, 0, 0, "100%", "100%", { class: "pluginGantt_taskLayout", rx: "2", ry: "2" });

    //progress

    if (baseline.progress > 0) {
      var progress = svg.rect(taskSvg, 0, "20%", (baseline.progress > 100 ? 100 : baseline.progress) + "%", "60%", {
        rx: "2",
        ry: "2",
        fill: "rgba(0,0,0,.4)",
      });
      /*if (dimensions.width > 50) {
                   var textStyle = {fill:"#888", "font-size":"10px",class:"textPerc teamworkIcons",transform:"translate(5)"};
                   if (baseline.progress > 100)
                   textStyle["font-weight"]="bold";
                   if (baseline.progress > 90)
                   textStyle.transform = "translate(-40)";
                   svg.text(taskSvg, (baseline.progress > 90 ? 100 : baseline.progress) + "%", (self.master.rowHeight - 5) / 2, (baseline.progress > 100 ? "!!! " : "") + baseline.progress + "%", textStyle);
                   }*/
    }

    //if (task.isParent())
    //  svg.rect(taskSvg, 0, 0, "100%", 3, {fill:"#000"});

    //task label
    //svg.text(taskSvg, "100%", 18, task.name, {class:"taskLabelSVG", transform:"translate(20,-5)"});

    return taskSvg;
  }
};

Ganttalendar.prototype.addTask = function (task) {
  //currently do nothing
};

//<%-------------------------------------- GANT DRAW LINK SVG ELEMENT --------------------------------------%>
//'from' and 'to' are tasks already drawn
Ganttalendar.prototype.drawLink = function (from, to, type) {
  //console.debug("drawLink")
  var self = this;
  var peduncolusSize = 10;

  /**
   * Given an item, extract its rendered position
   * width and height into a structure.
   */
  function buildRectFromTask(task) {
    var self = task.master.gantt;
    var editorRow = task.rowElement;
    /* <Modify the source code> */
    /*
     * editorRow.position().top + editorRow.offsetParent().scrollTop() may be 0
     * 
     * <Origin code>
     * var top = editorRow.position().top + editorRow.offsetParent().scrollTop();
     * </Origin code>
     */
    const index = Math.max(task.rowElement.parent().children("tr").filter("[ishide=false]").index(task.rowElement), 0);
    var top = index * task.master.rowHeight + $("table.pluginGantt_ganttFixHead").height();
    /* </Modify the source code> */
    var x = Math.round((task.start - self.startMillis) * self.fx);
    var rect = {
      left: x,
      top: top + self.taskVertOffset,
      width: Math.max(Math.round((task.end - task.start) * self.fx), 1),
      height: self.taskHeight,
    };
    /* <Modify the source code> */
    /*
     * if show actual, the link subject to actual
     * now still follow the actual
     */
    // if (task.master.displaySVGType === task.master.DISPLAYSVGTYPES.ALL || task.master.displaySVGType === task.master.DISPLAYSVGTYPES.Actual) {
    //   rect.left = Math.round((task.actualStart - self.startMillis) * self.fx);
    //   rect.width = Math.max(Math.round((task.actualEnd - task.actualStart) * self.fx), 1);
    // }
    /* </Modify the source code> */
    return rect;
  }

  /**
   * The default rendering method, which paints a start to end dependency.
   */
  function drawStartToEnd(from, to, ps) {
    var svg = self.svg;

    //this function update an existing link
    function update() {
      var group = $(this);
      var from = group.data("from");
      var to = group.data("to");

      var rectFrom = buildRectFromTask(from);
      var rectTo = buildRectFromTask(to);

      var fx1 = rectFrom.left;
      var fx2 = rectFrom.left + rectFrom.width;
      var fy = rectFrom.height / 2 + rectFrom.top;

      var tx1 = rectTo.left;
      var tx2 = rectTo.left + rectTo.width;
      var ty = rectTo.height / 2 + rectTo.top;

      var tooClose = tx1 < fx2 + 2 * ps;
      /* <Modify the source code> */
      /*
       * <Origin Code>
       * var r = 5; //radius
       * </Origin Code>
       */
      var r = 0; //radius
      /* </Modify the source code> */
      var arrowOffset = 5;
      var up = fy > ty;
      var fup = up ? -1 : 1;

      var prev = fx2 + 2 * ps > tx1;
      var fprev = prev ? -1 : 1;

      var image = group.find("image");
      var p = svg.createPath();

      if (tooClose) {
        var firstLine = fup * (rectFrom.height / 2 - 2 * r + 2);
        p.move(fx2, fy)
          .line(ps, 0, true)
          .arc(r, r, 90, false, !up, r, fup * r, true)
          .line(0, firstLine, true)
          .arc(r, r, 90, false, !up, -r, fup * r, true)
          .line(fprev * 2 * ps + (tx1 - fx2), 0, true)
          .arc(r, r, 90, false, up, -r, fup * r, true)
          .line(0, (Math.abs(ty - fy) - 4 * r - Math.abs(firstLine)) * fup - arrowOffset, true)
          .arc(r, r, 90, false, up, r, fup * r, true)
          .line(ps, 0, true);
        image.attr({ x: tx1 - 5, y: ty - 5 - arrowOffset });
      } else {
        p.move(fx2, fy)
          .line((tx1 - fx2) / 2 - r, 0, true)
          .arc(r, r, 90, false, !up, r, fup * r, true)
          .line(0, ty - fy - fup * 2 * r + arrowOffset, true)
          .arc(r, r, 90, false, up, r, fup * r, true)
          .line((tx1 - fx2) / 2 - r, 0, true);
        image.attr({ x: tx1 - 5, y: ty - 5 + arrowOffset });
      }

      group.find("path").attr({ d: p.path() });
    }

    // create the group
    var group = svg.group(self.linksGroup, "" + from.id + "-" + to.id);
    svg.title(group, from.name + " -> " + to.name);

    var p = svg.createPath();

    //add the arrow
    svg.image(group, 0, 0, 5, 10, self.master.resourceUrl + "res/linkArrow.png");
    //create empty path
    svg.path(group, p, { class: "pluginGantt_taskLinkPathSVG" });

    //set "from" and "to" to the group, bind "update" and trigger it
    var jqGroup = $(group)
      .data({ from: from, to: to })
      .attr({ from: from.id, to: to.id })
      .on("update", update)
      .trigger("update");

    if (self.showCriticalPath && from.isCritical && to.isCritical) jqGroup.addClass("pluginGantt_critical");

    jqGroup.addClass("linkGroup");
    return jqGroup;
  }

  /**
   * A rendering method which paints a start to start dependency.
   */
  function drawStartToStart(from, to) {
    console.error("StartToStart not supported on SVG");
    var rectFrom = buildRectFromTask(from);
    var rectTo = buildRectFromTask(to);
  }

  var link;
  // Dispatch to the correct renderer
  if (type == "start-to-start") {
    link = drawStartToStart(from, to, peduncolusSize);
  } else {
    link = drawStartToEnd(from, to, peduncolusSize);
  }

  // in order to create a dependency you will need permissions on both tasks
  if (this.master.permissions.canWrite || (from.canWrite && to.canWrite)) {
    link.click(function (e) {
      var el = $(this);
      e.stopPropagation(); // to avoid body remove focused
      self.element.find("[class*=pluginGantt_focused]").removeClass("pluginGantt_focused");
      $(".pluginGantt_ganttSVGBox .pluginGantt_focused").removeClass("pluginGantt_focused");
      var el = $(this);
      if (!self.resDrop) el.addClass("pluginGantt_focused");
      self.resDrop = false; //hack to avoid select

      $("body")
        .off("click.pluginGantt_focused")
        .one("click.pluginGantt_focused", function () {
          $(".pluginGantt_ganttSVGBox .pluginGantt_focused").removeClass("pluginGantt_focused");
        });
    });
  }
};

Ganttalendar.prototype.redrawLinks = function () {
  //console.debug("redrawLinks ");
  var self = this;
  this.element.stopTime("ganttlnksredr");
  this.element.oneTime(10, "ganttlnksredr", function () {
    //var prof=new Profiler("gd_drawLink_real");

    //remove all links
    /* <Modify the source code> */
    /*
     * use attributes on the propertype chain instead of id(#linksGroup)
     * 
     * <Origin code>
     * $("#linksGroup").empty();
     * </Origin code>
     */
    $(self.linksGroup).empty();
    /* </Modify the source code> */

    var collapsedDescendant = [];

    //[expand]
    var collapsedDescendant = self.master.getCollapsedDescendant();
    for (var i = 0; i < self.master.links.length; i++) {
      var link = self.master.links[i];

      if (collapsedDescendant.indexOf(link.from) >= 0 || collapsedDescendant.indexOf(link.to) >= 0) continue;

      var rowA = link.from.getRow();
      var rowB = link.to.getRow();

      //if link is out of visible screen continue
      if (
        Math.max(rowA, rowB) < self.master.firstVisibleTaskIndex ||
        Math.min(rowA, rowB) > self.master.lastVisibleTaskIndex
      )
        continue;

      self.drawLink(link.from, link.to);
    }
    //prof.stop();
  });
};

Ganttalendar.prototype.reset = function () {
  //var prof= new Profiler("ganttDrawerSVG.reset");
  this.element.find("[class*=linkGroup]").remove();
  this.element.find("[taskid]").remove();
  //prof.stop()
};

Ganttalendar.prototype.redrawTasks = function (drawAll) {
  //console.debug("redrawTasks ");
  var self = this;
  //var prof = new Profiler("ganttRedrawTasks");

  /* <Modify the source code> */
  /*
   * self.master.editor.element.height() may be 0
   * 
   * <Origin code>
   * self.element.find("table.pluginGantt_ganttTable").height(self.master.editor.element.height());
   * </Origin code>
   */
  self.element.find("table.pluginGantt_ganttTable").height(self.master.editor.element.children().filter("tr[ishide=false]").length * self.master.rowHeight);
  /* <Modify the source code> */

  var collapsedDescendant = this.master.getCollapsedDescendant();

  var startRowAdd = self.master.firstScreenLine - self.master.rowBufferSize;
  var endRowAdd = self.master.firstScreenLine + self.master.numOfVisibleRows + self.master.rowBufferSize;

  /* <Modify the source code> */
  /*
   * use attributes on the propertype chain instead of id(#linksGroup,#tasksGroup, #gridGroup)
   * 
   * <Origin code>
   * $("#linksGroup,#tasksGroup").empty();
   * var gridGroup = $("#gridGroup").empty().get(0);
   * </Origin code>
   */
  $(self.linksGroup).empty();
  $(self.tasksGroup).empty();
  var gridGroup = $(self.gridGroup).empty().get(0);
  /* </Modify the source code> */

  //add missing ones
  var row = 0;
  self.master.firstVisibleTaskIndex = -1;
  for (var i = 0; i < self.master.tasks.length; i++) {
    var task = self.master.tasks[i];
    if (collapsedDescendant.indexOf(task) >= 0) {
      continue;
    }
    if (drawAll || (row >= startRowAdd && row < endRowAdd)) {
      this.drawTask(task);
      self.master.firstVisibleTaskIndex =
        self.master.firstVisibleTaskIndex == -1 ? i : self.master.firstVisibleTaskIndex;
      self.master.lastVisibleTaskIndex = i;
    }
    row++;
  }

  //creates rows grid
  /* <Modify the source code> */
  /*
   * self.master.editor.element.height() may be 0
   * 
   * <Origin code>
   * for (var i = 40; i <= self.master.editor.element.height(); i += self.master.rowHeight)
   *   self.svg.rect(gridGroup, 0, i, "100%", self.master.rowHeight, { class: "pluginGantt_ganttLinesSVG" });
   * </Origin code>
   */
  for (var i = 40; i <= self.master.editor.element.children().filter("tr[ishide=false]").length * self.master.rowHeight; i += self.master.rowHeight)
    self.svg.rect(gridGroup, 0, i, "100%", self.master.rowHeight, { class: "pluginGantt_ganttLinesSVG" });
  /* <Modify the source code> */

  // drawTodayLine
  if (new Date().getTime() > self.startMillis && new Date().getTime() < self.endMillis) {
    var x = Math.round((new Date().getTime() - self.startMillis) * self.fx);
    self.svg.line(gridGroup, x, 0, x, "100%", { class: "pluginGantt_ganttTodaySVG" });
  }

  //prof.stop();
};

Ganttalendar.prototype.shrinkBoundaries = function () {
  //console.debug("shrinkBoundaries")
  var start = Infinity;
  var end = -Infinity;
  for (var i = 0; i < this.master.tasks.length; i++) {
    var task = this.master.tasks[i];
    if (start > task.start) start = task.start;
    if (end < task.end) end = task.end;
  }

  //if include today synch extremes
  if (this.includeToday) {
    var today = new Date().getTime();
    start = start > today ? today : start;
    end = end < today ? today : end;
  }

  //mark boundaries as changed
  this.gridChanged = this.gridChanged || this.originalStartMillis != start || this.originalEndMillis != end;

  this.originalStartMillis = start;
  this.originalEndMillis = end;
};

Ganttalendar.prototype.setBestFittingZoom = function () {
  //console.debug("setBestFittingZoom");

  if (this.getStoredZoomLevel()) {
    this.zoom = this.getStoredZoomLevel();
    return;
  }

  //if zoom is not defined get the best fitting one
  var dur = this.originalEndMillis - this.originalStartMillis;
  var minDist = Number.MAX_VALUE;
  var i = 0;
  for (; i < this.zoomLevels.length; i++) {
    var dist = Math.abs(dur - millisFromString(this.zoomLevels[i]));
    if (dist <= minDist) {
      minDist = dist;
    } else {
      break;
    }
    this.zoom = this.zoomLevels[i];
  }

  this.zoom = this.zoom || this.zoomLevels[this.zoomLevels.length - 1];
};

Ganttalendar.prototype.redraw = function () {
  //console.debug("redraw",this.zoom, this.originalStartMillis, this.originalEndMillis);
  //var prof= new Profiler("Ganttalendar.redraw");

  if (this.showCriticalPath) {
    this.master.computeCriticalPath();
  }

  if (this.gridChanged) {
    this.gridChanged = false;
    var par = this.element.parent();

    //try to maintain last scroll
    var scrollY = par.scrollTop();
    var scrollX = par.scrollLeft();

    this.element.remove();

    var domEl = this.createGanttGrid();
    this.element = domEl;
    par.append(domEl);
    this.redrawTasks();

    //set old scroll
    par.scrollTop(scrollY);
    par.scrollLeft(scrollX);
  } else {
    this.redrawTasks();
  }

  //set current task
  this.synchHighlight();

  //prof.stop();
  //Profiler.displayAll();
  //Profiler.reset()
};

Ganttalendar.prototype.fitGantt = function () {
  delete this.zoom;
  this.redraw();
};

Ganttalendar.prototype.synchHighlight = function () {
  //console.debug("synchHighlight",this.master.currentTask);
  if (this.master.currentTask) {
    // take care of collapsed rows
    /* <Modify the source code> */
    /*
     * GanttMaster.prototype.collapse && GanttMaster.prototype.expand
     * define new attr. to determine the fold([ishide=false])
     * 
     * <Origin code>
     * var ganttHighLighterPosition = this.master.editor.element
     *   .find(".pluginGantt_taskEditRow:visible")
     *   .index(this.master.currentTask.rowElement);
     * </Origin code>
     */
    var ganttHighLighterPosition = this.master.editor.element
      .find(".pluginGantt_taskEditRow[ishide=false]")
      .index(this.master.currentTask.rowElement);
    /* </Modify the source code> */
    this.master.gantt.element
      .find(".pluginGantt_ganttLinesSVG")
      .removeClass("pluginGantt_rowSelected")
      .eq(ganttHighLighterPosition)
      .addClass("pluginGantt_rowSelected");
  } else {
    $(".pluginGantt_rowSelected").removeClass("pluginGantt_rowSelected"); // todo non c'era
  }
};

Ganttalendar.prototype.getCenterMillis = function () {
  return parseInt(
    (this.element.parent().scrollLeft() + this.element.parent().width() / 2) / this.fx + this.startMillis
  );
};

Ganttalendar.prototype.goToMillis = function (millis) {
  /* <Modify the source code> */
  /*
   * The scrollbar in the icon part will be on the far left. Because this.element.parent().width() === 0.
   * 
   * bugx 11859
   * GanttMaster.prototype.loadProject: this.gantt.element.oneTime(200, function () { self.gantt.centerOnToday() });
   */
  if (!this.element.parent().width()) {
    var self = this;
    this.master.gantt.element.oneTime(200, function () { self.master.gantt.centerOnToday() });
    return;
  }
  /* </Modify the source code> */
  var x = Math.round((millis - this.startMillis) * this.fx) - this.element.parent().width() / 2;
  this.element.parent().scrollLeft(x);
};

Ganttalendar.prototype.centerOnToday = function () {
  this.goToMillis(new Date().getTime());
};

/**
 * Allows drag and drop and extesion of task boxes. Only works on x axis
 * @param opt
 * @return {*}
 */
$.fn.dragExtedSVG = function (svg, opt) {
  //doing this can work with one svg at once only
  var target;
  var svgX;
  var offsetMouseRect;

  var options = {
    canDrag: true,
    canResize: true,
    resizeZoneWidth: 5,
    minSize: 10,
    startDrag: function (e) {},
    drag: function (e) {},
    drop: function (e) {},
    startResize: function (e) {},
    resize: function (e) {},
    stopResize: function (e) {},
  };

  $.extend(options, opt);

  this.each(function () {
    var el = $(this);
    svgX = svg.parent().offset().left; //parent is used instead of svg for a Firefox oddity
    if (options.canDrag) el.addClass("pluginGantt_deSVGdrag");

    if (options.canResize || options.canDrag) {
      el.bind("mousedown.deSVG", function (e) {
        //console.debug("mousedown.deSVG");
        if ($(e.target).is("image")) {
          e.preventDefault();
        }

        target = $(this);
        var x1 = parseFloat(el.find("[class*=pluginGantt_taskLayout]").offset().left);
        var x2 = x1 + parseFloat(el.attr("width"));
        var posx = e.pageX;

        $("body").unselectable();

        //start resize end
        if (options.canResize && Math.abs(posx - x2) <= options.resizeZoneWidth) {
          //store offset mouse x2
          offsetMouseRect = x2 - e.pageX;
          target.attr("oldw", target.attr("width"));
          var one = true;

          //bind event for start resizing
          $(svg).bind("mousemove.deSVG", function (e) {
            //hide link circle
            $("[class*=pluginGantt_linkHandleSVG]").hide();

            if (one) {
              //trigger startResize
              options.startResize.call(target.get(0), e);
              one = false;
            }

            //manage resizing
            var nW = e.pageX - x1 + offsetMouseRect;

            target.attr("width", nW < options.minSize ? options.minSize : nW);
            //callback
            options.resize.call(target.get(0), e);
          });

          //bind mouse up on body to stop resizing
          $("body").one("mouseup.deSVG", stopResize);

          //start resize start
        } else if (options.canResize && Math.abs(posx - x1) <= options.resizeZoneWidth) {
          //store offset mouse x1
          offsetMouseRect = parseFloat(target.attr("x"));
          target.attr("oldw", target.attr("width")); //todo controllare se è ancora usato oldw

          var one = true;

          //bind event for start resizing
          $(svg).bind("mousemove.deSVG", function (e) {
            //hide link circle
            $("[class*=pluginGantt_linkHandleSVG]").hide();

            if (one) {
              //trigger startResize
              options.startResize.call(target.get(0), e);
              one = false;
            }

            //manage resizing
            var nx1 = offsetMouseRect - (posx - e.pageX);
            var nW = x2 - x1 + (posx - e.pageX);
            nW = nW < options.minSize ? options.minSize : nW;
            target.attr("x", nx1);
            target.attr("width", nW);
            //callback
            options.resize.call(target.get(0), e);
          });

          //bind mouse up on body to stop resizing
          $("body").one("mouseup.deSVG", stopResize);

          // start drag
        } else if (options.canDrag) {
          //store offset mouse x1
          offsetMouseRect = parseFloat(target.attr("x")) - e.pageX;
          target.attr("oldx", target.attr("x"));

          var one = true;
          //bind event for start dragging
          $(svg)
            .bind("mousemove.deSVG", function (e) {
              //hide link circle
              $("[class*=pluginGantt_linkHandleSVG]").hide();
              if (one) {
                //trigger startDrag
                options.startDrag.call(target.get(0), e);
                one = false;
              }

              //manage resizing
              target.attr("x", offsetMouseRect + e.pageX);
              //callback
              options.drag.call(target.get(0), e);
            })
            .bind("mouseleave.deSVG", drop);

          //bind mouse up on body to stop resizing
          $("body").one("mouseup.deSVG", drop);
        }
      })
        .bind("mousemove.deSVG", function (e) {
          var el = $(this);
          var x1 = el.find("[class*=pluginGantt_taskLayout]").offset().left;
          var x2 = x1 + parseFloat(el.attr("width"));
          var posx = e.pageX;

          //set cursor handle
          //if (options.canResize && (x2-x1)>3*options.resizeZoneWidth &&((posx<=x2 &&  posx >= x2- options.resizeZoneWidth) || (posx>=x1 && posx<=x1+options.resizeZoneWidth))) {
          if (
            options.canResize &&
            (Math.abs(posx - x1) <= options.resizeZoneWidth || Math.abs(posx - x2) <= options.resizeZoneWidth)
          ) {
            el.addClass("pluginGantt_deSVGhand");
          } else {
            el.removeClass("pluginGantt_deSVGhand");
          }
        })
        .addClass("pluginGantt_deSVG");
    }
  });
  return this;
  
  function stopResize(e) {
    $(svg).unbind("mousemove.deSVG").unbind("mouseup.deSVG").unbind("mouseleave.deSVG");
    if (target && target.attr("oldw") != target.attr("width")) options.stopResize.call(target.get(0), e); //callback
    target = undefined;
    $("body").clearUnselectable();
  }

  function drop(e) {
    $(svg).unbind("mousemove.deSVG").unbind("mouseup.deSVG").unbind("mouseleave.deSVG");
    if (target && target.attr("oldx") != target.attr("x")) options.drop.call(target.get(0), e); //callback
    target = undefined;
    $("body").clearUnselectable();
  }
};
