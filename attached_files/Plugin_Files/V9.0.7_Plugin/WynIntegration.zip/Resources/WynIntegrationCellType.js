var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var WynIntegrationCellType;
(function (WynIntegrationCellType_1) {
    var WynIntegrationCellType = /** @class */ (function (_super) {
        __extends(WynIntegrationCellType, _super);
        function WynIntegrationCellType() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        WynIntegrationCellType.prototype.createContent = function () {
            var div = $("<div id=".concat(this.ID, "></div>"));
            div.css("height", "100%");
            div.append(this.getWynDiv());
            return div;
        };
        WynIntegrationCellType.prototype.onPageLoaded = function () {
            var _this = this;
            this.createDashboardViewer();
            this.onDependenceCellValueChanged(function () {
                _this.createDashboardViewer();
            });
        };
        WynIntegrationCellType.prototype.createDashboardViewer = function () {
            var visible = this.checkAuthority(1 /* Forguncy.Plugin.UIPermissionScope.Visible */);
            if (!visible) {
                return;
            }
            WynIntegrationHelper.createDashboardViewer(this.CellElement.ServerPropertiesId.ServerModel, "#".concat(this.ID, "_wyn"), this);
        };
        WynIntegrationCellType.prototype.getWynDiv = function () {
            var wynDiv = $("<div id=".concat(this.ID, "_wyn></div>"));
            wynDiv.css("height", "100%");
            wynDiv.css("white-space", "normal");
            return wynDiv;
        };
        return WynIntegrationCellType;
    }(Forguncy.Plugin.CellTypeBase));
    WynIntegrationCellType_1.WynIntegrationCellType = WynIntegrationCellType;
})(WynIntegrationCellType || (WynIntegrationCellType = {}));
var WynIntegrationHelper = /** @class */ (function () {
    function WynIntegrationHelper() {
    }
    WynIntegrationHelper.createDashboardViewer = function (serverModel, selector, cellType) {
        if (cellType) {
            //destroy old
            if (cellType.wynInstance) {
                cellType.wynInstance.destroy();
            }
        }
        var baseUrl = Forguncy.Helper.SpecialPath.getBaseUrl();
        var options = {};
        //var getWynDashboardOptionsInForguncy = function(cellType: WynIntegrationCellType.WynIntegrationCellType): { [key: string]: any } {
        //    return {
        //        theme: 'red'
        //    };
        //}
        if (window.getWynDashboardOptionsInForguncy) {
            options = window.getWynDashboardOptionsInForguncy(cellType);
        }
        options.baseUrl = "".concat(window.location.origin).concat(baseUrl, "2F6F06BD-09BF-49E5-B699-D4A303FC0DDE/").concat(serverModel, "/").concat(selector.substr(1));
        options.token = '';
        options.dashboardId = '99C74ECD-90B3-48B5-878E-6156CCA690F0';
        var metadata = cellType.CellElement.CellType;
        if (metadata && metadata.ParamList && metadata.ParamList.length > 0) {
            var dp = {};
            metadata.ParamList.forEach(function (p) {
                var val = null;
                if (p.ParamValue) {
                    val = cellType.evaluateFormula(p.ParamValue.toString());
                }
                dp[p.ParamName] = val;
            });
            options.dp = JSON.stringify(dp);
        }
        //TODO: katherine 临时提交，wyn destory之后dom被销毁了。
        if ($(selector).length === 0) {
            cellType.getContainer().find("div").append(cellType.getWynDiv());
        }
        window.WynIntegration.createViewerLite(options, selector).then(function (ins) {
            if (cellType) {
                cellType.wynInstance = ins;
            }
        }).catch(function (err) {
            console.log(err);
        });
    };
    return WynIntegrationHelper;
}());
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CellTypeHelper.registerCellType("WynIntegration.WynIntegrationCellType, WynIntegration", WynIntegrationCellType.WynIntegrationCellType);
