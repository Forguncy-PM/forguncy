var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var RFIDCommand;
(function (RFIDCommand) {
    var RFIDInventoryCommand = /** @class */ (function (_super) {
        __extends(RFIDInventoryCommand, _super);
        function RFIDInventoryCommand() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.resourceMap = {
                CN: {
                    ReactNativeError: "请使用ReactNative版本的手机客户端打开重试！",
                    CellLocationEmptyError: "目标单元格不能为空",
                    PortError: "必须指定串口号"
                },
                JA: {
                    ReactNativeError: "Please use the ReactNative version of the Forguncy mobile client to execute this command.",
                    CellLocationEmptyError: "Target cell cannot be empty",
                    PortError: "Port number must be specified"
                },
                KR: {
                    ReactNativeError: "Please use the ReactNative version of the Forguncy mobile client to execute this command.",
                    CellLocationEmptyError: "Target cell cannot be empty",
                    PortError: "Port number must be specified"
                },
                EN: {
                    ReactNativeError: "Please use the ReactNative version of the Forguncy mobile client to execute this command.",
                    CellLocationEmptyError: "Target cell cannot be empty",
                    PortError: "Port number must be specified"
                }
            };
            return _this;
        }
        RFIDInventoryCommand.prototype.execute = function () {
            if (!window.ReactNativeWebView) {
                alert(this.getResourceString("ReactNativeError"));
                return;
            }
            var params = this.CommandParam;
            var inventoryType = params.InventoryType;
            var targetCell = params.TargetCell ? this.getCellLocation(params.TargetCell) : null;
            if (targetCell === null && (inventoryType === "start" || inventoryType === "findPort")) {
                alert(this.getResourceString("CellLocationEmptyError"));
                return;
            }
            var port = this.evaluateFormula(params.Port);
            if (port === null && inventoryType === "connect") {
                alert(this.getResourceString("PortError"));
                return;
            }
            var cellLocation = targetCell ? JSON.stringify(targetCell) : "";
            var js = "\n                try {\n                    const command = new RFIDCommand.RFIDInventoryCommand();\n                    command.setResult('".concat(cellLocation, "', '@result');\n                } catch(e) {\n                    console.log(e)  \n                }\n                true;\n            ");
            var info = {
                type: "plugin",
                data: {
                    type: inventoryType,
                    params: {
                        Port: port,
                        Baud: Number(params.Baud),
                        FastMode: params.FastSwitch,
                        Duration: Number(params.Duration),
                        Session: params.Session,
                        Target: params.Target,
                        FastSwitch: params.FastSwitch,
                        EnablePhase: params.EnablePhase,
                        script: js
                    },
                    guid: "ae5466af-6bfa-48ac-ad11-cd840c5fa9e1"
                }
            };
            window.ReactNativeWebView.postMessage(JSON.stringify(info));
        };
        RFIDInventoryCommand.prototype.setResult = function (cellInfo, result) {
            var cellLocation = JSON.parse(cellInfo);
            document.activeElement.blur();
            Forguncy.Page.getCellByLocation(cellLocation).setValue(result);
        };
        RFIDInventoryCommand.prototype.getResourceString = function (key) {
            var culture; // CN, JA, KR or EN
            if (Forguncy && Forguncy.RS && Forguncy.RS.Culture) {
                culture = Forguncy.RS.Culture;
            }
            else {
                culture = "EN"; // default culture
            }
            if (this.resourceMap[culture]) {
                return this.resourceMap[culture][key];
            }
            return "";
        };
        return RFIDInventoryCommand;
    }(Forguncy.Plugin.CommandBase));
    RFIDCommand.RFIDInventoryCommand = RFIDInventoryCommand;
})(RFIDCommand || (RFIDCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("RFIDCommand.RfidCommand, RFIDCommand", RFIDCommand.RFIDInventoryCommand);
