﻿var WechatJSAPIPay = (function (_super) {
    __extends(WechatJSAPIPay, _super);

    function WechatJSAPIPay() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    WechatJSAPIPay.prototype.isJSON = function (str) {
        try {
            return (JSON.parse(str) && !!str);
        } catch (e) {
            return false;
        }
    }

    WechatJSAPIPay.prototype.onBridgeReady = function () {
        try {
            var param = this.CommandParam;
            var serverCommandName = this.evaluateFormula(param.ServerCommandName);
            var orderId = this.evaluateFormula(param.OrderId);
            var openid = this.evaluateFormula(param.OpenId);
            var body = this.evaluateFormula(param.Body);
            var attach = this.evaluateFormula(param.Attach);

            var orderInfo = {
                OpenId: openid,
                OrderId: orderId,
                Body: body,
                Attach: attach
            };
            var self = this;
            var jqXHR = $.post(Forguncy.ForguncyData.ForguncyRoot + "ServerCommand/" + serverCommandName, orderInfo, function (ret) {
                var retJSON;
                if (typeof ret === "string") {
                    var retIsJson = self.isJSON(ret);
                    if (retIsJson) {
                        retJSON = JSON.parse(ret);
                    } else {
                        self.setResult(1, ret);
                        return;
                    }
                } else {
                    retJSON = ret;
                }
                if (retJSON.ErrCode !== null && retJSON.ErrCode !== undefined && retJSON.ErrCode !== 0) {
                    self.setResult(retJSON.ErrCode, retJSON.Message);
                    return;
                }
                WeixinJSBridge.invoke(
                    'getBrandWCPayRequest', {
                        "appId": retJSON.appId,     //公众号名称，由商户传入     
                        "timeStamp": retJSON.timeStamp,         //时间戳，自1970年以来的秒数     
                        "nonceStr": retJSON.nonceStr, //随机串
                        "package": retJSON.package,
                        "signType": retJSON.signType,         //微信签名方式：     
                        "paySign": retJSON.paySign //微信签名 
                    },
                    function (res) {
                        if (res.err_msg === "get_brand_wcpay_request:ok") {
                            self.setResult(0, "SUCCESS");
                        } else {
                            self.setResult(1, res.err_msg);
                        }
                    }
                );
            });

            jqXHR.fail(function (xhr, errorText) {
                self.setResult(xhr.status, errorText);
            })
        } catch (e) {
            alert(e);
        }
    }

    WechatJSAPIPay.prototype.setResult = function (errorCode, message) {
        var param = this.CommandParam;
        var resultErrorCodeTo = param.ResultErrorCodeTo;
        if (resultErrorCodeTo) {
            var cellLocation = this.getCellLocation(resultErrorCodeTo);
            Forguncy.Page.getCellByLocation(cellLocation).setValue(errorCode);
        }
        var resultMessageTo = param.ResultMessageTo;
        if (resultMessageTo) {
            var resultMessageToLocation = this.getCellLocation(resultMessageTo);
            Forguncy.Page.getCellByLocation(resultMessageToLocation).setValue(message);
        }
        if (!resultErrorCodeTo && !resultMessageTo && errorCode !== 0) {
            alert(message);
        }
        this.CommandExecutingInfo.suspend = false;
    }

    WechatJSAPIPay.prototype.execute = function () {
        if (typeof WeixinJSBridge === "undefined") {
            if (document.addEventListener) {
                document.addEventListener('WeixinJSBridgeReady', this.onBridgeReady, false);
            } else if (document.attachEvent) {
                document.attachEvent('WeixinJSBridgeReady', this.onBridgeReady);
                document.attachEvent('onWeixinJSBridgeReady', this.onBridgeReady);
            }
        } else {
            this.onBridgeReady();
        }
        this.CommandExecutingInfo.suspend = true;
    }
    return WechatJSAPIPay;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("WechatPay.WechatJSAPIPay, WechatPay", WechatJSAPIPay);
