var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var FilePreviewer;
(function (FilePreviewer) {
    var EventDispatcher = /** @class */ (function () {
        function EventDispatcher() {
            this.events = new FilePreviewer.Events();
        }
        EventDispatcher.prototype.on = function (eventName, handler, force) {
            if (force === void 0) { force = true; }
            this.events.addHandler(eventName, handler, force);
        };
        EventDispatcher.prototype.off = function (eventName, handler) {
            this.events.removeHandler(eventName, handler);
        };
        EventDispatcher.prototype.dispatch = function (eventName) {
            var _a;
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            (_a = this.events).raiseEvent.apply(_a, __spreadArray([eventName], args, false));
        };
        EventDispatcher.prototype.dispose = function () {
            this.events.release();
        };
        return EventDispatcher;
    }());
    FilePreviewer.EventDispatcher = EventDispatcher;
})(FilePreviewer || (FilePreviewer = {}));
