var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PDACommand;
(function (PDACommand) {
    var PdaScanCommand = /** @class */ (function (_super) {
        __extends(PdaScanCommand, _super);
        function PdaScanCommand() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.resourceMap = {
                CN: {
                    ReactNativeError: "请使用ReactNative版本的手机客户端打开重试！",
                    CellLocationEmptyError: "目标单元格不能为空",
                    BroadcastError: "广播名称和键值名称需要同时配置"
                },
                JA: {
                    ReactNativeError: "Please use the ReactNative version of the Forguncy mobile client to execute this command.",
                    CellLocationEmptyError: "Target cell cannot be empty",
                    BroadcastError: "The broadcast action name and broadcast key name need to be configured at the same time"
                },
                KR: {
                    ReactNativeError: "Please use the ReactNative version of the Forguncy mobile client to execute this command.",
                    CellLocationEmptyError: "Target cell cannot be empty",
                    BroadcastError: "The broadcast action name and broadcast key name need to be configured at the same time"
                },
                EN: {
                    ReactNativeError: "Please use the ReactNative version of the Forguncy mobile client to execute this command.",
                    CellLocationEmptyError: "Target cell cannot be empty",
                    BroadcastError: "The broadcast action name and broadcast key name need to be configured at the same time"
                }
            };
            return _this;
        }
        PdaScanCommand.prototype.execute = function () {
            var _a;
            if (!window.ReactNativeWebView) {
                alert(this.getResourceString("ReactNativeError"));
                return;
            }
            var params = this.CommandParam;
            var scanType = params.ScanType;
            var targetCell = params.TargetCell ? this.getCellLocation(params.TargetCell) : null;
            if (targetCell === null && scanType !== "Stop") {
                alert(this.getResourceString("CellLocationEmptyError"));
                return;
            }
            if ((params.BroadcastActionName !== undefined && params.BroadcastKeyName === undefined) ||
                (params.BroadcastActionName === undefined && params.BroadcastKeyName !== undefined)) {
                alert(this.getResourceString("BroadcastError"));
                return;
            }
            var cellLocation = targetCell ? JSON.stringify(targetCell) : "";
            var js = "\n                try {\n                    const command = new PDACommand.PdaScanCommand();\n                    command.setScanResult('".concat(cellLocation, "', @result);\n                } catch(e) {\n                    console.log(e)\n                }\n                true;\n            ");
            var modalMode = (_a = params.SingleModalMode) !== null && _a !== void 0 ? _a : false;
            var scanInfo = {
                type: "plugin",
                data: {
                    scanType: scanType,
                    cellLocation: cellLocation,
                    modalMode: modalMode,
                    script: js,
                    broadcastActionName: params.BroadcastActionName,
                    broadcastKeyName: params.BroadcastKeyName,
                    guid: "850b33ec-2fab-4c4f-9de9-47ef0cae0bbe"
                }
            };
            window.ReactNativeWebView.postMessage(JSON.stringify(scanInfo));
        };
        PdaScanCommand.prototype.setScanResult = function (cellInfo, barCode) {
            var cellLocation = JSON.parse(cellInfo);
            document.activeElement.blur();
            Forguncy.Page.getCellByLocation(cellLocation).setValue(barCode);
        };
        PdaScanCommand.prototype.getResourceString = function (key) {
            var culture; // CN, JA, KR or EN
            if (Forguncy && Forguncy.RS && Forguncy.RS.Culture) {
                culture = Forguncy.RS.Culture;
            }
            else {
                culture = "EN"; // default culture
            }
            if (this.resourceMap[culture]) {
                return this.resourceMap[culture][key];
            }
            return "";
        };
        return PdaScanCommand;
    }(Forguncy.Plugin.CommandBase));
    PDACommand.PdaScanCommand = PdaScanCommand;
})(PDACommand || (PDACommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("PDACommand.PdaScanCommand, PDACommand", PDACommand.PdaScanCommand);
