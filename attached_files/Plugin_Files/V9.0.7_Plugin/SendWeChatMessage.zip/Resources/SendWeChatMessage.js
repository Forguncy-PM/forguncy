var SendWeChatMessage = (function (_super) {
    __extends(SendWeChatMessage, _super);
    function SendWeChatMessage() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    SendWeChatMessage.prototype.execute = function () {
        // Get setings
        var commandSettings = this.CommandParam;
        var userId = commandSettings.UserId;
        var partyId = commandSettings.PartyId;
        var content = commandSettings.Content;
        var showError = commandSettings.ShowErrorMessage;
        var successMessage = commandSettings.SuccessMessage;

        var userId = this.evaluateFormula(userId);
        var partyId = this.evaluateFormula(partyId);
        var content = this.evaluateFormula(content);
        var successMessage = this.evaluateFormula(successMessage);

        Forguncy.Helper.post("customApi/wechat/sendTextMessage", JSON.stringify({ userId: userId, partyId: partyId, content: content }), function (message) {
            if (message)
            {
                if (showError)
                {
                    alert(message);
                }
            }
            else
            {
                if (successMessage)
                {
                    alert(successMessage);
                }
            }
        });
    }

    return SendWeChatMessage;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("SendWeChatMessage.SendWeChatMessage, SendWeChatMessage", SendWeChatMessage);