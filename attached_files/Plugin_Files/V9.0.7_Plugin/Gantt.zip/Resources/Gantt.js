var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Gantt;
(function (Gantt) {
    var GanttCellType = /** @class */ (function (_super) {
        __extends(GanttCellType, _super);
        function GanttCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._selectedRow = 0;
            _this._isListViewChanging = false;
            _this._isCalendarHolidaysLoaded = false;
            return _this;
        }
        GanttCellType.prototype.createContent = function () {
            // write inline height and witdh will avoid size initialization error
            var container = $("<div id=\"".concat(this.ID, "\" style='height: 100%; width: 100%;'></div>"));
            this._container = container;
            return container;
        };
        GanttCellType.prototype.getGanttData = function (tasks) {
            var result = {
                "tasks": [],
                "selectedRow": 0,
                "deletedTaskIds": [],
                "resources": [
                    { "id": "tmp_1", "name": "Resource 1" },
                    { "id": "tmp_2", "name": "Resource 2" },
                    { "id": "tmp_3", "name": "Resource 3" },
                    { "id": "tmp_4", "name": "Resource 4" }
                ],
                "roles": [
                    { "id": "tmp_1", "name": "Project Manager" },
                    { "id": "tmp_2", "name": "Worker" },
                    { "id": "tmp_3", "name": "Stakeholder" },
                    { "id": "tmp_4", "name": "Customer" }
                ],
                "zoom": "1M",
                "canWrite": true,
                "canAdd": true,
                "canWriteOnParent": true,
                "cannotCloseTaskIfIssueOpen": false,
                "canAddIssue": false,
                "canDelete": true
            };
            // if the bool attribute value is false, this arttribute willn't be passed in.
            var canEdit = this._ganttPermission;
            // 权限控制，默认传入的并不是完全敲定，更主要的是 task 内的 canAdd 等。目前仅设置一个全局控制可编辑
            result.canWrite = canEdit;
            result.canAdd = canEdit;
            result.canWriteOnParent = canEdit;
            result.canDelete = canEdit;
            // 一张表通过 project_id 区分切换多个甘特图项目
            // _selectedRow 就可能 index out of range
            if (tasks.length > this._selectedRow) {
                result.selectedRow = this._selectedRow;
            }
            else {
                this._selectedRow = 0;
            }
            tasks.forEach(function (task) {
                task.canWrite = canEdit;
                task.canAdd = canEdit;
                task.canDelete = canEdit;
                task.canAddIssue = canEdit;
            });
            result.tasks = tasks;
            return result;
        };
        GanttCellType.prototype.onLoad = function () {
            this.initializeProperties();
        };
        GanttCellType.prototype.initializeProperties = function () {
            var _this = this;
            var GanttCellTypeData = this.CellElement.CellType;
            this._metadata = GanttCellTypeData;
            this._ganttListViewInfo = this._metadata.GanttListViewInfo;
            this._listViewName = this._ganttListViewInfo.ListViewName;
            this._ganttTaskSetColInfo = this._ganttListViewInfo.GanttTaskSetColInfo;
            // @ts-ignore
            this._listViewBase = Forguncy.ListviewBase.getListview(this._listViewName, this.runTimePageName);
            this._listView = Forguncy.Page.getListView(this._listViewName, true);
            this._listView.bind(Forguncy.ListViewEvents.Reloaded, function () {
                _this.refresh();
            });
            this.updateGanttPermission();
            // Set Gantt
            if (this._ganttObj == null) {
                // here starts gantt initialization
                this._ganttObj = new GanttMaster();
                // style settings
                var showButtonBar = this._metadata.hasOwnProperty("ShowButtonBar") ? this._metadata.ShowButtonBar : false;
                var initialCalculationMode = this._metadata.hasOwnProperty("InitialCalculationMode") ? this._metadata.InitialCalculationMode : InitialCalculationModeModel.UseStartAndDuration;
                this._ganttObj.styleSettings = {
                    showButtonBar: showButtonBar
                };
                this._ganttObj.initialCalculationMode = initialCalculationMode;
                this._ganttObj.set100OnClose = true;
                this._ganttObj.shrinkParent = true;
                this._ganttObj.resourceUrl = this.getResourceUrl();
                this._ganttObj.hasSetCommands = this._metadata.TaskCommandList ? this._metadata.TaskCommandList.length > 0 : false;
                this._ganttObj.hasSetStatusCol = this._ganttTaskSetColInfo.StatusCol ? true : false;
                this._ganttObj.ganttTaskSetColInfo = this._metadata.GanttListViewInfo.GanttTaskSetColInfo;
                this._ganttObj.setCalendarHolidays([]);
                if (this._metadata.CustomHoliday && this._metadata.HolidayInfo) {
                    this.getBindingDataSourceValue(this._metadata.HolidayInfo, {
                        distinct: true
                    }, function (rowsData) {
                        var holidays = rowsData.map(function (row) {
                            var date = row["date"];
                            var isHoliday = row["isHoliday"];
                            var holiday = {
                                // TODO: why there write row.date or row.isHoliday, then value will undefined?
                                date: GanttCalendarConvert.formatHolidayValueFromTableToGanttChart(date, 'date'),
                                isHoliday: GanttCalendarConvert.formatHolidayValueFromTableToGanttChart(isHoliday, 'isHoliday')
                            };
                            return holiday;
                        });
                        _this._ganttObj.setCalendarHolidays(holidays);
                        _this._isCalendarHolidaysLoaded = true;
                    });
                }
                else {
                    this._isCalendarHolidaysLoaded = true;
                }
                this._ganttObj.init(this._container);
                /* <Modify the source code> */
                /*
                 * The default setting is month mode
                 *
                 * <Origin Code>
                 * //in order to force compute the best-fitting zoom level
                 * delete this._ganttObj.gantt.zoom;
                 * </Origin Code>
                 */
                // delete this._ganttObj.gantt.zoom;
                /* </Modify the source code> */
                this._ganttObj.checkpoint();
                this._ganttObj.bindTaskRowClickEvent = function (task) {
                    var rowIndex = ListViewHelper.getRowIndex(_this._listView, _this._ganttTaskSetColInfo.IdCol, task.id);
                    if (!Utilities.isEmpty(rowIndex) && rowIndex >= 0) {
                        _this._listView.selectRow(rowIndex);
                        // rowIndex 是在表中的当前行，和 listview 交互
                        // 而 _selectedRow 是甘特图列表中的当前行，与 rowIndex 并不等价，基于 task.order 取值即可
                        _this._selectedRow = task.order - 1;
                    }
                };
                this._ganttObj.bindTaskRowDblClickEvent = function (task) {
                    var taskCommandList = GanttCellTypeData.TaskCommandList;
                    _this.executeCommand(taskCommandList);
                };
                this._ganttObj.bindSaveGanttDataEvent = function (task) {
                    _this._isListViewChanging = true;
                    _this.saveGanttDataToListView();
                    // TODO: 更好的解决方法： {ConcurrentError: true, Message: "更新数据库失败!↵表格中有一条或多条记录已被他人更改。"}， 绑定命令会成功
                    // @ts-ignore
                    Forguncy.UpdateListviewCommand.updateListview(_this._listViewBase, function () {
                        Forguncy.NormalCellBindingManager.reloadData(_this._listViewBase.getDataTableName(), true);
                        Forguncy.ForguncyData.getRelatedTableWithForeignKey(_this._listViewBase.getDataTableName()).forEach(function (table) {
                            Forguncy.NormalCellBindingManager.reloadData(table, true);
                        });
                        _this._isListViewChanging = false;
                    });
                };
                // Original code: Is to get data from remote
                // initializeHistoryManagement(ge.tasks[0].id);
                this._ganttObj.loadProject(this.getGanttData([{
                        // @ts-ignore
                        id: "tmp_fk" + new Date().getTime(),
                        order: 0,
                        level: 0,
                        name: Forguncy.RS.Culture === "CN" /* Forguncy.ForguncySupportCultures.Chinese */ ? '加载数据中，请等待···' : 'loading data, please waiting···',
                        depends: "",
                        // @ts-ignore
                        start: Date.now(),
                        // @ts-ignore
                        end: Date.now(),
                        duration: 1,
                        progress: 0,
                        description: "",
                        code: "",
                        startIsMilestone: false,
                        endIsMilestone: false,
                        collapsed: false,
                        status: "STATUS_UNDEFINED",
                        assigs: "",
                    }]));
            }
        };
        GanttCellType.prototype.refresh = function () {
            var _this = this;
            if (this._isCalendarHolidaysLoaded && !this._isListViewChanging) {
                this._loadDataToGanttData();
            }
            else {
                setTimeout(function () {
                    _this.refresh();
                }, 100);
            }
        };
        GanttCellType.prototype._loadDataToGanttData = function () {
            var tasks = GanttTaskConvert.getTasksFromListViewToGanttChart(this._listView, this._ganttListViewInfo);
            var project = this.getGanttData(tasks);
            this._ganttObj.loadProject(project);
        };
        GanttCellType.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this.onIsDisabledChanged();
        };
        GanttCellType.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this.onIsDisabledChanged();
        };
        GanttCellType.prototype.onIsDisabledChanged = function () {
            var className = "pluginGantt_disable";
            if (this.isDisabled()) {
                this._container.addClass(className);
            }
            else {
                this._container.removeClass(className);
            }
        };
        GanttCellType.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this.updateGanttPermission();
        };
        GanttCellType.prototype.updateGanttPermission = function () {
            this._ganttPermission = !this.isDisabled() && !this.isReadOnly();
            if (!this._ganttObj) {
                return;
            }
            this._ganttObj.loadProjectPermissions(this._ganttPermission);
        };
        GanttCellType.prototype.saveGanttDataToListView = function () {
            var ganttData = this._ganttObj.saveProject();
            var oldTasks = GanttTaskConvert.getTasksFromListViewToGanttChart(this._listView, this._ganttListViewInfo);
            var newTasks = GanttTaskConvert.getTasksFromGanttChartToListView(ganttData, this._ganttListViewInfo);
            var editRows = [];
            var addRows = [];
            var deleteRows = [];
            // judge type
            var defaultIdCol = GanttTaskConvert.GanntTaskRequiredColInfo.IdCol;
            var oldTaskIds = oldTasks.map(function (oldTask) { return oldTask[defaultIdCol]; });
            var setIdCol = this._ganttTaskSetColInfo.IdCol;
            var newTaskIds = newTasks.map(function (newTask) { return newTask[setIdCol]; });
            newTasks.forEach(function (newTask) {
                var idValue = newTask[setIdCol];
                var isAdd = oldTaskIds.indexOf(idValue) === -1;
                if (isAdd) {
                    newTask.id = undefined;
                    addRows.push(newTask);
                }
                else {
                    editRows.push({
                        primaryKey: {
                            idCol: setIdCol,
                            idValue: idValue
                        },
                        values: newTask
                    });
                }
            });
            oldTasks.forEach(function (oldTask) {
                var idValue = oldTask[defaultIdCol];
                var isDelete = newTaskIds.indexOf(idValue) === -1;
                if (isDelete) {
                    deleteRows.push({
                        idCol: setIdCol,
                        idValue: idValue
                    });
                }
            });
            // modifyTablesData
            var ModifyData = {
                editRows: editRows,
                addRows: addRows,
                deleteRows: deleteRows
            };
            ListViewHelper.modifyRows(this._listView, ModifyData);
        };
        GanttCellType.prototype.getResourceUrl = function () {
            // compatible ie, new Error() no stack.
            try {
                throw new Error();
            }
            catch (resourceUrlError) {
                var stack = resourceUrlError.stack || '';
                var rgx = /(?:http|https|file):\/\/.*?\/.+?.js/;
                var pluginURL = (rgx.exec(stack) || [])[0] || '';
                var pluginBase = pluginURL.split("/").slice(3, -1).join("/");
                var resourceUrl = "/" + pluginBase + "/robicch-jQueryGantt/";
                return resourceUrl;
            }
        };
        return GanttCellType;
    }(Forguncy.Plugin.CellTypeBase));
    Gantt.GanttCellType = GanttCellType;
    var GanttTaskConvert = /** @class */ (function () {
        function GanttTaskConvert() {
        }
        GanttTaskConvert.getTasksFromListViewToGanttChart = function (listView, ganttListViewInfo) {
            var _this = this;
            var rowsData = this.getRowsData(listView);
            var mergedColumnInfos = listView.getMergedColumnInfos();
            var columnNameWithIndex = this.getColumnNameWithIndex(mergedColumnInfos);
            var tasks = rowsData.map(function (row) {
                var values = row.Values;
                var task = _this.creatTaskFromListViewToGanttChart(values, columnNameWithIndex, ganttListViewInfo);
                return task;
            });
            tasks.sort(function (a, b) {
                return (a.order - b.order);
            });
            return tasks;
        };
        GanttTaskConvert.getTasksFromGanttChartToListView = function (ganttData, ganttListViewInfo) {
            var _this = this;
            var newTasks = ganttData.tasks;
            newTasks.forEach(function (task, index) {
                task.order = index + 1;
            });
            var tasks = newTasks.map(function (oldTask) {
                var task = _this.creatTaskFromGanttChartToListView(oldTask, ganttListViewInfo);
                return task;
            });
            return tasks;
        };
        GanttTaskConvert.creatTaskFromListViewToGanttChart = function (values, columnNameWithIndex, ganttListViewInfo) {
            var _this = this;
            var ganttTaskSetColInfo = ganttListViewInfo.GanttTaskSetColInfo;
            var task = {};
            // required
            Object.keys(this.GanntTaskRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                var defaultColName = _this.GanntTaskRequiredColInfo[col];
                var index = columnNameWithIndex[setColName];
                var value = values[index];
                task[defaultColName] = _this.formatTaskValueFromListViewToGanttChart(value, col, ganttListViewInfo);
            }));
            // not required
            Object.keys(this.GanntTaskNotRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                if (!Utilities.isEmpty(setColName)) {
                    var defaultColName = _this.GanntTaskNotRequiredColInfo[col];
                    var index = columnNameWithIndex[setColName];
                    var value = values[index];
                    task[defaultColName] = _this.formatTaskValueFromListViewToGanttChart(value, col, ganttListViewInfo);
                }
            }));
            // set collapsed by level
            this.setTaskCollapsedFromListViewToGanttChart(task, ganttListViewInfo, ganttTaskSetColInfo);
            return task;
        };
        GanttTaskConvert.creatTaskFromGanttChartToListView = function (tasks, ganttListViewInfo) {
            var _this = this;
            var ganttTaskSetColInfo = ganttListViewInfo.GanttTaskSetColInfo;
            var task = {};
            // required
            Object.keys(this.GanntTaskRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                var defaultColName = _this.GanntTaskRequiredColInfo[col];
                var value = tasks[defaultColName];
                task[setColName] = _this.formatTaskValueFromGanttChartToListView(value, col, ganttListViewInfo);
            }));
            // not required
            Object.keys(this.GanntTaskNotRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                if (!Utilities.isEmpty(setColName)) {
                    var defaultColName = _this.GanntTaskNotRequiredColInfo[col];
                    var value = tasks[defaultColName];
                    task[setColName] = _this.formatTaskValueFromGanttChartToListView(value, col, ganttListViewInfo);
                }
            }));
            return task;
        };
        GanttTaskConvert.getRowsData = function (listView) {
            var rowsData = [];
            var rowCount = listView.getRowCount();
            if (rowCount === 0) {
                return [];
            }
            var columnInfos = listView.getMergedColumnInfos();
            var mergedColumnCount = columnInfos.length;
            for (var rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                var values = [];
                for (var colIndex = 0; colIndex < mergedColumnCount; colIndex++) {
                    var value = listView.getValue(rowIndex, colIndex);
                    values.push(Utilities.isEmpty(value) ? null : value);
                }
                rowsData.push({
                    RowIndex: rowIndex,
                    Values: values
                });
            }
            return rowsData;
        };
        GanttTaskConvert.getColumnNameWithIndex = function (mergedColumnInfos) {
            var columnNamesWithIndex = {};
            for (var i = 0; i < mergedColumnInfos.length; i++) {
                var columnName = mergedColumnInfos[i].ColumnName;
                if (Utilities.isEmpty(columnName)) {
                    continue;
                }
                columnNamesWithIndex[columnName] = i;
            }
            return columnNamesWithIndex;
        };
        GanttTaskConvert.formatTaskValueFromListViewToGanttChart = function (value, defaultColName, ganttListViewInfo) {
            switch (defaultColName) {
                case "IdCol": return value;
                case "OrderCol": return parseInt(value);
                case "LevelCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "NameCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "DependsCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "StartCol": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "EndCol": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "DurationCol": return Utilities.isEmpty(value) ? 2 : parseInt(value);
                case "ProgressCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "DescriptionCol": return Utilities.isEmpty(value) ? "" : value;
                case "CodeCol": return Utilities.isEmpty(value) ? "" : value;
                case "StartIsMilestoneCol": return Boolean(value);
                case "EndIsMilestoneCol": return Boolean(value);
                case "ActualStartCol": return Utilities.isEmpty(value) ? null : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "ActualEndCol": return Utilities.isEmpty(value) ? null : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "ActualDurationCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "AssigsCol": return Utilities.isEmpty(value) ? "" : value;
                case "CollapsedCol": return Boolean(value);
                case "StatusCol": return Utilities.isEmpty(value) || Utilities.isEmpty(ganttListViewInfo.GanttStatusSetInfo) ? "" : this.formatTaskStatusValueFromListViewToGanttChart(value, ganttListViewInfo.GanttStatusSetInfo);
                case "CanWriteCol": return Boolean(value);
                case "CanAddCol": return Boolean(value);
                case "CanDeleteCol": return Boolean(value);
                case "CanAddIssueCol": return Boolean(value);
                default: return value;
            }
        };
        GanttTaskConvert.formatTaskValueFromGanttChartToListView = function (value, defaultColName, ganttListViewInfo) {
            switch (defaultColName) {
                case "IdCol": return value;
                case "OrderCol": return parseInt(value);
                case "LevelCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "NameCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "DependsCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "StartCol":
                case "EndCol": {
                    var d = Utilities.isEmpty(value) ? new Date() : new Date(value);
                    d.setHours(0, 0, 0, 0);
                    return Forguncy.ConvertDateToOADate(d);
                }
                case "DurationCol": return Utilities.isEmpty(value) ? 2 : parseInt(value);
                case "ProgressCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "DescriptionCol": return Utilities.isEmpty(value) ? "" : value;
                case "CodeCol": return Utilities.isEmpty(value) ? "" : value;
                case "StartIsMilestoneCol": return Boolean(value);
                case "EndIsMilestoneCol": return Boolean(value);
                case "ActualStartCol": return Utilities.isEmpty(value) ? undefined : Forguncy.ConvertDateToOADate(new Date(value));
                case "ActualEndCol": {
                    if (Utilities.isEmpty(value)) {
                        return undefined;
                    }
                    else {
                        var d = new Date(value);
                        // 甘特图的开始时间，结束时间和实际开始时间，实际结束时间的绘图不正确.
                        // FORGUNCY-12153 [Runtime AT]Actualend result is incorrect in gantt.
                        d.setHours(0, 0, 0, 0);
                        return Forguncy.ConvertDateToOADate(d);
                    }
                }
                case "ActualDurationCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "AssigsCol": return Utilities.isEmpty(value) ? "" : value;
                case "CollapsedCol": return Boolean(value);
                case "StatusCol": return Utilities.isEmpty(value) || Utilities.isEmpty(ganttListViewInfo.GanttStatusSetInfo) ? "" : this.formatTaskStatusValueFromGanttChartToListView(value, ganttListViewInfo.GanttStatusSetInfo);
                case "CanWriteCol": return Boolean(value);
                case "CanAddCol": return Boolean(value);
                case "CanDeleteCol": return Boolean(value);
                case "CanAddIssueCol": return Boolean(value);
                default: return value;
            }
        };
        GanttTaskConvert.formatTaskStatusValueFromListViewToGanttChart = function (value, ganttStatusSetInfo) {
            var setInfo = Object.keys(ganttStatusSetInfo);
            for (var i = 0; i < setInfo.length; i++) {
                var key = setInfo[i];
                var setValue = ganttStatusSetInfo[key];
                if (setValue === value) {
                    var defaultValue = this.GanntStatusDefaultInfo[key];
                    return defaultValue;
                }
            }
        };
        GanttTaskConvert.formatTaskStatusValueFromGanttChartToListView = function (value, ganttStatusSetInfo) {
            var defaultInfo = Object.keys(this.GanntStatusDefaultInfo);
            for (var i = 0; i < defaultInfo.length; i++) {
                var key = defaultInfo[i];
                var defaultValue = this.GanntStatusDefaultInfo[key];
                if (defaultValue === value) {
                    var setValue = ganttStatusSetInfo[key];
                    return setValue;
                }
            }
        };
        GanttTaskConvert.setTaskCollapsedFromListViewToGanttChart = function (task, ganttListViewInfo, ganttTaskSetColInfo) {
            var ganttCollapsedSetLevel = ganttListViewInfo.GanttCollapsedSetLevel;
            var setCollapsedColName = ganttTaskSetColInfo.CollapsedCol;
            var defaultCollapsedColName = this.GanntTaskNotRequiredColInfo.CollapsedCol;
            if (Utilities.isEmpty(setCollapsedColName) && ganttCollapsedSetLevel > -1) {
                // if the task level is greater than the collapse setting, then collapse
                task[defaultCollapsedColName] = task.level >= ganttCollapsedSetLevel;
            }
        };
        GanttTaskConvert.GanntTaskRequiredColInfo = {
            IdCol: "id",
            OrderCol: "order",
            LevelCol: "level",
            NameCol: "name",
            DependsCol: "depends",
            StartCol: "start",
            EndCol: "end",
            DurationCol: "duration"
        };
        GanttTaskConvert.GanntTaskNotRequiredColInfo = {
            DescriptionCol: "description",
            CodeCol: "code",
            ProgressCol: "progress",
            StartIsMilestoneCol: "startIsMilestone",
            EndIsMilestoneCol: "endIsMilestone",
            ActualStartCol: "actualStart",
            ActualEndCol: "actualEnd",
            ActualDurationCol: "actualDuration",
            AssigsCol: "assigs",
            CollapsedCol: "collapsed",
            StatusCol: "status",
            CanWriteCol: "canWirte",
            CanAddCol: "canAdd",
            CanDeleteCol: "canDelete",
            CanAddIssueCol: "canAdd",
        };
        GanttTaskConvert.GanntStatusDefaultInfo = {
            WaitingCol: "STATUS_WAITING",
            ActiveCol: "STATUS_ACTIVE",
            CompletedCol: "STATUS_DONE",
            SuspendedCol: "STATUS_SUSPENDED",
            FailedCol: "STATUS_FAILED"
        };
        return GanttTaskConvert;
    }());
    var GanttCalendarConvert = /** @class */ (function () {
        function GanttCalendarConvert() {
        }
        GanttCalendarConvert.getColumnsFromColInfo = function (setColInfo) {
            return Object.keys(this.GanntCalendarColInfo).map(function (col) {
                return setColInfo[col];
            });
        };
        GanttCalendarConvert.formatHolidayValueFromTableToGanttChart = function (value, defaultColName) {
            switch (defaultColName) {
                case "date": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "isHoliday": return Boolean(value);
                default: return value;
            }
        };
        GanttCalendarConvert.GanntCalendarColInfo = {
            DateCol: "date",
            IsHolidayCol: "isHoliday"
        };
        return GanttCalendarConvert;
    }());
    var ListViewHelper = /** @class */ (function () {
        function ListViewHelper() {
        }
        ListViewHelper.getRowIndex = function (listView, idCol, idValue) {
            var count = listView.getRowCount();
            for (var rowIndex = 0; rowIndex < count; rowIndex++) {
                if (listView.getValue(rowIndex, idCol) == idValue) {
                    return rowIndex;
                }
            }
        };
        ListViewHelper.addRows = function (listView, rows) {
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                listView.addNewRow(row);
            });
        };
        ListViewHelper.editRows = function (listView, rows) {
            var _this = this;
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                var primaryKey = row.primaryKey, values = row.values;
                var idCol = primaryKey.idCol, idValue = primaryKey.idValue;
                var rowIndex = _this.getRowIndex(listView, idCol, idValue);
                Object.keys(values).forEach(function (col) {
                    var value = values[col];
                    listView.setValue(rowIndex, col, value);
                });
            });
        };
        ListViewHelper.deleteRows = function (listView, rows) {
            var _this = this;
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                var idCol = row.idCol, idValue = row.idValue;
                var rowIndex = _this.getRowIndex(listView, idCol, idValue);
                listView.deleteRow(rowIndex);
            });
        };
        ListViewHelper.modifyRows = function (listView, modifyData) {
            var addRows = modifyData.addRows, editRows = modifyData.editRows, deleteRows = modifyData.deleteRows;
            this.addRows(listView, addRows);
            this.editRows(listView, editRows);
            this.deleteRows(listView, deleteRows);
        };
        return ListViewHelper;
    }());
    var Utilities = /** @class */ (function () {
        function Utilities() {
        }
        Utilities.isEmpty = function (value) {
            return value === null || value === undefined || value === "";
        };
        return Utilities;
    }());
})(Gantt || (Gantt = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CellTypeHelper.registerCellType("Gantt.GanttCellType, Gantt", Gantt.GanttCellType);
