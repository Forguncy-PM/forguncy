﻿var WechatJSAPIPay = (function (_super) {
    __extends(WechatJSAPIPay, _super);
    function WechatJSAPIPay() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    WechatJSAPIPay.prototype.onBridgeReady = function () {
        try {
            var param = this.CommandParam;
            var serverCommandName = param.ServerCommandName;
            serverCommandName = this.evaluateFormula(serverCommandName);

            var orderId = param.OrderId;
            orderId = this.evaluateFormula(orderId);

            var openid = param.OpenId;
            openid = this.evaluateFormula(openid);

            var orderInfo = {
                OpenId: openid,
                OrderId: orderId
            };
            var self = this;
            var jqXHR = $.post(Forguncy.ForguncyData.ForguncyRoot + "ServerCommand/" + serverCommandName, orderInfo, function (ret) {
                var retJSON = JSON.parse(ret);
                WeixinJSBridge.invoke(
                    'getBrandWCPayRequest', {
                    "appId": retJSON.appId,     //公众号名称，由商户传入     
                    "timeStamp": retJSON.timestamp,         //时间戳，自1970年以来的秒数     
                    "nonceStr": retJSON.nonce_str, //随机串
                    "package": "prepay_id=" + retJSON.prepay_id,
                    "signType": "MD5",         //微信签名方式：     
                    "paySign": retJSON.paySign //微信签名 
                },
                    function (res) {
                        if (res.err_msg === "get_brand_wcpay_request:ok") {
                            self.setResult(0, "SUCCESS");
                        }
                        else {
                            self.setResult(res.err_code, res.err_msg);
                        }
                        self.CommandExecutingInfo.suspend = false;
                    }
                );
            });

            jqXHR.fail(function (xhr, errorText) { self.setResult(xhr.status, errorText); })
        } catch (e) {
            alert(e);
        }
    }

    WechatJSAPIPay.prototype.setResult = function (errorCode, message) {
        var param = this.CommandParam;
        var resultErrorCodeTo = param.ResultErrorCodeTo;
        if (resultErrorCodeTo) {
            var cellLocation = this.getCellLocation(resultErrorCodeTo);
            Forguncy.Page.getCellByLocation(cellLocation).setValue(errorCode);
        }
        var resultMessageTo = param.ResultMessageTo;
        if (resultMessageTo) {
            var resultMessageToLocation = this.getCellLocation(resultMessageTo);
            Forguncy.Page.getCellByLocation(resultMessageToLocation).setValue(message);
        }
    }

    WechatJSAPIPay.prototype.execute = function () {
        if (typeof WeixinJSBridge === "undefined") {
            if (document.addEventListener) {
                document.addEventListener('WeixinJSBridgeReady', this.onBridgeReady, false);
            } else if (document.attachEvent) {
                document.attachEvent('WeixinJSBridgeReady', this.onBridgeReady);
                document.attachEvent('onWeixinJSBridgeReady', this.onBridgeReady);
            }
        } else {
            this.onBridgeReady();
        }
        this.CommandExecutingInfo.suspend = true;
    }
    return WechatJSAPIPay;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("WechatPay.WechatJSAPIPay, WechatPay", WechatJSAPIPay);
