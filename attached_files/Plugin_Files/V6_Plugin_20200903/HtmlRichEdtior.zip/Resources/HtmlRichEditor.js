var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var HtmlRichEditor;
    (function (HtmlRichEditor_1) {
        var currentScriptSrc = document.scripts[document.scripts.length - 1].src;
        var paths = currentScriptSrc.split("/");
        var pluginBase = paths.slice(0, -2).join("/");
        var lang;
        if ($("script[src*=\"/summernote/lang/\"]").length === 0) {
            if (Forguncy.RS.Culture === "CN" /* Chinese */) {
                lang = 'zh-CN';
            }
            else if (Forguncy.RS.Culture === "KR" /* Korean */) {
                lang = 'ko-KR';
            }
            else if (Forguncy.RS.Culture === "JA" /* Japanese */) {
                lang = 'ja-JP';
            }
            var langSrc = pluginBase + "/Resources/summernote/lang/summernote-" + lang + ".js";
            $("head").append("<script src=\"" + langSrc + "\"/>");
            var cssSrc = pluginBase + "/Resources/summernote/summernote-lite.css";
            var link = document.createElement('link');
            link.rel = "stylesheet";
            link.type = "text/css";
            link.href = cssSrc;
            document.head.appendChild(link);
        }
        var HtmlRichEditor = /** @class */ (function (_super) {
            __extends(HtmlRichEditor, _super);
            function HtmlRichEditor() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this._enabled = true;
                _this._readOnly = false;
                return _this;
            }
            HtmlRichEditor.prototype.createContent = function () {
                var container = $("<div class=\"FGCHtmlRichEditor\" style=\"height:100%\"></div>");
                var hiddenDom = $("<div id=" + (this.ID + "_" + this["_pageID"]) + " style=\"display:none;\"></div>");
                container.append(hiddenDom);
                return container;
            };
            HtmlRichEditor.prototype.editor = function () {
                return $("#" + this.ID + "_" + this["_pageID"]);
            };
            HtmlRichEditor.prototype.getValueFromElement = function () {
                if (this._destroyed) {
                    return;
                }
                return this.editor().summernote('code');
            };
            HtmlRichEditor.prototype.setValueToElement = function (element, value) {
                if (this._destroyed) {
                    return;
                }
                var currentValue = this.editor().summernote('code');
                if (currentValue == value) {
                    return;
                }
                this.editor().summernote('code', value);
            };
            HtmlRichEditor.prototype.hasFocus = function () {
                return this._hasFocus;
            };
            HtmlRichEditor.prototype.setFocus = function () {
                if (this._readOnly) {
                    return;
                }
                this.editor().summernote("focus");
            };
            HtmlRichEditor.prototype.disable = function () {
                _super.prototype.disable.call(this);
                this._enabled = false;
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.enable = function () {
                _super.prototype.enable.call(this);
                this._enabled = true;
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.setReadOnly = function (value) {
                _super.prototype.setReadOnly.call(this, value);
                this._readOnly = value;
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.updateEditorMode = function () {
                var editor = this.editor();
                if (!editor) {
                    return;
                }
                var mode = this._enabled && !this._readOnly ? 'enable' : 'disable';
                editor.summernote(mode);
            };
            HtmlRichEditor.prototype.destroy = function () {
                this._destroyed = true;
                this.editor().summernote('destroy');
            };
            HtmlRichEditor.prototype.onLoad = function () {
                var _this = this;
                var cellTypeMetadata = this.CellElement.CellType;
                var showToolBars = cellTypeMetadata.ShowToolBars;
                this.editor().summernote({
                    lang: lang,
                    toolbar: [
                        ['operation', ['undo', 'redo',]],
                        ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript',]],
                        ['fontname', ['fontname', 'fontsize']],
                        ['color', ['color', 'clear',]],
                        ['Paragraph style', ['style', 'ul', 'ol', 'paragraph', 'height']],
                        ['insert', ['hr', 'link', 'picture', 'video', 'table',]],
                        ['view', ['codeview', 'help',]]
                    ],
                    fontSizes: ['8', '9', '10', '11', '12', '14', '16', '18', '24', '36'],
                    popover: this._enabled && !this._readOnly ? {
                        image: [
                            ['resize', ['resizeFull', 'resizeHalf', 'resizeQuarter', 'resizeNone']],
                            ['float', ['floatLeft', 'floatRight', 'floatNone']],
                            ['remove', ['removeMedia']],
                        ],
                        link: [
                            ['link', ['linkDialogShow', 'unlink']],
                        ],
                        table: [
                            ['add', ['addRowDown', 'addRowUp', 'addColLeft', 'addColRight']],
                            ['delete', ['deleteRow', 'deleteCol', 'deleteTable']],
                        ],
                        air: [
                            ['color', ['color']],
                            ['font', ['bold', 'underline', 'clear']],
                            ['para', ['ul', 'ol', 'paragraph']],
                            ['table', ['table']],
                            ['insert', ['link', 'picture']],
                        ]
                    } : {},
                    airMode: !showToolBars,
                    disableResizeEditor: true,
                    disableDragAndDrop: true,
                    callbacks: {
                        onFocus: function () {
                            _this._hasFocus = true;
                        },
                        onBlur: function (e) {
                            var _a, _b;
                            _this._hasFocus = false;
                            var relatedTarget = e["relatedTarget"];
                            if (relatedTarget === null) {
                                relatedTarget = document.activeElement;
                            }
                            if ((_b = (_a = relatedTarget) === null || _a === void 0 ? void 0 : _a.classList) === null || _b === void 0 ? void 0 : _b.contains("note-btn")) {
                                var beforeRichEditor = $(e.target).closest(".FGCHtmlRichEditor");
                                var activeRichEditor = $(relatedTarget).closest(".FGCHtmlRichEditor");
                                //点击的是当前summernote 的popover中的button
                                if (activeRichEditor === null || activeRichEditor.length === 0) {
                                    return;
                                }
                                if (beforeRichEditor.is(activeRichEditor)) {
                                    return;
                                }
                            }
                            // 当点击的不是 当前summernote 的按钮，提交值
                            _this.commitValue();
                        },
                        onBlurCodeview: function (e) {
                            _this._hasFocus = false;
                            _this.commitValue();
                        }
                    },
                });
                //Deal with select button of ColorPicker with the same ID
                this.resetColorPickerIDAndDataValue("backColorPicker");
                this.resetColorPickerIDAndDataValue("foreColorPicker");
                //add data-id for autoTesting
                var noteEditable = this.editor().siblings(".note-editor").find(".note-editable");
                noteEditable.attr("data-id", this.ID);
                this.updateEditorMode();
                this._setTabIndexToDom();
            };
            HtmlRichEditor.prototype.resetColorPickerIDAndDataValue = function (colorPickerID) {
                var colorPickerInput = $("#" + colorPickerID);
                colorPickerInput.attr("id", colorPickerID + this.ID);
                var colorPickerBtn = colorPickerInput.siblings(".note-color-select.btn");
                colorPickerBtn.attr("data-value", colorPickerID + this.ID);
            };
            HtmlRichEditor.prototype._setOverflowHidden = function (container) {
                // Do Nothing
            };
            HtmlRichEditor.prototype._setTabIndexToDom = function () {
                var cellType = this.CellElement.CellType;
                if (cellType && cellType.TabIndex && Forguncy.ForguncyData.pageInfo.enableTabIndex) {
                    this.editor().siblings(".note-editor").find(".note-editable").attr("tabindex", cellType.TabIndex);
                }
            };
            return HtmlRichEditor;
        }(Forguncy.Plugin.CellTypeBase));
        HtmlRichEditor_1.HtmlRichEditor = HtmlRichEditor;
    })(HtmlRichEditor = Forguncy.HtmlRichEditor || (Forguncy.HtmlRichEditor = {}));
})(Forguncy || (Forguncy = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("HtmlRichEditor.HtmlRichEditor, HtmlRichEditor", Forguncy.HtmlRichEditor.HtmlRichEditor);
//# sourceMappingURL=HtmlRichEditor.js.map