var FilePreviewer;
(function (FilePreviewer) {
    var Resources = (function () {
        function Resources() {
        }
        Resources.Button_Upload = "上传";
        Resources.Button_Preview = "预览";
        Resources.Button_Download = "下载";
        Resources.Button_Delete = "删除";
        Resources.Button_DownloadDirectly = "直接下载";
        Resources.File_CannotPreview = "该文件不支持预览！";
        Resources.File_Uploading = "该文件正在上传中...";
        Resources.Error_UploadFailed = "上传失败。错误信息：";
        Resources.Error_IncorrectFileType = "上传的文件 {0} 类型不正确。";
        Resources.Error_IncorrectFileSize = "上传的文件 {0} 的大小超出了限制, 最大上传文件的大小为 {1} MB。";
        Resources.Error_IncorrectFileCount = "上传的文件数量超出了限制, 最大上传数量为 {0}。";
        return Resources;
    }());
    FilePreviewer.Resources = Resources;
})(FilePreviewer || (FilePreviewer = {}));
