var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    var FileItem = (function () {
        function FileItem(src) {
            this.status = 0;
            this.src = src;
        }
        FileItem.prototype.getEncodeURIComponentSrc = function () {
            return encodeURIComponent(this.src);
        };
        FileItem.prototype.getEntireEncodeURIComponentSrc = function () {
            return encodeURIComponent(this.getEncodeURIComponentSrc());
        };
        FileItem.prototype.getStorageSrc = function () {
            return this.src;
        };
        FileItem.prototype.getExtension = function () {
            return this.src.toLowerCase().split('.').splice(-1)[0];
        };
        FileItem.prototype.getFileName = function () {
            return this.src.split('/').splice(-1)[0];
        };
        FileItem.prototype.getDisplayFileName = function () {
            return this.getFileName();
        };
        FileItem.prototype.getFileType = function () {
            var extension = this.getExtension();
            if (/(jpg|jpeg|gif|bmp|png)/.test(extension)) {
                return 1;
            }
            else if (/(doc|docx|xls|xlsx|ppt|pptx)/.test(extension)) {
                return 2;
            }
            else if (/(pdf)/.test(extension)) {
                return 3;
            }
            else if (/(wav|mp3|mp4|webm|ogg|avi|swf)/.test(extension)) {
                return 4;
            }
            else {
                return 0;
            }
        };
        return FileItem;
    }());
    FilePreviewer.FileItem = FileItem;
    var LoadingFileItem = (function (_super) {
        __extends(LoadingFileItem, _super);
        function LoadingFileItem() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.status = 1;
            _this.events = new FilePreviewer.Events();
            return _this;
        }
        LoadingFileItem.prototype.change = function (e) {
            this.events.raiseEvent("ProgressChanged", e);
        };
        return LoadingFileItem;
    }(FileItem));
    FilePreviewer.LoadingFileItem = LoadingFileItem;
    var FileItemHelper = (function () {
        function FileItemHelper() {
        }
        FileItemHelper.parseFromString = function (value, metadata) {
            if (value) {
                var splits = value.split("|");
                var fileItems = splits.map(function (segment) {
                    if (!FilePreviewer.StringHelper.isNullOrEmpty(segment)) {
                        if (/<.+>/.test(segment)) {
                            var real = segment.slice(segment.indexOf("<") + 1, segment.indexOf(">"));
                            if (real === "Tencent") {
                                var url = segment.slice(segment.indexOf(">") + 1);
                                return new FilePreviewer.TencentCloudFileItem(url);
                            }
                            return null;
                        }
                        else {
                            return new FilePreviewer.ServerFileItem(segment);
                        }
                    }
                });
                return fileItems;
            }
            else {
                return [];
            }
        };
        return FileItemHelper;
    }());
    FilePreviewer.FileItemHelper = FileItemHelper;
})(FilePreviewer || (FilePreviewer = {}));
