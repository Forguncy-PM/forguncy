var VideoPlayer = (function (_super) {
    __extends(VideoPlayer, _super);
    function VideoPlayer() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    //VideoPlayer.prototype.Video = undefined;

    VideoPlayer.prototype.createContent = function () {
        var self = this;

        var element = this.CellElement;
        var cellTypeMetaData = element.CellType;
        var videoInfo = cellTypeMetaData.VideoInfos;
        var controls = cellTypeMetaData.Controls;
        var autoplay = cellTypeMetaData.Autoplay;
        var loop = cellTypeMetaData.Loop;

        if (videoInfo == null || videoInfo.length <= 0) {
            return $("<div id=" + this.ID + "></div>");
        }

        var VideoDiv = $("<div id='" + this.ID + "video_container' style='width:100%;height:100%;align:center;'></div>");
        var video = $("<video id='" + this.ID + "_video' width='100%' height='100%'></video>");
        
        if (controls) {
            video.attr("controls","controls");
        }
        if (autoplay) {
            video.attr("autoplay", "autoplay");
        }
        if (loop) {
            video.attr("loop", "loop");
        }

        video.attr('src', self.getVideoPath(videoInfo[0].VideoPath));
                
        VideoDiv.append(video);

        return VideoDiv;
    }

    VideoPlayer.prototype.getVideoPath = function (video) {
        if (video) {
            return Forguncy.Helper.SpecialPath.getUploadFileFolderPathInDesigner() + "VideoPlayer/Videos/" + video;
        }
        else {
            console.log("source error");
        }
    }

    VideoPlayer.prototype.getValueFromElement = function () {
        return null;
    }

    VideoPlayer.prototype.setValueToElement = function (element, value) {

    }

    VideoPlayer.prototype.disable = function () {
        _super.prototype.disable.call(this);
    }

    VideoPlayer.prototype.enable = function () {
        _super.prototype.enable.call(this);
    }

    return VideoPlayer;
}(Forguncy.CellTypeBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CellTypeHelper.registerCellType("VideoPlayer.VideoPlayer, VideoPlayer", VideoPlayer);