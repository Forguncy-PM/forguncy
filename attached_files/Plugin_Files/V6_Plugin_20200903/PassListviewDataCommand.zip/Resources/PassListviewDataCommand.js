var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PassListviewDataCommand;
(function (PassListviewDataCommand_1) {
    var PassListviewDataCommand = /** @class */ (function (_super) {
        __extends(PassListviewDataCommand, _super);
        function PassListviewDataCommand() {
            var _this = _super.call(this) || this;
            if (!PassListviewDataCommand.hasBindPageEvent) {
                PassListviewDataCommand.hasBindPageEvent = true;
                Forguncy.Page.bind(Forguncy.PageEvents.PageDefaultDataLoaded, PassListviewDataCommand.onCurrentPageChanged, "*");
                Forguncy.Page.bind(Forguncy.PageEvents.PopupClosed, PassListviewDataCommand.onCurrentPageChanged, "*");
            }
            return _this;
        }
        PassListviewDataCommand.onCurrentPageChanged = function (arg1, arg2) {
            PassListviewDataCommand.cache.forEach(function (data) {
                return PassListviewDataCommand.tryToPassDataToCurrentPage(data);
            });
            PassListviewDataCommand.cache = [];
        };
        PassListviewDataCommand.prototype.execute = function () {
            var commandSettings = this.CommandParam;
            var passItems = commandSettings.PassValueItems;
            if (!passItems || passItems.length === 0) {
                return;
            }
            var sourceCells = this.getSourceCellInfos(passItems);
            var sourceListviewData = this.getSourceListviewData(sourceCells, commandSettings.PassRowMode, commandSettings.ImportMode);
            if (sourceListviewData.length === 0 &&
                commandSettings.ImportMode !== Forguncy.ImportMode.Replace &&
                commandSettings.ImportMode !== Forguncy.ImportMode.ReplaceIgnoreEdit) {
                return;
            }
            var passDataInfo = {
                TargetPage: commandSettings.TargetPage,
                TargetCells: this.getTargetCellInfos(passItems),
                Data: sourceListviewData,
                ImportMode: commandSettings.ImportMode
            };
            var success = PassListviewDataCommand.tryToPassDataToCurrentPage(passDataInfo);
            if (!success) {
                PassListviewDataCommand.cache.push(passDataInfo);
            }
        };
        PassListviewDataCommand.prototype.getSourceCellInfos = function (passItems) {
            var _this = this;
            return passItems.map(function (item) { return ({
                Cell: _this.getCellLocationOrColumnName(item.SourceCell),
                IsPrimaryKey: item.IsPrimaryKey
            }); });
        };
        PassListviewDataCommand.prototype.getTargetCellInfos = function (passItems) {
            var _this = this;
            return passItems.map(function (item) { return ({
                Cell: _this.getCellLocationOrColumnName(item.TargetCell),
                IsPrimaryKey: item.IsPrimaryKey
            }); });
        };
        PassListviewDataCommand.prototype.getCellLocationOrColumnName = function (cell) {
            var isFormula = typeof (cell) === "string" && cell.length > 0 && cell[0] === "=";
            if (isFormula) {
                return this.getCellLocation(cell);
            }
            else {
                return cell;
            }
        };
        PassListviewDataCommand.tryToPassDataToCurrentPage = function (passDataInfo) {
            if (PassListviewDataCommand.isTargetListviewInCurrentPage(passDataInfo)) {
                PassListviewDataCommand.addDataToTargetListview(passDataInfo, null);
                return true;
            }
            var subPageInfo = PassListviewDataCommand.getTargetSubPageInfo(passDataInfo);
            if (subPageInfo) {
                PassListviewDataCommand.addDataToTargetListview(passDataInfo, subPageInfo);
                return true;
            }
            return false;
        };
        PassListviewDataCommand.isTargetListviewInCurrentPage = function (passDataInfo) {
            if (Forguncy.Page.getPageName() === passDataInfo.TargetPage) {
                return true;
            }
            if (!passDataInfo.TargetPage) {
                return !!PassListviewDataCommand.getListview(passDataInfo.TargetCells, passDataInfo.ImportMode, null);
            }
            return false;
        };
        PassListviewDataCommand.getTargetSubPageInfo = function (passDataInfo, pageInfo) {
            if (pageInfo === void 0) { pageInfo = null; }
            var containers = pageInfo ? pageInfo.getContainerCells() : Forguncy.Page.getContainerCells(false);
            for (var i = 0; i < containers.length; i++) {
                var subPageInfos = void 0;
                if (containers[i].constructor === Forguncy.ContentContainerCell) {
                    subPageInfos = PassListviewDataCommand.getSubPagesOfContentContainerCell(containers[i]);
                }
                else if (containers[i].constructor === Forguncy.TabControlCell) {
                    subPageInfos = PassListviewDataCommand.getSubPagesOfTabControlCell(containers[i]);
                }
                else {
                    subPageInfos = [];
                }
                for (var k = 0; k < subPageInfos.length; k++) {
                    var subPageInfo = subPageInfos[k];
                    if (PassListviewDataCommand.isTargetListviewInSubPage(passDataInfo, subPageInfo)) {
                        return subPageInfo;
                    }
                    var target = PassListviewDataCommand.getTargetSubPageInfo(passDataInfo, subPageInfo);
                    if (target) {
                        return target;
                    }
                }
            }
            return null;
        };
        PassListviewDataCommand.getSubPagesOfContentContainerCell = function (cell) {
            return [cell.getContentPage()];
        };
        PassListviewDataCommand.getSubPagesOfTabControlCell = function (cell) {
            var subPageInfos = [];
            var tabCount = cell.getTabCount();
            for (var k = 0; k < tabCount; k++) {
                subPageInfos.push(cell.getTabPage(k));
            }
            return subPageInfos;
        };
        PassListviewDataCommand.isTargetListviewInSubPage = function (passDataInfo, subPageInfo) {
            if (!subPageInfo) {
                return false;
            }
            if (subPageInfo.getPageName() === passDataInfo.TargetPage) {
                return true;
            }
            if (!passDataInfo.TargetPage) {
                return !!PassListviewDataCommand.getListview(passDataInfo.TargetCells, passDataInfo.ImportMode, subPageInfo);
            }
        };
        PassListviewDataCommand.prototype.getSourceListviewData = function (sourceCells, passRowMode, importMode) {
            var pageID = this.getFormulaCalcContext().PageID;
            var listview = PassListviewDataCommand.getListview(sourceCells, importMode, Forguncy.Page.getSubPageInfoByPageID(pageID));
            if (!listview) {
                return [];
            }
            var columns = PassListviewDataCommand.getColumns(listview, sourceCells);
            switch (passRowMode) {
                case PassRowMode.SelectedRows:
                    return this.getSourceListviewDataOfSelectedRows(listview, columns);
                case PassRowMode.CurrentRow:
                    return this.getSourceListviewDataOfCurrentRow(listview, columns);
                default:
                    return this.getSourceListviewDataOfAllRows(listview, columns);
            }
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfSelectedRows = function (listview, columns) {
            var selectedRowsData = listview.getSelectedRowsData();
            if (selectedRowsData.length === 1 && !listview.isSelectedRow(listview.getSelectedRowIndex())) {
                //When listview don't have selected column, and no selected row, selectedRowsData will contain current row.
                return [];
            }
            return selectedRowsData.map(function (d) {
                return columns.map(function (c) {
                    if (c === -1) {
                        return null;
                    }
                    else {
                        return d.Values[c];
                    }
                });
            });
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfCurrentRow = function (listview, columns) {
            var currentRowIndex = listview.getSelectedRowIndex();
            var rowCount = listview.getRowCount();
            if (currentRowIndex === undefined || currentRowIndex < 0 || currentRowIndex >= rowCount) {
                return [];
            }
            return [this.getRowDataFromListview(listview, columns, currentRowIndex)];
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfAllRows = function (listview, columns) {
            var data = [];
            var rowCount = listview.getRowCount();
            for (var r = 0; r < rowCount; r++) {
                data.push(this.getRowDataFromListview(listview, columns, r));
            }
            return data;
        };
        PassListviewDataCommand.prototype.getRowDataFromListview = function (listview, columns, rowIndex) {
            return columns.map(function (c) {
                return c === -1 ? null : listview.getValue(rowIndex, c);
            });
        };
        PassListviewDataCommand.getListview = function (cells, importMode, pageInfo) {
            var firstCellLocation;
            for (var i = 0; i < cells.length; i++) {
                if (typeof (cells[i].Cell) === "object") {
                    firstCellLocation = cells[i].Cell;
                    break;
                }
            }
            var primaryColumnNames = [];
            for (var i = 0; i < cells.length; i++) {
                if (typeof (cells[i].Cell) === "string" && cells[i].Cell) {
                    if (importMode === Forguncy.ImportMode.Add) {
                        primaryColumnNames.push(cells[i].Cell);
                        break;
                    }
                    else {
                        if (cells[i].IsPrimaryKey) {
                            primaryColumnNames.push(cells[i].Cell);
                        }
                    }
                }
            }
            if (!firstCellLocation && primaryColumnNames.length <= 0) {
                return null;
            }
            var listViews = pageInfo ? pageInfo.getListViews() : Forguncy.Page.getListViews(false);
            var _loop_1 = function (i) {
                if (firstCellLocation) {
                    if (PassListviewDataCommand.isListviewContainCellLocation(listViews[i], firstCellLocation)) {
                        return { value: listViews[i] };
                    }
                }
                else if (primaryColumnNames) {
                    if (primaryColumnNames.every(function (name) { return PassListviewDataCommand.isListviewContainColumnName(listViews[i], name); })) {
                        return { value: listViews[i] };
                    }
                }
            };
            for (var i = 0; i < listViews.length; i++) {
                var state_1 = _loop_1(i);
                if (typeof state_1 === "object")
                    return state_1.value;
            }
            return null;
        };
        PassListviewDataCommand.isListviewContainCellLocation = function (listview, cellLocation) {
            var rangeInfo = listview.getDesignerRangeInfo();
            return cellLocation.Row >= rangeInfo.Row &&
                cellLocation.Row < rangeInfo.Row + rangeInfo.RowCount &&
                cellLocation.Column >= rangeInfo.Column &&
                cellLocation.Column < rangeInfo.Column + rangeInfo.ColumnCount;
        };
        PassListviewDataCommand.isListviewContainColumnName = function (listview, columnName) {
            return PassListviewDataCommand.getColumnIndex(listview, columnName) !== -1;
        };
        PassListviewDataCommand.getColumnIndex = function (listview, cell) {
            var columns = listview.getMergedColumnInfos();
            if (!cell) {
                return -1;
            }
            else if (typeof (cell) === "string") {
                for (var i = 0; i < columns.length; i++) {
                    if (columns[i].ColumnName === cell) {
                        return i;
                    }
                }
                return -1;
            }
            else {
                for (var i = 0; i < columns.length; i++) {
                    if (columns[i].DesignerColumnIndex === cell.Column) {
                        return i;
                    }
                }
                return -1;
            }
        };
        PassListviewDataCommand.getColumns = function (listview, cells) {
            var columns = [];
            for (var i = 0; i < cells.length; i++) {
                columns.push(PassListviewDataCommand.getColumnIndex(listview, cells[i].Cell));
            }
            return columns;
        };
        PassListviewDataCommand.addDataToTargetListview = function (passDataInfo, pageInfo) {
            var _this = this;
            var listview = PassListviewDataCommand.getListview(passDataInfo.TargetCells, passDataInfo.ImportMode, pageInfo);
            if (!listview) {
                return;
            }
            var columns = PassListviewDataCommand.getColumns(listview, passDataInfo.TargetCells);
            var data = [];
            for (var r = 0; r < passDataInfo.Data.length; r++) {
                var rowData = [];
                for (var c = 0; c < columns.length; c++) {
                    if (columns[c] === -1) {
                        continue;
                    }
                    rowData[columns[c]] = passDataInfo.Data[r][c];
                }
                data.push(rowData);
            }
            var baseColumns = passDataInfo.TargetCells
                .map(function (cell, index) { return cell.IsPrimaryKey ? columns[index] : -1; })
                .filter(function (index) { return index !== -1; });
            var editColumns = columns.filter(function (i) { return i !== -1; });
            listview.importData(data, false, passDataInfo.ImportMode, baseColumns, editColumns, function (result) {
                _this.handleErrorInfo(result);
            });
        };
        PassListviewDataCommand.handleErrorInfo = function (result) {
            if (result.Success) {
                return;
            }
            switch (result.ErrorInfos[0].ErrorType) {
                case Forguncy.ImportError.ExistSameKeys:
                    alert(PassListviewDataCommand_1.RSHelper.getRS().Error_ExistSameKeys);
                    break;
                default:
                    break;
            }
        };
        PassListviewDataCommand.hasBindPageEvent = false;
        PassListviewDataCommand.cache = [];
        return PassListviewDataCommand;
    }(Forguncy.Plugin.CommandBase));
    PassListviewDataCommand_1.PassListviewDataCommand = PassListviewDataCommand;
    var PassRowMode;
    (function (PassRowMode) {
        PassRowMode[PassRowMode["AllRows"] = 0] = "AllRows";
        PassRowMode[PassRowMode["SelectedRows"] = 1] = "SelectedRows";
        PassRowMode[PassRowMode["CurrentRow"] = 2] = "CurrentRow";
    })(PassRowMode || (PassRowMode = {}));
})(PassListviewDataCommand || (PassListviewDataCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("PassListviewDataCommand.PassListviewDataCommand, PassListviewDataCommand", PassListviewDataCommand.PassListviewDataCommand);
