var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PostDataToWebApi;
(function (PostDataToWebApi) {
    var PostDataCommand = (function (_super) {
        __extends(PostDataCommand, _super);
        function PostDataCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PostDataCommand.prototype.execute = function () {
            var _this = this;
            var commandSettings = this.CommandParam;
            var data = this.GenerateData(commandSettings.PostData, 0);
            var webUrl = this.evaluateFormula(commandSettings.WebUrl);
            if (webUrl && webUrl.toLowerCase().indexOf("http://") !== 0 && webUrl.toLowerCase().indexOf("https://") !== 0) {
                webUrl = Forguncy.Helper.SpecialPath.getBaseUrl() + webUrl;
            }
            var contentType = "application/x-www-form-urlencoded; charset=utf-8";
            var postData = commandSettings.PostData;
            if ((postData.DataItemType === DataItemType.Array && postData.Data.IsStringify)
                || (postData.DataItemType === DataItemType.Object && postData.Data.IsStringify)) {
                contentType = "application/json; charset=utf-8";
            }
            this.CommandExecutingInfo.suspend = true;
            $.ajax({
                url: webUrl,
                data: data,
                type: commandSettings.Method,
                contentType: contentType,
                success: function (result) {
                    try {
                        var callback = new Function("result", commandSettings.SuccessCallback);
                        return callback(result);
                    }
                    finally {
                        _this.CommandExecutingInfo.suspend = false;
                    }
                },
                error: function (error) {
                    try {
                        var callback = new Function("error", commandSettings.ErrorCallback);
                        return callback(error.responseText);
                    }
                    finally {
                        _this.CommandExecutingInfo.suspend = false;
                    }
                }
            });
        };
        PostDataCommand.prototype.GenerateData = function (data, rowIndex) {
            var _this = this;
            if (data.DataItemType === DataItemType.ValueOrFormula) {
                var valueOrFormula = data.Data;
                if (typeof valueOrFormula === "string") {
                    return this.evaluateFormula(valueOrFormula);
                }
                return data.Data === undefined ? null : data.Data;
            }
            else if (data.DataItemType === DataItemType.Object) {
                var obj_1 = {};
                var objectData = data.Data;
                if (objectData.Data) {
                    objectData.Data.forEach(function (property) {
                        obj_1[property.Name] = _this.GenerateData(property, rowIndex);
                    });
                }
                if (objectData.IsStringify) {
                    return JSON.stringify(obj_1);
                }
                else {
                    return obj_1;
                }
            }
            else if (data.DataItemType === DataItemType.Array) {
                var arr_1 = [];
                var arrayData = data.Data;
                if (arrayData.Data) {
                    if (arrayData.CountMode === ArrayCountMode.Auto) {
                        arrayData.Data.forEach(function (property, index) {
                            arr_1.push(_this.GenerateData(property, index));
                        });
                    }
                    else if (arrayData.CountMode === ArrayCountMode.Count) {
                        var count = parseInt(arrayData.Count);
                        if (isNaN(count)) {
                            if (arrayData.Count.charAt(0) === '=') {
                                var cellLocation = this.getCellLocation(arrayData.Count);
                                count = Forguncy.Page.getCellByLocation(cellLocation).getValue();
                            }
                            else {
                                count = 0;
                            }
                        }
                        if (arrayData.Data.length > 0) {
                            for (var index = 0; index < count; index++) {
                                if (index < arrayData.Data.length) {
                                    arr_1.push(this.GenerateData(arrayData.Data[index], index));
                                }
                                else {
                                    arr_1.push(this.GenerateData(arrayData.Data[0], index));
                                }
                            }
                        }
                    }
                }
                if (arrayData.IsStringify) {
                    return JSON.stringify(arr_1);
                }
                else {
                    return arr_1;
                }
            }
            else if (data.DataItemType === DataItemType.ListViewData) {
                var listViewData = data.Data;
                var listViewName = this.evaluateFormula(listViewData.ListViewName);
                var columnName = this.evaluateFormula(listViewData.ColumnName);
                if (listViewName) {
                    var listView = Forguncy.Page.getListView(listViewName);
                    if (listView) {
                        var indexOrName = columnName;
                        var index = parseInt(indexOrName);
                        if (isNaN(index)) {
                            return listView.getValue(rowIndex, indexOrName);
                        }
                        else {
                            return listView.getValue(rowIndex, index - 1);
                        }
                    }
                }
            }
        };
        return PostDataCommand;
    }(Forguncy.Plugin.CommandBase));
    PostDataToWebApi.PostDataCommand = PostDataCommand;
    var DataItemType;
    (function (DataItemType) {
        DataItemType[DataItemType["ValueOrFormula"] = 0] = "ValueOrFormula";
        DataItemType[DataItemType["Object"] = 1] = "Object";
        DataItemType[DataItemType["Array"] = 4] = "Array";
        DataItemType[DataItemType["ListViewData"] = 5] = "ListViewData";
    })(DataItemType || (DataItemType = {}));
    var ArrayCountMode;
    (function (ArrayCountMode) {
        ArrayCountMode[ArrayCountMode["Auto"] = 0] = "Auto";
        ArrayCountMode[ArrayCountMode["Count"] = 1] = "Count";
    })(ArrayCountMode || (ArrayCountMode = {}));
})(PostDataToWebApi || (PostDataToWebApi = {}));
Forguncy.Plugin.CommandFactory.registerCommand("PostDataToWebApi.PostDataCommand, PostDataToWebApi", PostDataToWebApi.PostDataCommand);
