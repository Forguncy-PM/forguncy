var Forguncy;
(function (Forguncy) {
    var MenuStyleUtils = (function () {
        function MenuStyleUtils() {
        }
        MenuStyleUtils.InsertArrowFillColorRule = function (container, cssSelector, fillColor) {
            container.prepend("<style>" + cssSelector + " {fill: " + fillColor + " !important;}</style>");
        };
        MenuStyleUtils.InsertForeColorRule = function (container, cssSelector, foreColor) {
            container.prepend("<style>" + cssSelector + " {color: " + foreColor + " !important;}</style>");
        };
        MenuStyleUtils.InsertBackColorRule = function (container, cssSelector, backgroundColor) {
            container.prepend("<style>" + cssSelector + " {background: " + backgroundColor + " border-box !important}</style>");
        };
        MenuStyleUtils.GetBase64FromSvgElement = function (element) {
            var div = document.createElement('div');
            div.appendChild(element.cloneNode(true));
            return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(div.innerHTML)));
        };
        return MenuStyleUtils;
    }());
    Forguncy.MenuStyleUtils = MenuStyleUtils;
})(Forguncy || (Forguncy = {}));
