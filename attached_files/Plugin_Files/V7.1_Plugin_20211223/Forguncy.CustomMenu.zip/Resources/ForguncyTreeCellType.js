var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var ForguncyTreeCellTypeStyleTemplateHelper = (function (_super) {
        __extends(ForguncyTreeCellTypeStyleTemplateHelper, _super);
        function ForguncyTreeCellTypeStyleTemplateHelper() {
            var _this = _super.call(this) || this;
            _this.CellTypeString = "Forguncy.CustomMenu.ForguncyTreeCellType";
            _this.TemplateNameParts = ["Tree"];
            return _this;
        }
        ForguncyTreeCellTypeStyleTemplateHelper.prototype.MapPartsNameToDom = function (container) {
            this.Container = container;
            return {
                Tree: container.find("a")
            };
        };
        return ForguncyTreeCellTypeStyleTemplateHelper;
    }(Forguncy.CellTypeStyleTemplateBase));
    Forguncy.ForguncyTreeCellTypeStyleTemplateHelper = ForguncyTreeCellTypeStyleTemplateHelper;
    var QueryResultMode;
    (function (QueryResultMode) {
        QueryResultMode[QueryResultMode["ToParent"] = 0] = "ToParent";
        QueryResultMode[QueryResultMode["ToChildren"] = 1] = "ToChildren";
        QueryResultMode[QueryResultMode["ToBoth"] = 2] = "ToBoth";
        QueryResultMode[QueryResultMode["OnlyQueryNode"] = 3] = "OnlyQueryNode";
    })(QueryResultMode = Forguncy.QueryResultMode || (Forguncy.QueryResultMode = {}));
    var ForguncyTreeCellType = (function (_super) {
        __extends(ForguncyTreeCellType, _super);
        function ForguncyTreeCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.currentTreeValue = null;
            _this.nodeId = 1;
            _this.tableParamCache = {};
            return _this;
        }
        ForguncyTreeCellType.prototype.getValueFromElement = function () {
            return this.currentTreeValue;
        };
        ForguncyTreeCellType.prototype.setValueToElement = function (element, value) {
            if (this.currentTreeValue !== value) {
                this.currentTreeValue = value;
                this.updateTreeActiveState();
            }
            this.selectTreeNode(value);
        };
        ForguncyTreeCellType.prototype.selectTreeNode = function (value) {
            var treeObj = this.getZTree(this.treeID);
            var success = this.updateSelectionStyle(treeObj, value);
            if (success) {
                return;
            }
            var selectedNodes = treeObj.getSelectedNodes();
            if (selectedNodes.length > 0) {
                treeObj.cancelSelectedNode(selectedNodes[0]);
            }
        };
        Object.defineProperty(ForguncyTreeCellType.prototype, "treeID", {
            get: function () {
                return this.ID + "_" + this._pageID;
            },
            enumerable: false,
            configurable: true
        });
        ForguncyTreeCellType.prototype.getZTree = function (id) {
            return $.fn.zTree.getZTreeObj(id);
        };
        ForguncyTreeCellType.prototype.updateSelectionStyle = function (treeObj, value) {
            var selectedNodesBefore = treeObj.getSelectedNodes();
            var beforeSelectNode = null;
            if (selectedNodesBefore && selectedNodesBefore.length === 1 && selectedNodesBefore[0].value === value) {
                beforeSelectNode = selectedNodesBefore[0];
            }
            var nodes = treeObj.transformToArray(treeObj.getNodes());
            var switcher = [];
            if (beforeSelectNode) {
                switcher = $("#" + beforeSelectNode.tId + "_switch");
            }
            $("#" + this.ID + " .selected").removeClass("selected");
            $("#" + this.ID + " span.switch").attr("data-selected", "");
            if (beforeSelectNode) {
                $("#" + this.ID + " li#" + beforeSelectNode.tId + ">a").addClass("selected");
                if (switcher.length) {
                    switcher.attr("data-selected", "selected");
                }
                return true;
            }
            else {
                for (var i = 0; i < nodes.length; i++) {
                    if (nodes[i].tag == value) {
                        treeObj.selectNode(nodes[i]);
                        $("#" + this.ID + " li#" + nodes[i].tId + ">.switch").attr("data-selected", "selected");
                        $("#" + this.ID + " li#" + nodes[i].tId + ">a").addClass("selected");
                        return true;
                    }
                }
            }
            return false;
        };
        ForguncyTreeCellType.prototype.createContent = function () {
            var container = $("<div id='" + this.ID + "' class=\"treeContainer\"/>");
            this.treeContainer = container;
            var ul = $("<ul id='" + this.treeID + "' class= 'ztree' > </ul>");
            container.append(ul);
            this.addSelectedStyle(container);
            var self = this;
            this.onDependenceCellValueChanged(function (uiAction) {
                self.initZTree();
                self.selectTreeNode(self.currentTreeValue);
            });
            return container;
        };
        ForguncyTreeCellType.prototype.addSelectedStyle = function (container) {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var treeStyleInfo = cellTypeMetaData.TreeStyleInfo;
            if (treeStyleInfo) {
                if (treeStyleInfo.SelectedBackColor && treeStyleInfo.SelectedBackColor != "") {
                    container.append($("<style> #" + this.treeID + " li a.curSelectedNode { background:" + Forguncy.ConvertToCssColor(treeStyleInfo.SelectedBackColor) + ";}</style>"));
                }
                if (treeStyleInfo.SelectedForeColor && treeStyleInfo.SelectedForeColor != "") {
                    container.append($("<style> #" + this.treeID + " li a.curSelectedNode { color:" + Forguncy.ConvertToCssColor(treeStyleInfo.SelectedForeColor) + ";}</style>"));
                }
            }
        };
        ForguncyTreeCellType.prototype._setFontStyle = function (styleInfo) {
            var cellTypeMetaData = this.CellElement.CellType;
            this.initIcon(cellTypeMetaData, this.treeContainer[0], this.CellElement);
            var ul = this.treeContainer.find("#" + this.treeID);
            if (styleInfo.FontFamily) {
                ul.css("font-family", styleInfo.FontFamily);
            }
            else {
                ul.css("font-family", Forguncy.LocaleFonts.default);
            }
            if (styleInfo.FontSize && styleInfo.FontSize > 0) {
                ul.css("font-size", styleInfo.FontSize);
                var lineHeight = Math.ceil(styleInfo.FontSize + 8);
                ul.find("li").css("line-height", lineHeight + "px");
                ul.find("li span").css("line-height", lineHeight + "px");
            }
            if (styleInfo.Foreground && styleInfo.Foreground !== "") {
                $("#" + this.ID).find("ul li a").css("color", Forguncy.ConvertToCssColor(styleInfo.Foreground));
            }
            else {
                $("#" + this.ID).find("ul li a").css("color", "");
            }
            $("#" + this.ID).find("ul li a.selected").css("color", "");
        };
        ForguncyTreeCellType.prototype.getStyleTemplateHelper = function () {
            var cellTypeMetaData = this.CellElement.CellType;
            if (cellTypeMetaData.TreeStyleInfo) {
                return null;
            }
            return ForguncyTreeCellType.StyleTemplateHelper;
        };
        ForguncyTreeCellType.prototype.getTreeSettings = function () {
            var self = this;
            var cellType = this.CellElement.CellType;
            var setting = {
                view: {
                    showLine: false,
                    dblClickExpand: false
                },
                data: {
                    simpleData: {
                        enable: cellType.TreeBindingMode !== 1 || !cellType.IsBinding
                    }
                },
                callback: {
                    onClick: function (e, treeId, treeNode) {
                        if (!self.isEnabled) {
                            return;
                        }
                        if (treeNode.tag !== self.currentTreeValue) {
                            self.currentTreeValue = treeNode.tag;
                            self.updateTreeActiveState();
                            self.commitValue();
                        }
                        self.updateSelectionStyle(self.getZTree(treeId), treeNode.tag);
                        var clickCommand = self.CellElement.CellType.TreeClickCommand;
                        self.onTreeClick(clickCommand, treeNode);
                    },
                    onNodeCreated: function (event, treeId, treeNode) {
                        if (treeNode.isLastNode) {
                            self.repaint();
                        }
                    },
                    onExpand: function () {
                        self.updateSimpleBar();
                    },
                    onCollapse: function () {
                        self.updateSimpleBar();
                    }
                }
            };
            return setting;
        };
        ForguncyTreeCellType.prototype.onTreeClick = function (clickCommand, currentTreeNode) {
            if (!clickCommand) {
                return;
            }
            if (this.isCommandExecuting()) {
                return;
            }
            var context = this.getFormulaCalcContext();
            Forguncy.CellHelper.setValueToCell(context, clickCommand.ValueTo, currentTreeNode.value);
            Forguncy.CellHelper.setValueToCell(context, clickCommand.NameTo, currentTreeNode.name);
            Forguncy.CellHelper.setValueToCell(context, clickCommand.LevelTo, currentTreeNode.level + 1);
            var commands = clickCommand.CommandList;
            if (commands && commands.length > 0) {
                this.executeCommand(commands);
            }
        };
        ForguncyTreeCellType.prototype.getTreeNodes = function () {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var bindingTreeLevelInfo = cellTypeMetaData.BindingTreeLevelInfo;
            var isBinding = cellTypeMetaData.IsBinding;
            var treeBindingMode = cellTypeMetaData.TreeBindingMode;
            var items = cellTypeMetaData.Items;
            if (isBinding === true) {
                this.tableParamCache = {};
                this.addTableParamInfo(bindingTreeLevelInfo);
                if (treeBindingMode === 1) {
                    return this.getTreeNodesInDynamicMode(bindingTreeLevelInfo);
                }
                items = this.getBindingItemsInFixLevelMode(bindingTreeLevelInfo, null, "");
            }
            if (items == null || items.length === 0) {
                return [];
            }
            var nodes = this.convertItemsToTreeNodes(items, null, "");
            return nodes;
        };
        ForguncyTreeCellType.prototype.addTableParamInfo = function (bindingTreeLevelInfo) {
            if (!bindingTreeLevelInfo) {
                return;
            }
            var tableName = bindingTreeLevelInfo.TableName;
            if (this.isEmpty(tableName)) {
                return;
            }
            var columns = [];
            this.addTableColumnParamInfo(columns, bindingTreeLevelInfo.NameColumn);
            this.addTableColumnParamInfo(columns, bindingTreeLevelInfo.ValueColumn);
            this.addTableColumnParamInfo(columns, bindingTreeLevelInfo.MasterTableReletedColumn);
            var param = {
                TableName: tableName,
                Columns: columns,
                QueryCondition: bindingTreeLevelInfo.QueryCondition,
                QueryPolicy: {
                    Distinct: false,
                    QueryNullPolicy: Forguncy.QueryNullPolicy.QueryAllItemsWhenValueIsNull,
                    IgnoreCache: false
                },
                SortCondition: bindingTreeLevelInfo.SortCondition
            };
            var postParamWithoutQuery = {
                TableName: tableName,
                Columns: columns,
                QueryPolicy: {
                    Distinct: false,
                    QueryNullPolicy: Forguncy.QueryNullPolicy.QueryAllItemsWhenValueIsNull,
                    IgnoreCache: false
                },
                SortCondition: bindingTreeLevelInfo.SortCondition
            };
            if (!this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)]) {
                this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)] = {};
                this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)].postParam = param;
                this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)].postParamWithoutQuery = postParamWithoutQuery;
            }
            this.addTableParamInfo(bindingTreeLevelInfo.SubBindingTreeLevelInfo);
        };
        ForguncyTreeCellType.prototype.isEmpty = function (obj) {
            if (obj === null || obj === "" || obj === undefined) {
                return true;
            }
            return false;
        };
        ForguncyTreeCellType.prototype.addTableColumnParamInfo = function (list, columnName) {
            if (!this.isEmpty(columnName) && list.indexOf(columnName) === -1) {
                list.push(columnName);
            }
        };
        ForguncyTreeCellType.prototype.getBindingItemsInFixLevelMode = function (bindingTreeLevelInfo, masterTableRelatedColumnValue, tag) {
            if (!bindingTreeLevelInfo || this.isEmpty(bindingTreeLevelInfo.TableName)) {
                return null;
            }
            var postParam = this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)].postParam;
            var tableData = this.getTableDataByCondition(postParam);
            var items = [];
            if (tableData != null) {
                var flags = {};
                for (var i = 0; i < tableData.length; i++) {
                    if (bindingTreeLevelInfo.MasterTableReletedColumn) {
                        var mRCvalue = tableData[i][bindingTreeLevelInfo.MasterTableReletedColumn];
                        if (masterTableRelatedColumnValue != null) {
                            if (mRCvalue !== masterTableRelatedColumnValue) {
                                continue;
                            }
                        }
                    }
                    var value = tableData[i][bindingTreeLevelInfo.ValueColumn];
                    if (value == null || flags[tag + "_" + value] === true) {
                        continue;
                    }
                    flags[tag + "_" + value] = true;
                    var itemInfo = {};
                    var text = tableData[i][bindingTreeLevelInfo.NameColumn];
                    if (text === undefined || text === null) {
                        text = "";
                    }
                    itemInfo.Text = text;
                    itemInfo.Value = value;
                    var detailTableReletedColumnValue = value;
                    if (bindingTreeLevelInfo.SubBindingTreeLevelInfo) {
                        var subItems = this.getBindingItemsInFixLevelMode(bindingTreeLevelInfo.SubBindingTreeLevelInfo, detailTableReletedColumnValue, tag + "_" + value);
                        if (subItems != null) {
                            itemInfo.SubItems = subItems;
                        }
                    }
                    items.push(itemInfo);
                }
            }
            return items;
        };
        ForguncyTreeCellType.prototype.getTableDataByCondition = function (postParam) {
            var tableData = null;
            Forguncy.getTableDataByCondition(postParam, this.getFormulaCalcContext(), function (data) {
                tableData = data;
            }, false);
            return tableData;
        };
        ForguncyTreeCellType.prototype.getTreeNodesInDynamicMode = function (bindingTreeLevelInfo) {
            var _this = this;
            var paramInfo = this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)];
            var postParam = paramInfo.postParam;
            var postParamWithoutQuery = paramInfo.postParamWithoutQuery;
            var allTableData = this.getTableDataByCondition(postParamWithoutQuery);
            var tableData = this.getTableDataByCondition(postParam);
            if (!allTableData || !tableData) {
                return null;
            }
            var allDataNodes = allTableData.map(function (item) {
                var _a, _b;
                return ({
                    id: (_a = item[bindingTreeLevelInfo.ValueColumn]) === null || _a === void 0 ? void 0 : _a.toString(),
                    pid: (_b = item[bindingTreeLevelInfo.MasterTableReletedColumn]) === null || _b === void 0 ? void 0 : _b.toString(),
                    text: item[bindingTreeLevelInfo.NameColumn],
                    name: item[bindingTreeLevelInfo.NameColumn],
                    value: item[bindingTreeLevelInfo.ValueColumn],
                    tag: item[bindingTreeLevelInfo.ValueColumn]
                });
            });
            for (var _i = 0, allDataNodes_1 = allDataNodes; _i < allDataNodes_1.length; _i++) {
                var node = allDataNodes_1[_i];
                node.uId = this.getUid(node.id, node.pid);
            }
            var queryUids = {};
            for (var _a = 0, tableData_1 = tableData; _a < tableData_1.length; _a++) {
                var item = tableData_1[_a];
                queryUids[this.getUid(item[bindingTreeLevelInfo.ValueColumn], item[bindingTreeLevelInfo.MasterTableReletedColumn])] = true;
            }
            var uidNodesCache = {};
            var idNodesCache = {};
            var parentIdNodesCache = {};
            for (var _b = 0, allDataNodes_2 = allDataNodes; _b < allDataNodes_2.length; _b++) {
                var node = allDataNodes_2[_b];
                uidNodesCache[node.uId] = node;
            }
            for (var _c = 0, allDataNodes_3 = allDataNodes; _c < allDataNodes_3.length; _c++) {
                var node = allDataNodes_3[_c];
                if (!idNodesCache[node.id]) {
                    idNodesCache[node.id] = [];
                }
                idNodesCache[node.id].push(node);
            }
            for (var _d = 0, allDataNodes_4 = allDataNodes; _d < allDataNodes_4.length; _d++) {
                var node = allDataNodes_4[_d];
                if (!parentIdNodesCache[node.pid]) {
                    parentIdNodesCache[node.pid] = [];
                }
                parentIdNodesCache[node.pid].push(node);
            }
            this.updateQuery(bindingTreeLevelInfo.QueryResultMode, queryUids, uidNodesCache, idNodesCache, parentIdNodesCache);
            var filteredNodes = allDataNodes.filter(function (i) { return queryUids[i.uId]; });
            this.buildChildren(filteredNodes, parentIdNodesCache, queryUids);
            var roots = filteredNodes.filter(function (i) { return _this.isRootNode(i, queryUids, idNodesCache); });
            var exsitId = {};
            var uniqueRoots = roots.filter(function (i) {
                if (exsitId[i.id]) {
                    return false;
                }
                exsitId[i.id] = true;
                return true;
            });
            return uniqueRoots;
        };
        ForguncyTreeCellType.prototype.getUid = function (id, pid) {
            return (id !== null && id !== void 0 ? id : "") + "_%_" + (pid !== null && pid !== void 0 ? pid : "");
        };
        ForguncyTreeCellType.prototype.buildChildren = function (filteredNodes, parentIdDataNodesCache, queryUids) {
            for (var _i = 0, filteredNodes_1 = filteredNodes; _i < filteredNodes_1.length; _i++) {
                var node = filteredNodes_1[_i];
                var children = parentIdDataNodesCache[node.id];
                if (children) {
                    node.children = children.filter(function (i) { return queryUids[i.uId]; });
                }
                else {
                    node.children = [];
                }
            }
        };
        ForguncyTreeCellType.prototype.isRootNode = function (node, queryUids, idNodesCache) {
            if (!node.pid) {
                return true;
            }
            var nodes = idNodesCache[node.pid];
            if (!nodes) {
                return true;
            }
            for (var _i = 0, nodes_1 = nodes; _i < nodes_1.length; _i++) {
                var pnode = nodes_1[_i];
                if (queryUids[pnode.uId]) {
                    return false;
                }
            }
            return true;
        };
        ForguncyTreeCellType.prototype.updateQuery = function (queryMode, queryUids, uidNodesCache, idNodesCache, parentIdNodesCache) {
            for (var uid in queryUids) {
                var node = uidNodesCache[uid];
                if (queryMode === QueryResultMode.ToParent) {
                    this.addParentIdToQuery(queryUids, node.pid, idNodesCache);
                }
                else if (queryMode === QueryResultMode.ToChildren) {
                    this.addChildIdToQuery(queryUids, node.id, parentIdNodesCache);
                }
                else if (queryMode === QueryResultMode.ToBoth) {
                    this.addParentIdToQuery(queryUids, node.pid, idNodesCache);
                    this.addChildIdToQuery(queryUids, node.id, parentIdNodesCache);
                }
            }
        };
        ForguncyTreeCellType.prototype.addParentIdToQuery = function (queryUids, pid, idNodesCache) {
            if (!pid) {
                return;
            }
            var nodes = idNodesCache[pid];
            if (nodes) {
                for (var _i = 0, nodes_2 = nodes; _i < nodes_2.length; _i++) {
                    var node = nodes_2[_i];
                    if (node && !queryUids[node.uId]) {
                        queryUids[node.uId] = true;
                        this.addParentIdToQuery(queryUids, node.pid, idNodesCache);
                    }
                }
            }
        };
        ForguncyTreeCellType.prototype.addChildIdToQuery = function (queryUids, id, parentIdNodesCache) {
            var nodes = parentIdNodesCache[id];
            if (nodes) {
                for (var _i = 0, nodes_3 = nodes; _i < nodes_3.length; _i++) {
                    var node = nodes_3[_i];
                    if (node && !queryUids[node.uId]) {
                        queryUids[node.uId] = true;
                        this.addChildIdToQuery(queryUids, node.id, parentIdNodesCache);
                    }
                }
            }
        };
        ForguncyTreeCellType.prototype.convertItemsToTreeNodes = function (items, pId, pTag) {
            if (items != null && items.length > 0) {
                var nodes = [];
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    var node = {
                        id: this.nodeId++,
                        value: item.Value,
                        name: item.Text,
                        pId: pId,
                        tag: pTag === "" ? item.Value : (pTag + "_" + item.Value)
                    };
                    nodes.push(node);
                    var subNodes = this.convertItemsToTreeNodes(item.SubItems, node.id, node.tag);
                    if (subNodes != null && subNodes.length > 0) {
                        for (var k = 0; k < subNodes.length; k++) {
                            nodes.push(subNodes[k]);
                        }
                    }
                }
                return nodes;
            }
            return null;
        };
        ForguncyTreeCellType.prototype.onPageLoaded = function () {
            this.initZTree();
            this.createSimpleBar();
        };
        ForguncyTreeCellType.prototype.getImageUrl = function (image) {
            if (!image) {
                return "";
            }
            if (!image.Name) {
                return "";
            }
            var src = "";
            if (image.BuiltIn) {
                src = Forguncy.Helper.SpecialPath.getBuiltInImageFolderPath() + image.Name;
            }
            else {
                src = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + encodeURIComponent(image.Name);
            }
            return src;
        };
        ForguncyTreeCellType.prototype.getSvgElement = function (data) {
            var svgElement;
            if (typeof data === "string") {
                var parser = new DOMParser();
                svgElement = parser.parseFromString(data, "image/svg+xml").documentElement;
            }
            else {
                svgElement = data.documentElement;
            }
            svgElement.setAttribute('height', '100%');
            svgElement.setAttribute('width', '100%');
            return $(svgElement);
        };
        ForguncyTreeCellType.prototype.setIconStyle = function (src, defaultUrl, svgColor, selector, element, UseCellTypeForeColor) {
            var _this = this;
            if (src.length === 0) {
                return this.appendStyleToBody(defaultUrl, selector, element);
            }
            if (Forguncy.ImageDataHelper.IsSvg(src)) {
                $.ajax({
                    url: src,
                    success: function (data) {
                        var _a, _b, _c, _d, _e, _f, _g, _h;
                        var svgElement = _this.getSvgElement(data);
                        var notNormalColors = [{
                                selector: selector + ':hover',
                                value: (_d = (_c = (_b = (_a = element.StyleTemplate) === null || _a === void 0 ? void 0 : _a.Styles) === null || _b === void 0 ? void 0 : _b.Tree) === null || _c === void 0 ? void 0 : _c.HoverStyle) === null || _d === void 0 ? void 0 : _d.FontColor,
                            }, {
                                selector: selector + '[data-selected=selected]',
                                value: (_h = (_g = (_f = (_e = element.StyleTemplate) === null || _e === void 0 ? void 0 : _e.Styles) === null || _f === void 0 ? void 0 : _f.Tree) === null || _g === void 0 ? void 0 : _g.SelectedStyle) === null || _h === void 0 ? void 0 : _h.FontColor,
                            }];
                        if (UseCellTypeForeColor) {
                            notNormalColors.map(function (v) {
                                if (!v.value) {
                                    return;
                                }
                                var svgElement = _this.getSvgElement(data);
                                Forguncy.ImageHelper.preHandleSvg(svgElement, v.value);
                                _this.appendStyleToBody(Forguncy.MenuStyleUtils.GetBase64FromSvgElement(svgElement[0]), v.selector, element);
                            });
                        }
                        Forguncy.ImageHelper.preHandleSvg(svgElement, svgColor);
                        _this.appendStyleToBody(Forguncy.MenuStyleUtils.GetBase64FromSvgElement(svgElement[0]), selector, element);
                    }
                });
            }
            else {
                this.appendStyleToBody(src, selector, element);
            }
        };
        ForguncyTreeCellType.prototype.appendStyleToBody = function (url, selector, element) {
            var oldStyle = this.treeContainer.find('style');
            for (var i = 0; i < oldStyle.length; i++) {
                if (oldStyle[i].getAttribute('data-selector') === selector) {
                    $(oldStyle[i]).remove();
                }
            }
            var style = document.createElement('style');
            style.type = 'text/css';
            style.setAttribute('data-selector', selector);
            style.innerHTML = "\n#" + this.ID + " " + selector + "{\n\tbackground-image: url(" + url + ");\n}\n[id_temp=" + this.ID + "] " + selector + "{\n\tbackground-image: url(" + url + ");\n}\n";
            this.treeContainer.append(style);
        };
        ForguncyTreeCellType.prototype.getCellTypeForeColor = function (element) {
            var _a, _b, _c, _d, _e;
            return ((_a = element.StyleInfo) === null || _a === void 0 ? void 0 : _a.Foreground) || ((_e = (_d = (_c = (_b = element.StyleTemplate) === null || _b === void 0 ? void 0 : _b.Styles) === null || _c === void 0 ? void 0 : _c.Tree) === null || _d === void 0 ? void 0 : _d.NormalStyle) === null || _e === void 0 ? void 0 : _e.FontColor);
        };
        ForguncyTreeCellType.prototype.initIcon = function (cellTypeMetaData, container, element) {
            var _a, _b, _c, _d, _e, _f;
            var ExpandIconSrc = this.getImageUrl(cellTypeMetaData.ExpandIcon);
            var CloseIconSrc = this.getImageUrl(cellTypeMetaData.CloseIcon);
            var ExpandSvgColor = Forguncy.ConvertToCssColor(((_a = cellTypeMetaData.ExpandIcon) === null || _a === void 0 ? void 0 : _a.UseCellTypeForeColor)
                ? this.getCellTypeForeColor(element)
                : (_b = cellTypeMetaData.ExpandIcon) === null || _b === void 0 ? void 0 : _b.Color);
            var CloseSvgColor = Forguncy.ConvertToCssColor(((_c = cellTypeMetaData.CloseIcon) === null || _c === void 0 ? void 0 : _c.UseCellTypeForeColor)
                ? this.getCellTypeForeColor(element)
                : (_d = cellTypeMetaData.CloseIcon) === null || _d === void 0 ? void 0 : _d.Color);
            var defaultCloseUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAJ9JREFUOBFjYBjUoKGhgQmE8TmSEZckSCM3N/cckPzXr19TgPx/2NSyYBOEif3//18XxsZF43UeLk3I4iheQPMvExcX13GQ4m/fvlkCKbgXkL0DNwDm53///hkwMjL+hdqiCaWvg2igl5iZmJguIIfJIPIC1KlwCuQlYBicBAkAw8Ac2d9wRUAGxV7Amw6AgXkZ2TaS2SBvgDDJGumqAQA1Hj0c2PUgTQAAAABJRU5ErkJggg==";
            var defaultExpandUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAFxJREFUOBFjYBgFAx8CjMhOaGhoYELm42ID1f2DycENAGnm5uae8+/fPwNGRsa/MAXI9P///5mZmJgufP36NQVmCFE2IhuCzoa7ACQBcgW6Amx8mO3Y5EbFBiIEAEVwGAZkoAtuAAAAAElFTkSuQmCC";
            this.setIconStyle(CloseIconSrc, defaultCloseUrl, CloseSvgColor, '.ztree li span.button.noline_close', element, (_e = cellTypeMetaData.CloseIcon) === null || _e === void 0 ? void 0 : _e.UseCellTypeForeColor);
            this.setIconStyle(ExpandIconSrc, defaultExpandUrl, ExpandSvgColor, '.ztree li span.button.noline_open', element, (_f = cellTypeMetaData.ExpandIcon) === null || _f === void 0 ? void 0 : _f.UseCellTypeForeColor);
        };
        ForguncyTreeCellType.prototype.initZTree = function () {
            $.fn.zTree.init($("#" + this.treeID), this.getTreeSettings(), this.getTreeNodes());
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            if (cellTypeMetaData.DefaultExpandStyle === 0) {
                var tree = $.fn.zTree.getZTreeObj(this.treeID);
                var nodes = tree.transformToArray(tree.getNodes());
                for (var i = 0; i < nodes.length; i++) {
                    var node = nodes[i];
                    tree.expandNode(node, undefined, undefined, false, true);
                }
            }
            else if (cellTypeMetaData.DefaultExpandStyle === 1) {
                var tree = $.fn.zTree.getZTreeObj(this.treeID);
                var level = cellTypeMetaData.SpecifyExpandedLevel - 1;
                var nodes = tree.transformToArray(tree.getNodes());
                for (var i = 0; i < nodes.length; i++) {
                    var node = nodes[i];
                    if (node.level < level) {
                        tree.expandNode(node, undefined, undefined, false, true);
                    }
                }
            }
        };
        ForguncyTreeCellType.prototype.getDefaultValue = function () {
            var currentTreeActiveState = this.getTreeActiveState();
            if (currentTreeActiveState) {
                return {
                    Value: currentTreeActiveState
                };
            }
            return null;
        };
        ForguncyTreeCellType.prototype.getTreeActiveState = function () {
            var pageName = this.IsInMasterPage === true ? Forguncy.Page.getMasterPageName() : Forguncy.Page.getPageName();
            if (ForguncyTreeCellType.treeStorage == null || ForguncyTreeCellType.treeStorage[pageName] == null || ForguncyTreeCellType.treeStorage[pageName][this.ID] == null) {
                return;
            }
            var currentTreeStorage = ForguncyTreeCellType.treeStorage[pageName][this.ID];
            return currentTreeStorage["active_treeNode"];
        };
        ForguncyTreeCellType.prototype.updateTreeActiveState = function () {
            if (ForguncyTreeCellType.treeStorage == null) {
                ForguncyTreeCellType.treeStorage = {};
            }
            var pageName = this.IsInMasterPage === true ? Forguncy.ForguncyData.pageInfo.masterPageName : Forguncy.ForguncyData.pageInfo.pageName;
            if (ForguncyTreeCellType.treeStorage[pageName] == null) {
                ForguncyTreeCellType.treeStorage[pageName] = {};
            }
            if (ForguncyTreeCellType.treeStorage[pageName][this.ID] == null) {
                ForguncyTreeCellType.treeStorage[pageName][this.ID] = [];
            }
            ForguncyTreeCellType.treeStorage[pageName][this.ID]["active_treeNode"] = this.currentTreeValue;
        };
        ForguncyTreeCellType.prototype.createSimpleBar = function () {
            var container = $("#" + this.ID + "_div");
            if (Forguncy.Platform.isIpad() || Forguncy.Platform.isMobile()) {
                container.css("overflow", "auto");
                return;
            }
            this.simpleBar = new SimpleBar(container[0]);
            this.updateContainerForSimplebar();
        };
        ForguncyTreeCellType.prototype.updateSimpleBar = function () {
            this.simpleBar && this.simpleBar.recalculate();
        };
        ForguncyTreeCellType.prototype.getBindingTables = function () {
            var cellTypeMetaData = this.CellElement.CellType;
            var isBinding = cellTypeMetaData.IsBinding;
            var bindingTreeLevelInfo = cellTypeMetaData.BindingTreeLevelInfo;
            if (!isBinding || !bindingTreeLevelInfo) {
                return null;
            }
            var result = [];
            var treeBindingMode = cellTypeMetaData.TreeBindingMode;
            if (treeBindingMode == 1) {
                result.push(bindingTreeLevelInfo.TableName);
            }
            else {
                this.addRelatedTables(bindingTreeLevelInfo, result);
            }
            return result;
        };
        ForguncyTreeCellType.prototype.addRelatedTables = function (bindingTreeLevelInfo, list) {
            if (bindingTreeLevelInfo) {
                list.push(bindingTreeLevelInfo.TableName);
                this.addRelatedTables(bindingTreeLevelInfo.SubBindingTreeLevelInfo, list);
            }
        };
        ForguncyTreeCellType.prototype.reload = function () {
            var isReload = arguments[0];
            if (isReload) {
                this.initZTree();
                this.selectTreeNode(this.currentTreeValue);
                this.repaint();
            }
        };
        ForguncyTreeCellType.prototype.repaint = function () {
            var cell = Forguncy.ForguncyData.pageInfo.pageElementManager.cells.getCell(this.ID);
            if (cell) {
                cell.repaint();
            }
        };
        ForguncyTreeCellType.prototype.destroy = function () {
            _super.prototype.destroy.call(this);
            this.treeContainer = null;
        };
        ForguncyTreeCellType.treeStorage = {};
        ForguncyTreeCellType.StyleTemplateHelper = new ForguncyTreeCellTypeStyleTemplateHelper();
        return ForguncyTreeCellType;
    }(Forguncy.Plugin.CellTypeBaseWithSimplebar));
    Forguncy.ForguncyTreeCellType = ForguncyTreeCellType;
})(Forguncy || (Forguncy = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Forguncy.CustomMenu.ForguncyTreeCellType, Forguncy.CustomMenu", Forguncy.ForguncyTreeCellType);
