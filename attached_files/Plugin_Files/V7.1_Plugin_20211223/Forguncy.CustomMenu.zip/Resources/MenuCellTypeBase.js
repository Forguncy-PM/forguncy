var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var MenuStorageOption = (function () {
        function MenuStorageOption() {
            this._data = {};
        }
        MenuStorageOption.prototype.ensureMenuStorage = function () {
            var propertyNames = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                propertyNames[_i] = arguments[_i];
            }
            var obj = this._data;
            for (var i = 0; i < propertyNames.length; i++) {
                var name_1 = propertyNames[i];
                if (!obj[name_1]) {
                    obj[name_1] = {};
                }
                obj = obj[name_1];
            }
        };
        MenuStorageOption.prototype.updateSelect = function (pageName, cellID, aTag, isDefaultValue) {
            this.ensureMenuStorage(pageName, cellID);
            if (isDefaultValue) {
                if (!this._data[pageName][cellID]["select_a_tag"]) {
                    this._data[pageName][cellID]["select_a_tag"] = aTag;
                }
            }
            else {
                this._data[pageName][cellID]["select_a_tag"] = aTag;
            }
        };
        MenuStorageOption.prototype.updateExpand = function (pageName, cellID, levelIndex, aTag, isExpand, isDefaultValue) {
            this.ensureMenuStorage(pageName, cellID, "expand_tag", levelIndex);
            if (isDefaultValue) {
                if (this._data[pageName][cellID]["expand_tag"][levelIndex][aTag] === null ||
                    this._data[pageName][cellID]["expand_tag"][levelIndex][aTag] === undefined) {
                    this._data[pageName][cellID]["expand_tag"][levelIndex][aTag] = isExpand;
                }
            }
            else {
                this._data[pageName][cellID]["expand_tag"][levelIndex][aTag] = isExpand;
            }
        };
        MenuStorageOption.prototype.updateScrollTop = function (pageName, cellID, top) {
            this.ensureMenuStorage(pageName, cellID);
            this._data[pageName][cellID]["scrollTop"] = top;
        };
        MenuStorageOption.prototype.getMenuStorage = function (pageName, cellID) {
            var _a;
            return (_a = this._data[pageName]) === null || _a === void 0 ? void 0 : _a[cellID];
        };
        MenuStorageOption.prototype.getSelectStorage = function (pageName, cellID) {
            var _a;
            return (_a = this.getMenuStorage(pageName, cellID)) === null || _a === void 0 ? void 0 : _a["select_a_tag"];
        };
        MenuStorageOption.prototype.getExpandStorage = function (pageName, cellID) {
            var _a;
            return (_a = this.getMenuStorage(pageName, cellID)) === null || _a === void 0 ? void 0 : _a["expand_tag"];
        };
        MenuStorageOption.prototype.getScrollStorage = function (pageName, cellID) {
            var _a;
            return (_a = this.getMenuStorage(pageName, cellID)) === null || _a === void 0 ? void 0 : _a["scrollTop"];
        };
        return MenuStorageOption;
    }());
    var MenuCellTypeBase = (function (_super) {
        __extends(MenuCellTypeBase, _super);
        function MenuCellTypeBase() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._bindingListViews = [];
            _this._loopInvoker = new LoopInvoker();
            _this.pageNavigatedBind = _this.pageNavigated.bind(_this);
            _this.notifyNodes = [];
            return _this;
        }
        MenuCellTypeBase.prototype.pageNavigated = function (arg1, arg2) {
            this.highlight(arg2.pageName);
        };
        MenuCellTypeBase.prototype.highlight = function (pageName) {
            var cellTypeMetaData = this.CellElement.CellType;
            var items = cellTypeMetaData.Items;
            var needHighlightItems = [];
            this.getNeedHighlightItems(items, pageName, needHighlightItems);
            if (!needHighlightItems || needHighlightItems.length === 0) {
                return;
            }
            if (this.isAnyItemSelected(needHighlightItems)) {
                return;
            }
            var needSelectItem = needHighlightItems[0];
            this.setSelectItem(needSelectItem.aTag);
        };
        MenuCellTypeBase.prototype.setSelectItem = function (aTag) {
            var selectedItem = MenuCellTypeBase.menuStorage.getSelectStorage(this.getPageName(), this.ID);
            if (selectedItem === aTag) {
                return;
            }
            this.setSelectToStorage(aTag);
            this.setSelectStyle(aTag);
        };
        MenuCellTypeBase.prototype.setSelectStyle = function (aTag) { };
        MenuCellTypeBase.prototype.getNeedHighlightItems = function (items, pageName, result) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (this.hasCommandNavigateToPage(item.CommandList, pageName)) {
                    result.push(item);
                }
                this.getNeedHighlightItems(item.SubItems, pageName, result);
            }
        };
        MenuCellTypeBase.prototype.hasCommandNavigateToPage = function (commandList, pageName) {
            var _a;
            if (commandList && commandList.length > 0) {
                for (var i = 0; i < commandList.length; i++) {
                    var command = commandList[i];
                    if (command && !command["Disabled"] && command["$type"] && command["$type"].indexOf("NavigateCommand") !== -1 && command.PageName === pageName) {
                        return true;
                    }
                    if (command && !command["Disabled"] && command["$type"] && command["$type"].indexOf("ConditionCommand") !== -1) {
                        var conditionPairs = command["ConditionAndCommandPairList"];
                        if (conditionPairs && conditionPairs.length) {
                            for (var i_1 = 0; i_1 < conditionPairs.length; i_1++) {
                                var commands = (_a = conditionPairs[i_1]) === null || _a === void 0 ? void 0 : _a.CommandList;
                                if (commands) {
                                    if (this.hasCommandNavigateToPage(commands, pageName)) {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        };
        MenuCellTypeBase.prototype.isAnyItemSelected = function (items) {
            var menuStoragePageName = this.getPageName();
            var currentHighlightItem = MenuCellTypeBase.menuStorage.getSelectStorage(menuStoragePageName, this.ID);
            if (!currentHighlightItem) {
                return false;
            }
            for (var i = 0; i < items.length; i++) {
                var aTag = items[i].aTag;
                if (aTag === currentHighlightItem) {
                    return true;
                }
            }
            return false;
        };
        MenuCellTypeBase.prototype.setSelectToStorage = function (aTag, isDefaultValue) {
            MenuCellTypeBase.menuStorage.updateSelect(this.getPageName(), this.ID, aTag, isDefaultValue);
        };
        MenuCellTypeBase.prototype.createContent = function () {
            var _this = this;
            Forguncy.Page.bind(Forguncy.PageEvents.PageDefaultDataLoaded, this.pageNavigatedBind, "*");
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            this.adjustMenuStyleBasedOnTemplate(element);
            var horizontalClassName = cellTypeMetaData.Orientation === 0 ? "horizontal" : "";
            var container = $("<div id='" + this.ID + "' class=\"" + this.menuContainerName + " " + horizontalClassName + "\"/>");
            this.rootContainer = container;
            if (!cellTypeMetaData.IsBinding) {
                this.removeNoPermissionItems(cellTypeMetaData);
                this.createMenu(cellTypeMetaData, container);
                this.onDependenceCellValueChanged(function () {
                    _this.initNotifyNumber();
                });
            }
            return container;
        };
        MenuCellTypeBase.prototype.createMenu = function (cellTypeMetaData, container) {
            this.createMenuDom(cellTypeMetaData, container);
            this.initMenuItemStyle(cellTypeMetaData, container);
        };
        MenuCellTypeBase.prototype.initNotifyNumber = function () {
            var notices = this.notifyNodes;
            for (var i = 0; i < notices.length; i++) {
                var item = notices[i];
                var dom = item.dom;
                var formula = item.formula;
                var result = this.evaluateFormula(formula);
                if (result) {
                    dom.text(result);
                    dom.css("display", "block");
                }
                else {
                    dom.css("display", "none");
                }
            }
        };
        MenuCellTypeBase.prototype.destroy = function () {
            Forguncy.Page.unbind(Forguncy.PageEvents.PageDefaultDataLoaded, this.pageNavigatedBind, "*");
        };
        MenuCellTypeBase.prototype.removeNoPermissionItems = function (cellTypeMetaData) {
            var menuPermission = this.getUIPermission(1);
            if (!menuPermission) {
                return;
            }
            var itemsPermissions = menuPermission.Children;
            this.checkMenuPermissions(cellTypeMetaData.Items, itemsPermissions);
        };
        MenuCellTypeBase.prototype.checkMenuPermissions = function (items, permissions) {
            if (!permissions) {
                return;
            }
            for (var i = items.length - 1; i >= 0; i--) {
                var menuItem = items[i];
                if (permissions[i]) {
                    menuItem.CanVisitRoleList = permissions[i].AllowRoles;
                }
                if (this.checkMenuAuthority(menuItem) === false) {
                    items.splice(i, 1);
                }
                else if (menuItem.SubItems) {
                    this.checkMenuPermissions(menuItem.SubItems, permissions[i].Children);
                }
            }
        };
        MenuCellTypeBase.prototype.createMenuDom = function (cellTypeMetaData, container) {
            var items = cellTypeMetaData.Items;
            var levelsStyle = cellTypeMetaData.MenuLevelsStyle;
            this.notifyNodes = [];
            var ul = this.initMenuItems(items, levelsStyle, 0, "level=0");
            if (ul !== null) {
                container.append(ul);
            }
        };
        MenuCellTypeBase.prototype.initMenuItemStyle = function (cellTypeMetaData, container) {
        };
        MenuCellTypeBase.prototype.initMenuItems = function (itemsInfo, levelsStyle, levelIndex, aTag) {
            return null;
        };
        MenuCellTypeBase.prototype.createMenuItemsByLevelInfo = function (levelInfo, levelIndex, parentValue) {
            if (!(levelInfo === null || levelInfo === void 0 ? void 0 : levelInfo.ListViewName)) {
                return;
            }
            var listView = this._bindingListViews[levelIndex];
            if (!listView) {
                return;
            }
            var items = [];
            for (var i = 0; i < listView.getRowCount(); i++) {
                if (levelInfo.MasterListViewReletedColumn) {
                    var masterRelatedValue = listView.getText(i, levelInfo.MasterListViewReletedColumn);
                    if (parentValue !== masterRelatedValue) {
                        continue;
                    }
                }
                var value = this.getListViewText(listView, i, levelInfo.ValueColumn);
                var expand = this.getListViewText(listView, i, levelInfo.IsExpandColumn);
                expand = this.convertExpand(expand);
                var item = {
                    CanVisitRoleList: [],
                    IsBuiltInIconPath: false,
                    IsBuiltInSelectedIconPath: false,
                    IsDefaultItem: false,
                    SubItems: this.createMenuItemsByLevelInfo(levelInfo.SubBindingMenuBaseLevelInfo, levelIndex + 1, value),
                    Text: listView.getText(i, levelInfo.NameColumn),
                    Value: value,
                    aTag: "level=" + levelIndex,
                    IconPath: this.getListViewText(listView, i, levelInfo.IconColumn),
                    SelectedIconPath: this.getListViewText(listView, i, levelInfo.SelectedIconColumn),
                    Expand: expand,
                    Notification: this.getListViewText(listView, i, levelInfo.NotificationInfoColumn)
                };
                items.push(item);
            }
            return items;
        };
        MenuCellTypeBase.prototype.convertExpand = function (expand) {
            if (expand === undefined || expand === null || expand.trim() === "") {
                return undefined;
            }
            if (!expand || expand.trim() === "0" || expand.trim().toLowerCase() === "false") {
                return false;
            }
            return true;
        };
        MenuCellTypeBase.prototype.getListViewText = function (listview, rowIndex, columnName) {
            if (!columnName) {
                return;
            }
            return listview.getText(rowIndex, columnName);
        };
        MenuCellTypeBase.prototype.setHyperLinkStyle = function (itemStyle, style, levelIndex) {
            if (style) {
                if (style.FontSize > 0) {
                    itemStyle.itemFontSize = style.FontSize;
                    itemStyle.itemHeight = style.FontSize * 2;
                }
                if (style.Height > 0) {
                    itemStyle.itemHeight = style.Height;
                }
            }
            itemStyle.itemHeight = Math.max(itemStyle.itemHeight, 20);
            var height = this.CellElement.Height || this.CellElement.FullHeight;
            if (levelIndex === 0 && itemStyle.itemHeight > height) {
                itemStyle.itemHeight = height;
            }
            itemStyle.iconWidth = itemStyle.itemHeight - 12;
            itemStyle.iconHeight = itemStyle.itemHeight;
            if (style) {
                if (style.IconWidth > 0) {
                    itemStyle.iconWidth = style.IconWidth;
                }
                if (style.IconHeight > 0) {
                    itemStyle.iconHeight = style.IconHeight;
                }
            }
            itemStyle.iconHeight = itemStyle.iconHeight > itemStyle.itemHeight ? itemStyle.itemHeight : itemStyle.iconHeight;
        };
        MenuCellTypeBase.prototype.checkMenuAuthority = function (itemInfo) {
            return this.checkRoleAuthority(itemInfo.CanVisitRoleList);
        };
        MenuCellTypeBase.prototype.setMenuLevelStyle = function (ul, style, levelIndex) {
            var target = ul.find(">li>a");
            if (style) {
                if (style.BackColor) {
                    target.css("background", Forguncy.ConvertToCssColor(style.BackColor));
                    target.css("background-origin", "border-box");
                }
                if (style.ForeColor) {
                    target.css("color", Forguncy.ConvertToCssColor(style.ForeColor));
                    $(".arrow", target).attr("fill", Forguncy.ConvertToCssColor(style.ForeColor));
                }
                if (style.FontFamily) {
                    target.css("font-family", "'" + style.FontFamily + "'");
                }
                if (style.FontSize && style.FontSize > 0 && style.FontSize > style.Height) {
                    target.css("line-height", "2");
                    target.css("font-size", style.FontSize + "px");
                }
                if (style.SelectedBackColor) {
                    var cssSelector = "#" + this.ID + " ul[level='" + levelIndex + "'] > li > a.selected";
                    Forguncy.MenuStyleUtils.InsertBackColorRule(this.rootContainer, cssSelector, Forguncy.ConvertToCssColor(style.SelectedBackColor));
                }
                if (style.SelectedForeColor) {
                    var cssSelector = "#" + this.ID + " ul[level='" + levelIndex + "'] > li > a.selected";
                    var arrawCssSelector = "#" + this.ID + " ul[level='" + levelIndex + "'] > li > a.selected g.arrowIcon";
                    Forguncy.MenuStyleUtils.InsertForeColorRule(this.rootContainer, cssSelector, Forguncy.ConvertToCssColor(style.SelectedForeColor));
                    Forguncy.MenuStyleUtils.InsertArrowFillColorRule(this.rootContainer, arrawCssSelector, Forguncy.ConvertToCssColor(style.SelectedForeColor));
                }
            }
        };
        MenuCellTypeBase.prototype.setFirstItemLevelStyle = function (cellTypeMetaData, container) {
            container.find("> ul > li").css("display", "inline-block");
            container.find("> ul > li").css("width", 100 / cellTypeMetaData.Items.length + "%");
            return container;
        };
        MenuCellTypeBase.prototype.adjustMenuStyleBasedOnTemplate = function (element) {
            var cellType = element.CellType;
            if (this.CellElement.StyleInfo && this.CellElement.StyleInfo.Foreground) {
                for (var i = 0; i < cellType.MenuLevelsStyle.length; i++) {
                    var currentMenuLevelStyle = cellType.MenuLevelsStyle[i];
                    if (!currentMenuLevelStyle.ForeColor) {
                        currentMenuLevelStyle.ForeColor = this.CellElement.StyleInfo.Foreground;
                    }
                }
            }
            if (!element.StyleTemplate) {
                return;
            }
            if (!cellType.TemplateKey) {
                return null;
            }
            var styles = element.StyleTemplate.Styles;
            var cellParts = Object.keys(styles);
            for (var i = 0; i < cellParts.length; i++) {
                var partName = cellParts[i];
                var partStyle = styles[partName];
                this.mergeMenuItemStyle(partStyle, cellType.MenuLevelsStyle[i]);
            }
        };
        MenuCellTypeBase.prototype.mergeMenuItemStyle = function (templatePartStyle, originalStyle) {
            if (!originalStyle) {
                return;
            }
            for (var key in templatePartStyle) {
                var value = templatePartStyle[key];
                var style = value;
                if (key === "NormalStyle") {
                    if (style.Background && !originalStyle.BackColor) {
                        originalStyle.BackColor = Forguncy.ConvertToCssColor(style.Background);
                    }
                    if (style.FontColor && !originalStyle.ForeColor) {
                        originalStyle.ForeColor = Forguncy.ConvertToCssColor(style.FontColor);
                    }
                }
                else if (key === "HoverStyle") {
                    if (style.Background && !originalStyle.HoverBackColor) {
                        originalStyle.HoverBackColor = Forguncy.ConvertToCssColor(style.Background);
                    }
                    if (style.FontColor && !originalStyle.HoverForeColor) {
                        originalStyle.HoverForeColor = Forguncy.ConvertToCssColor(style.FontColor);
                    }
                }
                else if (key === "SelectedStyle") {
                    if (style.Background && !originalStyle.SelectedBackColor) {
                        originalStyle.SelectedBackColor = Forguncy.ConvertToCssColor(style.Background);
                    }
                    if (style.FontColor && !originalStyle.SelectedForeColor) {
                        originalStyle.SelectedForeColor = Forguncy.ConvertToCssColor(style.FontColor);
                    }
                }
            }
        };
        MenuCellTypeBase.prototype.getPageName = function () {
            return this.IsInMasterPage === true ? Forguncy.Page.getMasterPageName() : Forguncy.Page.getPageName();
        };
        MenuCellTypeBase.prototype.createIconHtml = function (iconPath, iconColor, itemHeight, iconWidth, iconHeight, isBuiltIn, isOldPath) {
            var imgHtml = $("<div elemType='icon'></div>");
            imgHtml.css("width", iconWidth + "px");
            imgHtml.css("height", iconHeight + "px");
            imgHtml.css("background-size", "contain");
            imgHtml.css("background-position", "center");
            imgHtml.css("background-repeat", "no-repeat");
            imgHtml.css("margin", "auto");
            imgHtml.css("line-height", "normal");
            if (isOldPath && !isBuiltIn) {
                imgHtml.css("background-image", "url(\"" + Forguncy.Helper.SpecialPath.getUploadFileFolderPathInDesigner() + "ForguncyCustomMenu/IconImages/" + encodeURIComponent(iconPath) + "\")");
            }
            else if (iconPath) {
                var metaData = this.CellElement.CellType;
                if (metaData.IsBinding) {
                    var src = Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer() + iconPath;
                    imgHtml.css("background-image", "url(\"" + src + "\")");
                }
                else {
                    var src = void 0;
                    if (isBuiltIn) {
                        src = Forguncy.Helper.SpecialPath.getBuiltInImageFolderPath() + iconPath;
                    }
                    else {
                        src = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + encodeURIComponent(iconPath);
                    }
                    if (this.IsSvg(iconPath)) {
                        $.get(src, function (data) {
                            var svg = $(data.documentElement);
                            Forguncy.ImageHelper.preHandleSvg(svg, iconColor);
                            imgHtml.append(svg);
                        });
                    }
                    else {
                        imgHtml.css("background-image", "url(\"" + src + "\")");
                    }
                }
            }
            return imgHtml;
        };
        MenuCellTypeBase.prototype.IsSvg = function (name) {
            return name && name.length > 4 &&
                (name.substr(name.length - 4, 4).toLowerCase() === ".svg" ||
                    name.toLowerCase().indexOf(".svg?v=") > 0);
        };
        MenuCellTypeBase.prototype.executeOnClickCommand = function (itemInfo) {
            var _a;
            var cellTypeMetaData = this.CellElement.CellType;
            if (cellTypeMetaData.IsBinding) {
                var clickCommand = cellTypeMetaData.ClickCommand;
                if (!clickCommand) {
                    return false;
                }
                var context = this.getFormulaCalcContext();
                CellHelper.setValueToCell(context, clickCommand.ValueTo, itemInfo.Value);
                CellHelper.setValueToCell(context, clickCommand.NameTo, itemInfo.Text);
                var level = this.parseLevel(itemInfo.aTag);
                CellHelper.setValueToCell(context, clickCommand.LevelTo, level + 1);
                this.executeCommand(clickCommand.CommandList);
            }
            else {
                if (!((_a = itemInfo.CommandList) === null || _a === void 0 ? void 0 : _a.length)) {
                    return false;
                }
                this.executeCommand(itemInfo.CommandList);
            }
            return true;
        };
        MenuCellTypeBase.prototype.parseLevel = function (aTag) {
            var substr = aTag.substring(aTag.lastIndexOf("level"));
            return Number(substr.match(/[0-9]+/)[0]);
        };
        MenuCellTypeBase.prototype.onLoad = function () {
            this.initializeProperties();
        };
        MenuCellTypeBase.prototype.initializeProperties = function () {
            var _this = this;
            var metadata = this.CellElement.CellType;
            if (!metadata.IsBinding) {
                this.setStyleAfterLoad();
                return;
            }
            var level = metadata.BindingMenuLevelInfo;
            while (level === null || level === void 0 ? void 0 : level.ListViewName) {
                var listView = Forguncy.Page.getListView(level.ListViewName, true);
                this._bindingListViews.push(listView);
                ListViewSelectionChangedCapture.regist(listView, function () {
                    _this._loopInvoker.invokeable = true;
                });
                level = level.SubBindingMenuBaseLevelInfo;
            }
            this._loopInvoker.start(function () {
                _this.refreshBindingMenu();
            });
        };
        MenuCellTypeBase.prototype.refreshBindingMenu = function () {
            this.rootContainer.empty();
            var metadata = this.CellElement.CellType;
            metadata.Items = this.createMenuItemsByLevelInfo(metadata.BindingMenuLevelInfo, 0);
            this.createMenu(this.CellElement.CellType, this.rootContainer);
            this.setStyleAfterLoad();
        };
        MenuCellTypeBase.prototype.setStyleAfterLoad = function () {
        };
        MenuCellTypeBase.menuStorage = new MenuStorageOption();
        return MenuCellTypeBase;
    }(Forguncy.Plugin.CellTypeBaseWithSimplebar));
    Forguncy.MenuCellTypeBase = MenuCellTypeBase;
    var ListViewSelectionChangedCapture = (function () {
        function ListViewSelectionChangedCapture() {
        }
        ListViewSelectionChangedCapture.regist = function (listView, notify) {
            listView.bind(Forguncy.ListViewEvents.Reloaded, function () {
                notify && notify();
            });
            listView.bind(Forguncy.ListViewEvents.ValueChanged, function () {
                notify && notify();
            });
        };
        return ListViewSelectionChangedCapture;
    }());
    var LoopInvoker = (function () {
        function LoopInvoker() {
            this.interval = 50;
        }
        LoopInvoker.prototype.start = function (func, invokeable) {
            var _this = this;
            if (invokeable === void 0) { invokeable = false; }
            this.invokeable = invokeable;
            setInterval(function () {
                if (_this.invokeable) {
                    _this.invokeable = false;
                    func && func();
                }
            }, this.interval);
        };
        return LoopInvoker;
    }());
    var CellHelper = (function () {
        function CellHelper() {
        }
        CellHelper.setValueToCell = function (context, cellLocationFormula, value) {
            if (!cellLocationFormula) {
                return;
            }
            var cellLocation = Forguncy.Helper.getCellLocation(cellLocationFormula, context);
            var cell = Forguncy.Page.getCellByLocation(cellLocation);
            if (cell) {
                cell.setValue(value);
            }
            else {
                Forguncy.CommandHelper.setVariableValue(cellLocationFormula, value);
            }
        };
        return CellHelper;
    }());
    Forguncy.CellHelper = CellHelper;
})(Forguncy || (Forguncy = {}));
