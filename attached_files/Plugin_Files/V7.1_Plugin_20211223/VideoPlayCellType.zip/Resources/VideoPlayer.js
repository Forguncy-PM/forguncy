﻿var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Player;
(function (Player) {
    var Preload;
    (function (Preload) {
        Preload[Preload["Auto"] = 0] = "Auto";
        Preload[Preload["Metadata"] = 1] = "Metadata";
        Preload[Preload["None"] = 2] = "None";
    })(Preload || (Preload = {}));
    var PlayerBase = (function (_super) {
        __extends(PlayerBase, _super);
        function PlayerBase() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        PlayerBase.prototype.getTagName = function () {
            return null;
        };
        PlayerBase.prototype.createContent = function () {
            var _this = this;
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var videoInfo = cellTypeMetaData.VideoInfos;
            var controls = cellTypeMetaData.Controls;
            var autoplay = cellTypeMetaData.Autoplay;
            var loop = cellTypeMetaData.Loop;
            var notAllowDownload = cellTypeMetaData.NotAllowDownload;
            var notAllowFullScreen = cellTypeMetaData.NotAllowFullScreen;
            var disablePictureInPicture = cellTypeMetaData.DisablePictureInPicture;
            if (!videoInfo || videoInfo.length <= 0) {
                return $("<div id=" + this.ID + "></div>");
            }
            var tagName = this.getTagName();
            var VideoDiv = $("<div id='" + this.ID + tagName + "_container' style='width:100%;height:100%;align-items:center;justify-content:center;display:flex;'></div>");
            var video = $("<" + tagName + " id='" + this.ID + "_" + tagName + "' width='100%' height='100%'></" + tagName + ">");
            this._video = video;
            this._PreSrc = '';
            if (Forguncy.Platform.isIE()) {
                if (this._video[0]) {
                    var video_1 = this._video[0];
                    video_1.onended = function () {
                        video_1.pause();
                    };
                }
            }
            if (controls) {
                video.attr("controls", "controls");
            }
            if (autoplay) {
                video.attr("autoplay", "autoplay");
            }
            if (loop) {
                video.attr("loop", "loop");
            }
            if (disablePictureInPicture) {
                video.attr("disablePictureInPicture", "disablePictureInPicture");
            }
            if (notAllowDownload || notAllowFullScreen) {
                video.attr("controlslist", [notAllowDownload ? "nodownload" : null, notAllowFullScreen ? "nofullscreen " : null].join(" "));
            }
            switch (cellTypeMetaData.Preload) {
                case Preload.Metadata:
                    video.attr("preload", "metadata");
                    break;
                case Preload.None:
                    video.attr("preload", "none");
                    break;
                default:
                    video.attr("preload", "auto");
            }
            this.onDependenceCellValueChanged(function () {
                _this.updateAttributes();
                if (document.pictureInPictureEnabled) {
                    if (document.pictureInPictureElement) {
                        document.exitPictureInPicture && document.exitPictureInPicture();
                    }
                }
            });
            VideoDiv.append(video);
            return VideoDiv;
        };
        PlayerBase.prototype.onPageLoaded = function () {
            this.updateAttributes();
        };
        PlayerBase.prototype.destroy = function () {
            this._video = null;
        };
        PlayerBase.prototype.updateAttributes = function () {
            this.updateVideoSrc();
            this.updatePoserSrc();
        };
        PlayerBase.prototype.updatePoserSrc = function () {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var videoInfo = cellTypeMetaData.VideoInfos;
            if (!videoInfo) {
                return;
            }
            var coverPath = videoInfo[0].ExternalCoverPathFormula;
            var posterSrc = this.getCoverPath(coverPath);
            if (posterSrc) {
                this._video.attr('poster', posterSrc);
            }
            else {
                this._video[0].removeAttribute('poster');
            }
        };
        PlayerBase.prototype.updateVideoSrc = function () {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var videoInfo = cellTypeMetaData.VideoInfos;
            if (!videoInfo) {
                return;
            }
            var externalPath = videoInfo[0].ExternalVideoPathFormula;
            var src;
            if (externalPath !== "" && externalPath !== null && externalPath !== undefined) {
                src = this.getExternalPath(externalPath).path;
            }
            else {
                src = this.getVideoPath(videoInfo[0].VideoPath);
            }
            if (this._PreSrc === src) {
                return;
            }
            this._PreSrc = src;
            if (!src) {
                var videoDom = this._video[0];
                videoDom.pause();
                videoDom.removeAttribute('src');
                videoDom.load();
            }
            else {
                this._video.attr('src', src);
            }
        };
        PlayerBase.prototype.getExternalPath = function (externalPath) {
            var originPath = this.evaluateFormula(externalPath);
            var path = typeof originPath === 'string' ? originPath : '';
            if (this.isAttachment(path)) {
                path = this.getAttachmentUrl(path);
            }
            return { path: path, isAttachment: this.isAttachment(originPath) };
        };
        PlayerBase.prototype.getAttachmentUrl = function (src) {
            var urls = src.split("|");
            if (urls.length === 0) {
                return src;
            }
            var url = urls[0];
            var fileUrl = Forguncy.Helper.SpecialPath.getBaseUrl() + Forguncy.ModuleLoader.getCdnUrl("Upload/" + encodeURIComponent(url));
            return fileUrl;
        };
        PlayerBase.prototype.isAttachment = function (src) {
            if (typeof src !== "string") {
                return false;
            }
            src = src.toLowerCase();
            if (src.indexOf("http") === 0) {
                return false;
            }
            if (src.length < 37 || src[36] !== "_") {
                return false;
            }
            return true;
        };
        PlayerBase.prototype.getCoverPath = function (cover) {
            if (!cover) {
                return null;
            }
            var _a = this.getExternalPath(cover), externalPathValue = _a.path, isAttachment = _a.isAttachment;
            if (externalPathValue) {
                if (isAttachment) {
                    return externalPathValue;
                }
                if (externalPathValue.indexOf("http://") === 0 || externalPathValue.indexOf("https://") === 0) {
                    return externalPathValue;
                }
                if (externalPathValue.indexOf("GeneratedResources/Images/GenerateImages/ImageCellType/") > -1) {
                    return externalPathValue;
                }
                return Forguncy.Helper.SpecialPath.getBaseUrl() + "Upload/" + externalPathValue;
            }
            else {
                return null;
            }
        };
        PlayerBase.prototype.getVideoPath = function (video) {
            if (video) {
                return Forguncy.Helper.SpecialPath.getUploadFileFolderPathInDesigner() + "VideoPlayer/Videos/" + video;
            }
        };
        PlayerBase.prototype.getValueFromElement = function () {
            return null;
        };
        PlayerBase.prototype.setValueToElement = function () {
        };
        return PlayerBase;
    }(Forguncy.Plugin.CellTypeBase));
    Player.PlayerBase = PlayerBase;
    var VideoPlayer = (function (_super) {
        __extends(VideoPlayer, _super);
        function VideoPlayer() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        VideoPlayer.prototype.getTagName = function () {
            return "video";
        };
        return VideoPlayer;
    }(PlayerBase));
    Player.VideoPlayer = VideoPlayer;
    var AudioPlayer = (function (_super) {
        __extends(AudioPlayer, _super);
        function AudioPlayer() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        AudioPlayer.prototype.getTagName = function () {
            return "audio";
        };
        return AudioPlayer;
    }(PlayerBase));
    Player.AudioPlayer = AudioPlayer;
    var OperateType;
    (function (OperateType) {
        OperateType[OperateType["ChangePlaySpeed"] = 0] = "ChangePlaySpeed";
        OperateType[OperateType["Toggle"] = 1] = "Toggle";
        OperateType[OperateType["Stop"] = 2] = "Stop";
        OperateType[OperateType["Play"] = 3] = "Play";
        OperateType[OperateType["Pause"] = 4] = "Pause";
    })(OperateType || (OperateType = {}));
    var SpeedType;
    (function (SpeedType) {
        SpeedType[SpeedType["x050"] = 0] = "x050";
        SpeedType[SpeedType["x075"] = 1] = "x075";
        SpeedType[SpeedType["x100"] = 2] = "x100";
        SpeedType[SpeedType["x125"] = 3] = "x125";
        SpeedType[SpeedType["x150"] = 4] = "x150";
        SpeedType[SpeedType["x200"] = 5] = "x200";
    })(SpeedType || (SpeedType = {}));
    var MediaControlCommand = (function (_super) {
        __extends(MediaControlCommand, _super);
        function MediaControlCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MediaControlCommand.prototype.execute = function () {
            var _a;
            var commandSettings = this.CommandParam;
            var path = this.getCellLocation(commandSettings.MediaCell);
            var videoLabel = $("#r" + path.Row + "c" + path.Column + this.CommandExecutingInfo.runTimePageName + "_video");
            var audioLabel = $("#r" + path.Row + "c" + path.Column + this.CommandExecutingInfo.runTimePageName + "_audio");
            var mediaDom = (videoLabel[0] || audioLabel[0]);
            if (!mediaDom) {
                return console.warn("media player not found!");
            }
            var speedList = [0.5, 0.75, 1, 1.25, 1.5, 2];
            var targetSpeed = speedList[(_a = commandSettings.Speed) !== null && _a !== void 0 ? _a : 2];
            switch (commandSettings.OperateType) {
                case OperateType.ChangePlaySpeed:
                    mediaDom.playbackRate = targetSpeed;
                    break;
                case OperateType.Stop:
                    mediaDom.pause();
                    if (!isNaN(mediaDom.duration)) {
                        mediaDom.currentTime = 0;
                    }
                    break;
                case OperateType.Toggle:
                    if (mediaDom.paused) {
                        mediaDom.play();
                    }
                    else {
                        mediaDom.pause();
                    }
                    break;
                case OperateType.Play:
                    mediaDom.play();
                    break;
                case OperateType.Pause:
                    mediaDom.pause();
                    break;
                default:
                    console.error('OperateType Not found');
                    return;
            }
        };
        return MediaControlCommand;
    }(Forguncy.Plugin.CommandBase));
    Player.MediaControlCommand = MediaControlCommand;
    var GetMediaInfoCommand = (function (_super) {
        __extends(GetMediaInfoCommand, _super);
        function GetMediaInfoCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        GetMediaInfoCommand.prototype.execute = function () {
            var commandSettings = this.CommandParam;
            var path = this.getCellLocation(commandSettings.MediaCell);
            var PlayStateReturnCell = this.getCellLocation(commandSettings.PlayStateReturnCell);
            var returnCell = Forguncy.Page.getCellByLocation(PlayStateReturnCell);
            var videoLabel = $("#r" + path.Row + "c" + path.Column + this.CommandExecutingInfo.runTimePageName + "_video");
            var audioLabel = $("#r" + path.Row + "c" + path.Column + this.CommandExecutingInfo.runTimePageName + "_audio");
            var mediaDom = (videoLabel[0] || audioLabel[0]);
            if (!mediaDom) {
                return console.warn("media player not found!");
            }
            var returnValue = mediaDom.paused ? 'paused' : 'playing';
            if (!returnCell) {
                Forguncy.CommandHelper.setVariableValue(commandSettings.PlayStateReturnCell, returnValue);
                return;
            }
            returnCell.setValue(returnValue);
        };
        return GetMediaInfoCommand;
    }(Forguncy.Plugin.CommandBase));
    Player.GetMediaInfoCommand = GetMediaInfoCommand;
})(Player || (Player = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("VideoPlayer.VideoPlayer, VideoPlayer", Player.VideoPlayer);
Forguncy.Plugin.CellTypeHelper.registerCellType("VideoPlayer.AudioPlayer, VideoPlayer", Player.AudioPlayer);
Forguncy.Plugin.CommandFactory.registerCommand("VideoPlayer.MediaControlCommand, VideoPlayer", Player.MediaControlCommand);
Forguncy.Plugin.CommandFactory.registerCommand("VideoPlayer.GetMediaInfoCommand, VideoPlayer", Player.GetMediaInfoCommand);
