var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Gantt;
(function (Gantt) {
    var GanttCellType = (function (_super) {
        __extends(GanttCellType, _super);
        function GanttCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this._selectedRow = 0;
            _this._isListViewChange = true;
            _this._enabled = true;
            return _this;
        }
        GanttCellType.prototype.createContent = function () {
            var container = $("<div id=\"" + this.ID + "\" style='height: 100%; width: 100%;'></div>");
            this._container = container;
            return container;
        };
        GanttCellType.prototype.getGanttData = function () {
            var result = {
                "tasks": [],
                "selectedRow": 0,
                "deletedTaskIds": [],
                "resources": [
                    { "id": "tmp_1", "name": "Resource 1" },
                    { "id": "tmp_2", "name": "Resource 2" },
                    { "id": "tmp_3", "name": "Resource 3" },
                    { "id": "tmp_4", "name": "Resource 4" }
                ],
                "roles": [
                    { "id": "tmp_1", "name": "Project Manager" },
                    { "id": "tmp_2", "name": "Worker" },
                    { "id": "tmp_3", "name": "Stakeholder" },
                    { "id": "tmp_4", "name": "Customer" }
                ],
                "zoom": "1M",
                "canWrite": true,
                "canAdd": true,
                "canWriteOnParent": true,
                "cannotCloseTaskIfIssueOpen": false,
                "canAddIssue": false,
                "canDelete": true
            };
            var canEdit = this._ganttPermission;
            result.canWrite = canEdit;
            result.canAdd = canEdit;
            result.canWriteOnParent = canEdit;
            result.canDelete = canEdit;
            result.selectedRow = this._selectedRow;
            var tasks = GanttTaskConvert.getTasksFromListViewToGanttChart(this._listView, this._ganttListViewInfo);
            tasks.forEach(function (task) {
                task.canWrite = canEdit;
                task.canAdd = canEdit;
                task.canDelete = canEdit;
                task.canAddIssue = canEdit;
            });
            result.tasks = tasks;
            return result;
        };
        GanttCellType.prototype.onLoad = function () {
            this.initializeProperties();
        };
        GanttCellType.prototype.initializeProperties = function () {
            var _this = this;
            var GanttCellTypeData = this.CellElement.CellType;
            this._metadata = GanttCellTypeData;
            this._ganttListViewInfo = this._metadata.GanttListViewInfo;
            this._listViewName = this._ganttListViewInfo.ListViewName;
            this._ganttTaskSetColInfo = this._ganttListViewInfo.GanttTaskSetColInfo;
            this._listViewBase = Forguncy.ListviewBase.getListview(this._listViewName, this.runTimePageName);
            this._listView = Forguncy.Page.getListView(this._listViewName, true);
            ListViewSelectionChangedCapture.regist(this._listView, function () {
                if (!_this._isListViewChange) {
                    return;
                }
                _this._loadDataToGanttData();
            });
            this._readOnly = !!this._metadata.hasOwnProperty("ReadOnly");
            this.updateGanttPermission();
            if (this._ganttObj == null) {
                this._ganttObj = new GanttMaster();
                var showButtonBar = this._metadata.hasOwnProperty("ShowButtonBar") ? this._metadata.ShowButtonBar : false;
                var initialCalculationMode = this._metadata.hasOwnProperty("InitialCalculationMode") ? this._metadata.InitialCalculationMode : InitialCalculationModeModel.UseStartAndDuration;
                this._ganttObj.styleSettings = {
                    showButtonBar: showButtonBar
                };
                this._ganttObj.initialCalculationMode = initialCalculationMode;
                this._ganttObj.set100OnClose = true;
                this._ganttObj.shrinkParent = true;
                this._ganttObj.resourceUrl = this.getResourceUrl();
                this._ganttObj.hasSetCommands = this._metadata.TaskCommandList ? this._metadata.TaskCommandList.length > 0 : false;
                this._ganttObj.hasSetStatusCol = this._ganttTaskSetColInfo.StatusCol ? true : false;
                this._ganttObj.ganttTaskSetColInfo = this._metadata.GanttListViewInfo.GanttTaskSetColInfo;
                this._ganttObj.setCalendarHolidays(GanttCalendarConvert.getHolidaysFromTableToGanttChart(this._metadata.GanttCalendarInfo, this.getFormulaCalcContext()));
                this._ganttObj.init(this._container);
                this._ganttObj.checkpoint();
                this._ganttObj.bindTaskRowClickEvent = function (task) {
                    var rowIndex = ListViewHelper.getRowIndex(_this._listView, _this._ganttTaskSetColInfo.IdCol, task.id);
                    if (!Utilities.isEmpty(rowIndex) && rowIndex >= 0) {
                        _this._listView.selectRow(rowIndex);
                        _this._selectedRow = rowIndex;
                    }
                };
                this._ganttObj.bindTaskRowDblClickEvent = function (task) {
                    var taskCommandList = GanttCellTypeData.TaskCommandList;
                    _this.executeCommand(taskCommandList);
                };
                this._ganttObj.bindSaveGanttDataEvent = function (task) {
                    _this._isListViewChange = false;
                    _this.saveGanttDataToListView();
                    Forguncy.UpdateListviewCommand.updateListview(_this._listViewBase, function () {
                        Forguncy.NormalCellBindingManager.reloadData(_this._listViewBase.getDataTableName(), true);
                        Forguncy.ForguncyData.getRelatedTableWithForeignKey(_this._listViewBase.getDataTableName()).forEach(function (table) {
                            Forguncy.NormalCellBindingManager.reloadData(table, true);
                        });
                        _this._isListViewChange = true;
                    });
                };
            }
            this.refresh();
        };
        GanttCellType.prototype.refresh = function () {
            var _this = this;
            if (this._listView._grid && this._listView._grid.lastDataRowIndexInView >= 0) {
                this._loadDataToGanttData();
            }
            else {
                setTimeout(function () {
                    _this.refresh();
                }, 100);
            }
        };
        GanttCellType.prototype._loadDataToGanttData = function () {
            var project = this.getGanttData();
            this._ganttObj.loadProject(project);
        };
        GanttCellType.prototype.disable = function () {
            _super.prototype.disable.call(this);
            this._enabled = false;
            this._container.addClass("pluginGantt_disable");
        };
        GanttCellType.prototype.enable = function () {
            _super.prototype.enable.call(this);
            this._enabled = true;
            this._container.removeClass("pluginGantt_disable");
        };
        GanttCellType.prototype.setReadOnly = function (value) {
            _super.prototype.setReadOnly.call(this, value);
            this._readOnly = value;
            this.updateGanttPermission();
        };
        GanttCellType.prototype.updateGanttPermission = function () {
            this._ganttPermission = this._enabled && !this._readOnly ? true : false;
            if (!this._ganttObj) {
                return;
            }
            this._ganttObj.loadProjectPermissions(this._ganttPermission);
        };
        GanttCellType.prototype.saveGanttDataToListView = function () {
            var ganttData = this._ganttObj.saveProject();
            var oldTasks = GanttTaskConvert.getTasksFromListViewToGanttChart(this._listView, this._ganttListViewInfo);
            var newTasks = GanttTaskConvert.getTasksFromGanttChartToListView(ganttData, this._ganttListViewInfo);
            var editRows = [];
            var addRows = [];
            var deleteRows = [];
            var defaultIdCol = GanttTaskConvert.GanntTaskRequiredColInfo.IdCol;
            var oldTaskIds = oldTasks.map(function (oldTask) { return oldTask[defaultIdCol]; });
            var setIdCol = this._ganttTaskSetColInfo.IdCol;
            var newTaskIds = newTasks.map(function (newTask) { return newTask[setIdCol]; });
            newTasks.forEach(function (newTask) {
                var idValue = newTask[setIdCol];
                var isAdd = oldTaskIds.indexOf(idValue) === -1;
                if (isAdd) {
                    newTask.id = undefined;
                    addRows.push(newTask);
                }
                else {
                    editRows.push({
                        primaryKey: {
                            idCol: setIdCol,
                            idValue: idValue
                        },
                        values: newTask
                    });
                }
            });
            oldTasks.forEach(function (oldTask) {
                var idValue = oldTask[defaultIdCol];
                var isDelete = newTaskIds.indexOf(idValue) === -1;
                if (isDelete) {
                    deleteRows.push({
                        idCol: setIdCol,
                        idValue: idValue
                    });
                }
            });
            var callback = function () { };
            var errorCallback = function () { };
            var ModifyData = {
                editRows: editRows,
                addRows: addRows,
                deleteRows: deleteRows
            };
            ListViewHelper.modifyRows(this._listView, ModifyData);
        };
        GanttCellType.prototype.getResourceUrl = function () {
            try {
                throw new Error();
            }
            catch (resourceUrlError) {
                var stack = resourceUrlError.stack || '';
                var rgx = /(?:http|https|file):\/\/.*?\/.+?.js/;
                var pluginURL = (rgx.exec(stack) || [])[0] || '';
                var pluginBase = pluginURL.split("/").slice(3, -1).join("/");
                var resourceUrl = "/" + pluginBase + "/robicch-jQueryGantt/";
                return resourceUrl;
            }
        };
        return GanttCellType;
    }(Forguncy.Plugin.CellTypeBase));
    Gantt.GanttCellType = GanttCellType;
    var GanttTaskConvert = (function () {
        function GanttTaskConvert() {
        }
        GanttTaskConvert.getTasksFromListViewToGanttChart = function (listView, ganttListViewInfo) {
            var _this = this;
            var rowsData = this.getRowsData(listView);
            var mergedColumnInfos = listView.getMergedColumnInfos();
            var columnNameWithIndex = this.getColumnNameWithIndex(mergedColumnInfos);
            var tasks = rowsData.map(function (row) {
                var values = row.Values;
                var task = _this.creatTaskFromListViewToGanttChart(values, columnNameWithIndex, ganttListViewInfo);
                return task;
            });
            tasks.sort(function (a, b) {
                return (a.order - b.order);
            });
            return tasks;
        };
        GanttTaskConvert.getTasksFromGanttChartToListView = function (ganttData, ganttListViewInfo) {
            var _this = this;
            var newTasks = ganttData.tasks;
            newTasks.forEach(function (task, index) {
                task.order = index + 1;
            });
            var tasks = newTasks.map(function (oldTask) {
                var task = _this.creatTaskFromGanttChartToListView(oldTask, ganttListViewInfo);
                return task;
            });
            return tasks;
        };
        GanttTaskConvert.creatTaskFromListViewToGanttChart = function (values, columnNameWithIndex, ganttListViewInfo) {
            var _this = this;
            var ganttTaskSetColInfo = ganttListViewInfo.GanttTaskSetColInfo;
            var task = {};
            Object.keys(this.GanntTaskRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                var defaultColName = _this.GanntTaskRequiredColInfo[col];
                var index = columnNameWithIndex[setColName];
                var value = values[index];
                task[defaultColName] = _this.formatTaskValueFromListViewToGanttChart(value, col, ganttListViewInfo);
            }));
            Object.keys(this.GanntTaskNotRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                if (!Utilities.isEmpty(setColName)) {
                    var defaultColName = _this.GanntTaskNotRequiredColInfo[col];
                    var index = columnNameWithIndex[setColName];
                    var value = values[index];
                    task[defaultColName] = _this.formatTaskValueFromListViewToGanttChart(value, col, ganttListViewInfo);
                }
            }));
            this.setTaskCollapsedFromListViewToGanttChart(task, ganttListViewInfo, ganttTaskSetColInfo);
            return task;
        };
        GanttTaskConvert.creatTaskFromGanttChartToListView = function (tasks, ganttListViewInfo) {
            var _this = this;
            var ganttTaskSetColInfo = ganttListViewInfo.GanttTaskSetColInfo;
            var task = {};
            Object.keys(this.GanntTaskRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                var defaultColName = _this.GanntTaskRequiredColInfo[col];
                var value = tasks[defaultColName];
                task[setColName] = _this.formatTaskValueFromGanttChartToListView(value, col, ganttListViewInfo);
            }));
            Object.keys(this.GanntTaskNotRequiredColInfo).forEach((function (col) {
                var setColName = ganttTaskSetColInfo[col];
                if (!Utilities.isEmpty(setColName)) {
                    var defaultColName = _this.GanntTaskNotRequiredColInfo[col];
                    var value = tasks[defaultColName];
                    task[setColName] = _this.formatTaskValueFromGanttChartToListView(value, col, ganttListViewInfo);
                }
            }));
            return task;
        };
        GanttTaskConvert.getRowsData = function (listView) {
            var rowsData = [];
            var rowCount = listView.getRowCount();
            if (rowCount === 0) {
                return [];
            }
            var columnInfos = listView.getMergedColumnInfos();
            var mergedColumnCount = columnInfos.length;
            for (var rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                var values = [];
                for (var colIndex = 0; colIndex < mergedColumnCount; colIndex++) {
                    var value = listView.getValue(rowIndex, colIndex);
                    values.push(Utilities.isEmpty(value) ? null : value);
                }
                rowsData.push({
                    RowIndex: rowIndex,
                    Values: values
                });
            }
            return rowsData;
        };
        GanttTaskConvert.getColumnNameWithIndex = function (mergedColumnInfos) {
            var columnNamesWithIndex = {};
            for (var i = 0; i < mergedColumnInfos.length; i++) {
                var columnName = mergedColumnInfos[i].ColumnName;
                if (Utilities.isEmpty(columnName)) {
                    continue;
                }
                columnNamesWithIndex[columnName] = i;
            }
            return columnNamesWithIndex;
        };
        GanttTaskConvert.formatTaskValueFromListViewToGanttChart = function (value, defaultColName, ganttListViewInfo) {
            switch (defaultColName) {
                case "IdCol": return value;
                case "OrderCol": return parseInt(value);
                case "LevelCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "NameCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "DependsCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "StartCol": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "EndCol": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "DurationCol": return Utilities.isEmpty(value) ? 2 : parseInt(value);
                case "ProgressCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "DescriptionCol": return Utilities.isEmpty(value) ? "" : value;
                case "CodeCol": return Utilities.isEmpty(value) ? "" : value;
                case "StartIsMilestoneCol": return Boolean(value);
                case "EndIsMilestoneCol": return Boolean(value);
                case "ActualStartCol": return Utilities.isEmpty(value) ? null : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "ActualEndCol": return Utilities.isEmpty(value) ? null : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "AssigsCol": return Utilities.isEmpty(value) ? "" : value;
                case "CollapsedCol": return Boolean(value);
                case "StatusCol": return Utilities.isEmpty(value) || Utilities.isEmpty(ganttListViewInfo.GanttStatusSetInfo) ? "" : this.formatTaskStatusValueFromListViewToGanttChart(value, ganttListViewInfo.GanttStatusSetInfo);
                case "CanWriteCol": return Boolean(value);
                case "CanAddCol": return Boolean(value);
                case "CanDeleteCol": return Boolean(value);
                case "CanAddIssueCol": return Boolean(value);
                default: return value;
            }
        };
        GanttTaskConvert.formatTaskValueFromGanttChartToListView = function (value, defaultColName, ganttListViewInfo) {
            switch (defaultColName) {
                case "IdCol": return value;
                case "OrderCol": return parseInt(value);
                case "LevelCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "NameCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "DependsCol": return Utilities.isEmpty(value) ? "" : value.toString();
                case "StartCol":
                case "EndCol": {
                    var d = Utilities.isEmpty(value) ? new Date() : new Date(value);
                    d.setHours(0, 0, 0, 0);
                    return Forguncy.ConvertDateToOADate(d);
                }
                case "DurationCol": return Utilities.isEmpty(value) ? 2 : parseInt(value);
                case "ProgressCol": return Utilities.isEmpty(value) ? 0 : parseInt(value);
                case "DescriptionCol": return Utilities.isEmpty(value) ? "" : value;
                case "CodeCol": return Utilities.isEmpty(value) ? "" : value;
                case "StartIsMilestoneCol": return Boolean(value);
                case "EndIsMilestoneCol": return Boolean(value);
                case "ActualStartCol": return Utilities.isEmpty(value) ? undefined : Forguncy.ConvertDateToOADate(new Date(value));
                case "ActualEndCol": return Utilities.isEmpty(value) ? undefined : Forguncy.ConvertDateToOADate(new Date(value));
                case "AssigsCol": return Utilities.isEmpty(value) ? "" : value;
                case "CollapsedCol": return Boolean(value);
                case "StatusCol": return Utilities.isEmpty(value) || Utilities.isEmpty(ganttListViewInfo.GanttStatusSetInfo) ? "" : this.formatTaskStatusValueFromGanttChartToListView(value, ganttListViewInfo.GanttStatusSetInfo);
                case "CanWriteCol": return Boolean(value);
                case "CanAddCol": return Boolean(value);
                case "CanDeleteCol": return Boolean(value);
                case "CanAddIssueCol": return Boolean(value);
                default: return value;
            }
        };
        GanttTaskConvert.formatTaskStatusValueFromListViewToGanttChart = function (value, ganttStatusSetInfo) {
            var setInfo = Object.keys(ganttStatusSetInfo);
            for (var i = 0; i < setInfo.length; i++) {
                var key = setInfo[i];
                var setValue = ganttStatusSetInfo[key];
                if (setValue === value) {
                    var defaultValue = this.GanntStatusDefaultInfo[key];
                    return defaultValue;
                }
            }
        };
        GanttTaskConvert.formatTaskStatusValueFromGanttChartToListView = function (value, ganttStatusSetInfo) {
            var defaultInfo = Object.keys(this.GanntStatusDefaultInfo);
            for (var i = 0; i < defaultInfo.length; i++) {
                var key = defaultInfo[i];
                var defaultValue = this.GanntStatusDefaultInfo[key];
                if (defaultValue === value) {
                    var setValue = ganttStatusSetInfo[key];
                    return setValue;
                }
            }
        };
        GanttTaskConvert.setTaskCollapsedFromListViewToGanttChart = function (task, ganttListViewInfo, ganttTaskSetColInfo) {
            var ganttCollapsedSetLevel = ganttListViewInfo.GanttCollapsedSetLevel;
            var setCollapsedColName = ganttTaskSetColInfo.CollapsedCol;
            var defaultCollapsedColName = this.GanntTaskNotRequiredColInfo.CollapsedCol;
            if (Utilities.isEmpty(setCollapsedColName) && ganttCollapsedSetLevel > -1) {
                task[defaultCollapsedColName] = task.level >= ganttCollapsedSetLevel;
            }
        };
        GanttTaskConvert.GanntTaskRequiredColInfo = {
            IdCol: "id",
            OrderCol: "order",
            LevelCol: "level",
            NameCol: "name",
            DependsCol: "depends",
            StartCol: "start",
            EndCol: "end",
            DurationCol: "duration"
        };
        GanttTaskConvert.GanntTaskNotRequiredColInfo = {
            DescriptionCol: "description",
            CodeCol: "code",
            ProgressCol: "progress",
            StartIsMilestoneCol: "startIsMilestone",
            EndIsMilestoneCol: "endIsMilestone",
            ActualStartCol: "actualStart",
            ActualEndCol: "actualEnd",
            AssigsCol: "assigs",
            CollapsedCol: "collapsed",
            StatusCol: "status",
            CanWriteCol: "canWirte",
            CanAddCol: "canAdd",
            CanDeleteCol: "canDelete",
            CanAddIssueCol: "canAdd",
        };
        GanttTaskConvert.GanntStatusDefaultInfo = {
            WaitingCol: "STATUS_WAITING",
            ActiveCol: "STATUS_ACTIVE",
            CompletedCol: "STATUS_DONE",
            SuspendedCol: "STATUS_SUSPENDED",
            FailedCol: "STATUS_FAILED"
        };
        return GanttTaskConvert;
    }());
    var GanttCalendarConvert = (function () {
        function GanttCalendarConvert() {
        }
        GanttCalendarConvert.getColumnsFromColInfo = function (setColInfo) {
            return Object.keys(this.GanntCalendarColInfo).map(function (col) {
                return setColInfo[col];
            });
        };
        GanttCalendarConvert.getHolidaysFromTableToGanttChart = function (ganttCalendarInfo, formulaCalcContext) {
            var _this = this;
            if (Utilities.isEmpty(ganttCalendarInfo) || Utilities.isEmpty(ganttCalendarInfo.TableName)) {
                return [];
            }
            var tableName = ganttCalendarInfo.TableName;
            var ganttCalendarSetColInfo = ganttCalendarInfo.GanttCalendarSetColInfo;
            var columns = this.getColumnsFromColInfo(ganttCalendarSetColInfo);
            var queryCondition = ganttCalendarInfo.QueryCondition;
            var params = {
                TableName: tableName,
                Columns: columns,
                QueryCondition: queryCondition,
                QueryPolicy: {
                    Distinct: true,
                    QueryNullPolicy: Forguncy.QueryNullPolicy.QueryAllItemsWhenValueIsNull,
                    IgnoreCache: false
                },
                SortCondition: null
            };
            var rowsData = [];
            Forguncy.getTableDataByCondition(params, formulaCalcContext, function (data) {
                if (!Utilities.isEmpty(data)) {
                    rowsData = data;
                }
            }, false);
            var holidays = rowsData.map(function (row) {
                var date = row[ganttCalendarSetColInfo.DateCol];
                var isHoliday = row[ganttCalendarSetColInfo.IsHolidayCol];
                var holiday = {
                    date: _this.formatHolidayValueFromTableToGanttChart(date, 'date'),
                    isHoliday: _this.formatHolidayValueFromTableToGanttChart(isHoliday, 'isHoliday')
                };
                return holiday;
            });
            return holidays;
        };
        GanttCalendarConvert.formatHolidayValueFromTableToGanttChart = function (value, defaultColName) {
            switch (defaultColName) {
                case "date": return Utilities.isEmpty(value) ? Date.now() : Date.parse(Forguncy.ConvertOADateToDate(value));
                case "isHoliday": return Boolean(value);
                default: return value;
            }
        };
        GanttCalendarConvert.GanntCalendarColInfo = {
            DateCol: "date",
            IsHolidayCol: "isHoliday"
        };
        return GanttCalendarConvert;
    }());
    var ListViewSelectionChangedCapture = (function () {
        function ListViewSelectionChangedCapture() {
        }
        ListViewSelectionChangedCapture.regist = function (listView, notify) {
            listView.bind(Forguncy.ListViewEvents.Reloaded, function (arg1, arg2) {
                setTimeout(function () {
                    notify && notify();
                }, 0);
            });
            listView.bind(Forguncy.ListViewEvents.ValueChanged, function (arg1, arg2) {
                notify && notify();
            });
        };
        return ListViewSelectionChangedCapture;
    }());
    var ListViewHelper = (function () {
        function ListViewHelper() {
        }
        ListViewHelper.getRowIndex = function (listView, idCol, idValue) {
            var count = listView.getRowCount();
            for (var rowIndex = 0; rowIndex < count; rowIndex++) {
                if (listView.getValue(rowIndex, idCol) == idValue) {
                    return rowIndex;
                }
            }
        };
        ListViewHelper.addRows = function (listView, rows) {
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                listView.addNewRow(row);
            });
        };
        ListViewHelper.editRows = function (listView, rows) {
            var _this = this;
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                var primaryKey = row.primaryKey, values = row.values;
                var idCol = primaryKey.idCol, idValue = primaryKey.idValue;
                var rowIndex = _this.getRowIndex(listView, idCol, idValue);
                Object.keys(values).forEach(function (col) {
                    var value = values[col];
                    listView.setValue(rowIndex, col, value);
                });
            });
        };
        ListViewHelper.deleteRows = function (listView, rows) {
            var _this = this;
            if (Utilities.isEmpty(rows))
                return;
            rows.forEach(function (row) {
                var idCol = row.idCol, idValue = row.idValue;
                var rowIndex = _this.getRowIndex(listView, idCol, idValue);
                listView.deleteRow(rowIndex);
            });
        };
        ListViewHelper.modifyRows = function (listView, modifyData) {
            var addRows = modifyData.addRows, editRows = modifyData.editRows, deleteRows = modifyData.deleteRows;
            this.addRows(listView, addRows);
            this.editRows(listView, editRows);
            this.deleteRows(listView, deleteRows);
        };
        return ListViewHelper;
    }());
    var Utilities = (function () {
        function Utilities() {
        }
        Utilities.isEmpty = function (value) {
            return value === null || value === undefined || value === "";
        };
        return Utilities;
    }());
})(Gantt || (Gantt = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Gantt.GanttCellType, Gantt", Gantt.GanttCellType);
