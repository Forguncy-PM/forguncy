﻿var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    var TabContentUI = (function (_super) {
        __extends(TabContentUI, _super);
        function TabContentUI() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(TabContentUI.prototype, "activeTab", {
            set: function (value) {
                this.container.find("." + "FTM-content-iframe").hide();
                this.showActiveIframe();
            },
            enumerable: false,
            configurable: true
        });
        TabContentUI.prototype.createContainer = function () {
            this.container = $("<div class=\"" + "FTM-content" + "\" id='page-content'></div>");
            this.target.on("TabsClosed", function (tabs) {
                tabs.forEach(function (tab) { return tab.iframeContainer && tab.iframeContainer.remove(); });
            });
            this.target.on("ReloadTab", function (tabs) {
                tabs.forEach(function (tab) {
                    if (tab.iframeContainer) {
                        var iframe = tab.iframeContainer[0];
                        try {
                            iframe.contentWindow.location.href = tab.url;
                        }
                        catch (_a) {
                        }
                    }
                });
            });
        };
        TabContentUI.prototype.showActiveIframe = function () {
            var tab = this.target.activeTab;
            if (tab) {
                if (!tab.iframeContainer) {
                    tab.iframeContainer = $("<iframe name=\"" + tab.uid + "\" class=\"" + "FTM-content-iframe" + "\"/>").attr("src", tab.url);
                    this.container.append(tab.iframeContainer);
                }
                tab.iframeContainer.show();
                try {
                    var window_1 = tab.iframeContainer[0].contentWindow;
                    window_1.Forguncy.ForguncyData.pageInfo.pageElementManager.resizePageElements();
                }
                catch (_a) {
                }
            }
        };
        return TabContentUI;
    }(TabManager.ControlUIBase));
    TabManager.TabContentUI = TabContentUI;
})(TabManager || (TabManager = {}));
