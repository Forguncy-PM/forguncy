﻿var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    var UserControl = (function (_super) {
        __extends(UserControl, _super);
        function UserControl() {
            var _this = _super.call(this) || this;
            _this.enabled = true;
            _this.visibility = true;
            _this.focusable = false;
            _this.isFocus = false;
            _this.registedProperties = [];
            _this.registDefaultProperties();
            return _this;
        }
        UserControl.prototype.refresh = function () {
            this.dispatch("Refresh");
            return this;
        };
        UserControl.prototype.identify = function (id) {
            this.id = id;
            return this;
        };
        UserControl.prototype.show = function () {
            this.refresh();
            this.visibility = true;
            return this;
        };
        UserControl.prototype.hide = function () {
            this.visibility = false;
            return this;
        };
        UserControl.prototype.focus = function () {
            this.isFocus = true;
            return this;
        };
        UserControl.prototype.blur = function () {
            this.isFocus = false;
            return this;
        };
        UserControl.prototype.enable = function () {
            this.enabled = true;
            return this;
        };
        UserControl.prototype.disable = function () {
            this.enabled = false;
            return this;
        };
        UserControl.prototype.createUI = function (uiConstructor) {
            if (uiConstructor === void 0) { uiConstructor = this.defaultUI; }
            return new uiConstructor(this);
        };
        UserControl.prototype.bindProperty = function (targetElement, targetName, sourceName) {
            var _this = this;
            if (this.registedProperties.indexOf(sourceName) < 0) {
                this.registProperty(sourceName);
            }
            if (targetElement.registedProperties.indexOf(targetName) < 0) {
                targetElement.registProperty(targetName);
            }
            targetElement[targetName] = this[sourceName];
            targetElement.on("PropertyChanged", function (data, propertyName) {
                if (propertyName === targetName && targetElement) {
                    _this[sourceName] = targetElement[targetName];
                }
            });
            this.on("PropertyChanged", function (data, propertyName) {
                if (propertyName === sourceName && targetElement) {
                    targetElement[targetName] = _this[sourceName];
                }
            });
        };
        UserControl.prototype.registProperty = function (propertyName, value) {
            if (value === void 0) { value = this[propertyName]; }
            var self = this;
            var privatePropertyName = "__" + propertyName;
            this[privatePropertyName] = value;
            Object.defineProperty(this, propertyName, {
                get: function () {
                    return self[privatePropertyName];
                },
                set: function (newValue) {
                    if (newValue !== self[privatePropertyName]) {
                        self[privatePropertyName] = newValue;
                        self.onPropertyChanged(propertyName);
                    }
                }
            });
            this.registedProperties.push(propertyName);
        };
        UserControl.prototype.registDefaultProperties = function () {
            this.registProperty("id");
            this.registProperty("enabled");
            this.registProperty("visibility");
            this.registProperty("focusable");
            this.registProperty("isFocus");
        };
        UserControl.prototype.onPropertyChanged = function (propertyName) {
            this.dispatch("PropertyChanged", propertyName);
        };
        return UserControl;
    }(TabManager.EventDispatcher));
    TabManager.UserControl = UserControl;
    var JQueryUIBase = (function () {
        function JQueryUIBase(target) {
            this.target = target;
            this.createContainer();
            this.createContainerEvents();
            this.refresh();
        }
        JQueryUIBase.prototype.refresh = function () {
            this.container.empty();
            this.createChildren();
            return this;
        };
        JQueryUIBase.prototype.dispose = function () { };
        JQueryUIBase.prototype.createChildren = function () { };
        JQueryUIBase.prototype.createContainer = function () {
            this.container = $('<div></div>');
        };
        JQueryUIBase.prototype.createContainerEvents = function () { };
        JQueryUIBase.prototype.addChild = function (jqueryUI, targetContainer) {
            if (targetContainer === void 0) { targetContainer = this.container; }
            if (jqueryUI && targetContainer) {
                targetContainer.append(jqueryUI.container);
            }
        };
        return JQueryUIBase;
    }());
    TabManager.JQueryUIBase = JQueryUIBase;
    var ControlUIBase = (function (_super) {
        __extends(ControlUIBase, _super);
        function ControlUIBase(target) {
            var _this = _super.call(this, target) || this;
            _this.target.on("Refresh", function () {
                _this.refresh();
            });
            _this.target.on("PropertyChanged", function (propertyName) {
                _this[propertyName] = _this.target[propertyName];
            });
            _this.target.on("Dispose", function () {
                _this.dispose();
            });
            return _this;
        }
        Object.defineProperty(ControlUIBase.prototype, "id", {
            set: function (value) {
                if (value === undefined || value === null || value === '') {
                    this.container.removeAttr('id');
                }
                else {
                    this.container.attr('id', value);
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "enabled", {
            set: function (value) {
                if (value) {
                    this.container.removeClass("FUI-disable");
                    this.container.removeAttr("disabled");
                    this.focusable = this.target.focusable;
                }
                else {
                    this.container.addClass("FUI-disable");
                    this.container.attr("disabled", "disabled");
                    this.focusable = false;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "visibility", {
            set: function (value) {
                if (value) {
                    this.container.show();
                }
                else {
                    this.container.hide();
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "focusable", {
            set: function (value) {
                if (value && this.target.enabled) {
                    this.container.attr("tabindex", "0");
                }
                else {
                    this.container.removeAttr("tabindex");
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "isFocus", {
            set: function (value) {
                if (value && this.target.focusable) {
                    this.container[0].focus();
                }
                else {
                    this.container[0].blur();
                }
            },
            enumerable: false,
            configurable: true
        });
        ControlUIBase.prototype.refresh = function () {
            _super.prototype.refresh.call(this);
            this.initializeProperties();
            return this;
        };
        ControlUIBase.prototype.createContainerEvents = function () {
            this.bindFocusAndBlurEvent();
        };
        ControlUIBase.prototype.initializeProperties = function () {
            var _this = this;
            this.target.registedProperties.forEach(function (propertyName) {
                _this[propertyName] = _this.target[propertyName];
            });
        };
        ControlUIBase.prototype.bindFocusAndBlurEvent = function (container) {
            var _this = this;
            if (container === void 0) { container = this.container; }
            container.on("focus", function () {
                _this.target.focus();
            });
            container.on("blur", function () {
                _this.target.blur();
            });
        };
        return ControlUIBase;
    }(JQueryUIBase));
    TabManager.ControlUIBase = ControlUIBase;
})(TabManager || (TabManager = {}));
