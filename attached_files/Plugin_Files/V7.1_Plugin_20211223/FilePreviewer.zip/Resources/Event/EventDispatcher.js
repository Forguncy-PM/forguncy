var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
var FilePreviewer;
(function (FilePreviewer) {
    var EventDispatcher = (function () {
        function EventDispatcher() {
            this.events = new FilePreviewer.Events();
        }
        EventDispatcher.prototype.on = function (eventName, handler, force) {
            if (force === void 0) { force = true; }
            this.events.addHandler(eventName, handler, force);
        };
        EventDispatcher.prototype.off = function (eventName, handler) {
            this.events.removeHandler(eventName, handler);
        };
        EventDispatcher.prototype.dispatch = function (eventName) {
            var _a;
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            (_a = this.events).raiseEvent.apply(_a, __spreadArray([eventName], args));
        };
        EventDispatcher.prototype.dispose = function () {
            this.events.release();
        };
        return EventDispatcher;
    }());
    FilePreviewer.EventDispatcher = EventDispatcher;
})(FilePreviewer || (FilePreviewer = {}));
