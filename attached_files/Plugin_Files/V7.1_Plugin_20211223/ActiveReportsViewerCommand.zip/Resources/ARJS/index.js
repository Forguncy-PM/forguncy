function load() {
    new ARViewer().init();
}
var ARViewer = (function () {
    function ARViewer() {
        this.defaultLangauge = "zh";
    }
    ARViewer.prototype.init = function () {
        var raw = sessionStorage.getItem("FGC_AR_Model");
        var model = JSON.parse(raw);
        if (model) {
            this.trySetWindowTitle(model.MainFileTitle);
            this.tryActiveLicense(model.LicenseKey);
            this.openFile(model);
        }
    };
    ARViewer.prototype.trySetWindowTitle = function (title) {
        if (title) {
            window.document.title = title;
        }
    };
    ARViewer.prototype.tryActiveLicense = function (licenseKey) {
        if (licenseKey) {
            GC.ActiveReports.Core.PageReport.LicenseKey = licenseKey;
        }
    };
    ARViewer.prototype.openFile = function (model) {
        var fileName = model.MainFilePath;
        if (fileName) {
            var params = model.PassValueItems.map(function (v) { return ({ Name: v.ActualTarget, Value: [v.ActualSource] }); });
            params.push({ Name: "ForguncyBaseUrl", Value: [model.ForguncyBaseUrl] });
            var options = { ReportParams: params };
            this.openViewer(fileName, options, !!model.ShowSideBar);
        }
    };
    ARViewer.prototype.openViewer = function (fileName, options, showSideBar) {
        var viewer = new ActiveReports.Viewer('#ARJSviewerDiv', { language: this.defaultLangauge });
        viewer.toggleSidebar(showSideBar);
        viewer.open(fileName, options);
    };
    return ARViewer;
}());
