var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ReloadListViewCommand;
(function (ReloadListViewCommand_1) {
    var ReloadListViewCommand = /** @class */ (function (_super) {
        __extends(ReloadListViewCommand, _super);
        function ReloadListViewCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ReloadListViewCommand.prototype.execute = function () {
            var metadata = this.CommandParam;
            if (!metadata || !metadata.SelectedName || metadata.SelectedName.trim() === "") {
                alert(ReloadListViewCommand_1.ResourcesHelper.getResource().Error_NoListView);
                return;
            }
            var listView = Forguncy.Page.getListView(metadata.SelectedName);
            if (listView === undefined || listView === null) {
                alert(ReloadListViewCommand_1.ResourcesHelper.getResource().Error_InvalidListViewName.replace("{0}", metadata.SelectedName));
                return;
            }
            if (metadata.IsClearFilter) {
                listView.clearAllColumnFilters();
                listView.goToFirstPage();
            }
            listView.reload();
        };
        return ReloadListViewCommand;
    }(Forguncy.Plugin.CommandBase));
    ReloadListViewCommand_1.ReloadListViewCommand = ReloadListViewCommand;
})(ReloadListViewCommand || (ReloadListViewCommand = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CommandFactory.registerCommand("ReloadListViewCommand.ReloadListViewCommand, ReloadListViewCommand", ReloadListViewCommand.ReloadListViewCommand);
