var ReloadListViewCommand;
(function (ReloadListViewCommand) {
    var RS_JP = {
        Error_NoListView: "リストビュー名が不正です。",
        Error_InvalidListViewName: "現在のリストビュー「{0}」は存在しません。"
    };
    var RS_CN = {
        Error_NoListView: "表格名称不合法",
        Error_InvalidListViewName: "当前表格 {0} 不存在"
    };
    var RS_KO = {
        Error_NoListView: "",
        Error_InvalidListViewName: ""
    };
    var RS_EN = {
        Error_NoListView: "Invalid name of ListView",
        Error_InvalidListViewName: "The current ListView {0} does not exist"
    };
    var ResourcesHelper = /** @class */ (function () {
        function ResourcesHelper() {
        }
        ResourcesHelper.getResource = function () {
            switch (Forguncy.RS.Culture) {
                case "CN" /* Chinese */:
                    return RS_CN;
                case "JA" /* Japanese */:
                    return RS_JP;
                case "KR" /* Korean */:
                    return RS_KO;
                default:
                    return RS_EN;
            }
        };
        return ResourcesHelper;
    }());
    ReloadListViewCommand.ResourcesHelper = ResourcesHelper;
})(ReloadListViewCommand || (ReloadListViewCommand = {}));
