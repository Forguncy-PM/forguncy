var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ImageViewerCommand;
(function (ImageViewerCommand_1) {
    var ImageViewerCommand = /** @class */ (function (_super) {
        __extends(ImageViewerCommand, _super);
        function ImageViewerCommand() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ImageViewerCommand.prototype.execute = function () {
            var LIMIT_CLASS_NAME = 'image-viewer-command';
            var QUERY_IMAGE_SIZE_NAME = 'imageSize';
            var commandParam = this.CommandParam;
            var targetCellLocation = Forguncy.FormulaHelper.getCellLocation(commandParam.TargetCell, this.CommandExecutingInfo.runTimePageName);
            if (!targetCellLocation) {
                return;
            }
            var cellId = this.getIdStr(targetCellLocation);
            var targetCellDOM = $("#" + cellId)[0];
            if (!targetCellDOM) {
                return;
            }
            var targetImgs = $("#" + cellId + " img");
            var isMoreOneImg = targetImgs.length > 1;
            // 当前触发命令的的单元格 C，目标单元格 T：C 内的第一个 Img 的有效次序作为预览的 initialViewIndex，其余情况均取默认值 0
            // 如果只有一张图片就不需要判断了
            var initialViewIndex = 0;
            if (isMoreOneImg) {
                var currentImg = $("#" + this.CommandExecutingInfo.commandId + " img");
                var currentImgIndex = targetImgs.index(currentImg);
                if (currentImgIndex > -1 && currentImgIndex !== initialViewIndex) {
                    initialViewIndex = currentImgIndex;
                }
            }
            var viewer = new Viewer(targetCellDOM, {
                initialViewIndex: initialViewIndex,
                hidden: function () {
                    viewer.destroy();
                },
                url: function (image) {
                    // upload 路径下会有 QUERY_IMAGE_SIZE_NAME 条件来设置返回小、中或大图，在预览下需要移除此选项均返回大图
                    var originImageHref = image.src;
                    var uploadURL = Forguncy.Helper.SpecialPath.getUploadImageFolderPathInServer();
                    if (!originImageHref.search(uploadURL)) {
                        return originImageHref;
                    }
                    var searchIndex = originImageHref.indexOf('?');
                    var hashIndex = originImageHref.indexOf('#');
                    var isHasHash = hashIndex > -1;
                    var search = isHasHash ? originImageHref.substring(searchIndex, hashIndex) : originImageHref.substring(searchIndex);
                    var querys = search.substring(1).split('&');
                    for (var i = 0, len = querys.length; i < len; i++) {
                        var queryName = querys[i].split("=")[0];
                        if (queryName === QUERY_IMAGE_SIZE_NAME) {
                            querys.splice(i, 1);
                            return originImageHref.substring(0, searchIndex) + "?" + querys.join('&') + (isHasHash ? originImageHref.substring(hashIndex) : '');
                        }
                    }
                    return originImageHref;
                },
                className: LIMIT_CLASS_NAME,
                navbar: isMoreOneImg,
                toolbar: {
                    zoomIn: true,
                    zoomOut: true,
                    oneToOne: true,
                    reset: true,
                    prev: false,
                    play: {
                        show: isMoreOneImg,
                        size: 'large',
                    },
                    next: false,
                    rotateLeft: true,
                    rotateRight: true,
                    flipHorizontal: true,
                    flipVertical: true
                }
            });
            viewer.show();
            // 使用此样式的 prev 和 next 来切换图片
            if (isMoreOneImg) {
                var prev = $("\n                <a class=\"carousel-control-prev\" role=\"button\" data-slide=\"prev\">\n                  <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>\n                  <span class=\"sr-only\">Previous</span>\n                </a>");
                var next = $("\n                <a class=\"carousel-control-next\" role=\"button\" data-slide=\"next\">\n                  <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>\n                  <span class=\"sr-only\">Next</span>\n                </a>");
                prev.on('click', function () { viewer.prev(); });
                next.on('click', function () { viewer.next(); });
                $("." + LIMIT_CLASS_NAME).append(prev, next);
            }
        };
        ImageViewerCommand.prototype.getIdStr = function (cellLocation) {
            return Forguncy.Page.getCellByLocation(cellLocation)._getCellId();
        };
        return ImageViewerCommand;
    }(Forguncy.Plugin.CommandBase));
    ImageViewerCommand_1.ImageViewerCommand = ImageViewerCommand;
})(ImageViewerCommand || (ImageViewerCommand = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CommandFactory.registerCommand("ImageViewerCommand.ImageViewerCommand, ImageViewerCommand", ImageViewerCommand.ImageViewerCommand);
//# sourceMappingURL=ImageViewerCommand.js.map